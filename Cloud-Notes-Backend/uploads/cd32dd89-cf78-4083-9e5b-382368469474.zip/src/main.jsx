import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import App from './App.jsx';
import './index.css'; // This contains your CSS variables

// Import Providers
import { ThemeProvider } from './contexts/ThemeContext';
import { AuthProvider } from './auth/AuthProvider'; // <-- IMPORT THE AUTH PROVIDER

// Import the new Navbar styles
import './styles/components/Navbar.css'; // <-- IMPORT THE NAVBAR CSS

const queryClient = new QueryClient();

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    {/* WRAP YOUR APP WITH ALL PROVIDERS */}
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <AuthProvider> {/* <-- WRAP WITH AUTH PROVIDER */}
          <ThemeProvider>
            <App />
          </ThemeProvider>
        </AuthProvider>
      </BrowserRouter>
    </QueryClientProvider>
  </React.StrictMode>,
);