import { useState } from 'react';
import '../styles/components/Modal.css'; // Import our custom CSS

export default function RejectModal({ show, onHide, candidate, onSend }) {
  const [feedback, setFeedback] = useState(
    `Dear ${candidate?.candidateName || 'Candidate'},\n\n` +
    'After careful review we decided to proceed with other applicants whose skills more closely match our needs.\n\n' +
    'We encourage you to upskill and apply again in the future.\n\n' +
    'Best regards,\nRecruitment Team'
  );

  const handleSend = () => {
    onSend(candidate.applicationId, feedback);
    onHide();
  };

  // Handle clicks on the backdrop to close the modal
  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) {
      onHide();
    }
  };

  if (!show) {
    return null;
  }

  return (
    <div className={`modal-overlay ${show ? 'show' : ''}`} onClick={handleBackdropClick}>
      <div className={`modal modal--lg`}>
        <div className="modal__header">
          <h5 className="modal__title">Reject Candidate – Email Preview</h5>
          <button className="modal__close-button" onClick={onHide} aria-label="Close">
            &times;
          </button>
        </div>
        <div className="modal__body">
          <div className="form-group">
            <label className="form-label">Feedback / Email Body</label>
            <textarea
              className="form-control"
              rows={8}
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
            />
          </div>
        </div>
        <div className="modal__footer">
          <button className="btn btn-secondary" onClick={onHide}>
            Cancel
          </button>
          <button className="btn btn-danger" onClick={handleSend}>
            Send Rejection Email
          </button>
        </div>
      </div>
    </div>
  );
}