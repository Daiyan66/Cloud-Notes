import React, { useState, useEffect } from 'react';
import recruiterRequestService from '../services/recruiterRequestService';
import Spinner from './Spinner'; // Import our custom Spinner
import '../styles/components/ManageRecruiterRequests.css'; // Import our custom CSS

const ManageRecruiterRequests = () => {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [actionLoading, setActionLoading] = useState(null); // To disable buttons during action

  const fetchRequests = () => {
    setLoading(true);
    setError('');
    recruiterRequestService.getPendingRequests()
      .then(response => {
        setRequests(response.data);
      })
      .catch(err => {
        setError('Failed to fetch requests. Please try again.');
        console.error(err);
      })
      .finally(() => {
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchRequests();
  }, []);

  const handleApprove = async (requestId) => {
    setActionLoading(requestId);
    try {
      await recruiterRequestService.approveRequest(requestId);
      fetchRequests();
    } catch (err) {
      setError('Failed to approve request.');
      console.error(err);
    } finally {
      setActionLoading(null);
    }
  };

  const handleReject = async (requestId) => {
    setActionLoading(requestId);
    try {
      await recruiterRequestService.rejectRequest(requestId);
      fetchRequests();
    } catch (err) {
      setError('Failed to reject request.');
      console.error(err);
    } finally {
      setActionLoading(null);
    }
  };

  if (loading) {
    return (
      <div className="manage-requests__loading">
        <Spinner size="3rem" />
      </div>
    );
  }

  return (
    <div className="manage-requests">
      <h4 className="manage-requests__header">Pending Recruiter Requests</h4>
      <div className="manage-requests__body">
        {error && <div className="alert alert--danger">{error}</div>}
        
        {requests.length === 0 && !loading && (
          <p className="manage-requests__empty-state">No pending requests at the moment.</p>
        )}
        
        {requests.length > 0 && (
          <div className="table-wrapper">
            <table className="manage-requests__table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Company</th>
                  <th>Message</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {requests.map((request) => (
                  <tr key={request.id}>
                    <td>{request.name}</td>
                    <td>{request.email}</td>
                    <td>{request.company}</td>
                    <td>{request.message || '-'}</td>
                    <td>
                      <div className="manage-requests__actions">
                        <button
                          className="btn btn-success btn-sm"
                          onClick={() => handleApprove(request.id)}
                          disabled={actionLoading === request.id}
                        >
                          {actionLoading === request.id ? 'Approving...' : 'Approve'}
                        </button>
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => handleReject(request.id)}
                          disabled={actionLoading === request.id}
                        >
                          {actionLoading === request.id ? 'Rejecting...' : 'Reject'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default ManageRecruiterRequests;