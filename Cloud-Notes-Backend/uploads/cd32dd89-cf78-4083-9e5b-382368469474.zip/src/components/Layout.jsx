// src/components/Layout.jsx

import { useState, useEffect, useRef } from 'react';
import { Outlet, Link } from 'react-router-dom';
import { useAuth } from '../auth/AuthProvider';
import { ROLES } from '../utils/constants';
import ThemeToggle from './ThemeToggle'; // Assuming you've created this component
// In src/App.jsx or src/Layout.jsx
import '../styles/components/Navbar.css';

const Layout = () => {
  const { user, logout, hasRole } = useAuth();
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);
  const [isJobDropdownOpen, setIsJobDropdownOpen] = useState(false);
  const jobDropdownRef = useRef(null);

  const handleLogout = () => {
    logout();
    window.location.href = '/login';
  };

  const toggleMobileNav = () => {
    setIsMobileNavOpen(!isMobileNavOpen);
  };

  const toggleJobDropdown = () => {
    setIsJobDropdownOpen(!isJobDropdownOpen);
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (jobDropdownRef.current && !jobDropdownRef.current.contains(event.target)) {
        setIsJobDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <>
      <nav className="navbar">
        <div className="container">
          {/* Brand */}
          <Link to="/" className="navbar-brand">
            AI-Resume ·{" "}
            {user?.role === 'ADMIN'
              ? 'Admin Portal'
              : user?.role === 'RECRUITER'
              ? 'Recruiter Dashboard'
              : 'Candidate Home'}
          </Link>

          {/* Mobile Toggler */}
          <button className="navbar-toggler" onClick={toggleMobileNav} aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>

          {/* Collapsible Content */}
          <div className={`navbar-collapse ${isMobileNavOpen ? 'show' : ''}`}>
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link to="/" className="nav-link" onClick={() => setIsMobileNavOpen(false)}>
                  Dashboard
                </Link>
              </li>

              {/* ADMIN ONLY */}
              {hasRole(ROLES.ADMIN) && (
                <li className="nav-item">
                  <Link to="/admin/add-recruiter" className="nav-link" onClick={() => setIsMobileNavOpen(false)}>
                    Add Recruiter
                  </Link>
                </li>
              )}

              {/* RECRUITER ONLY (not ADMIN) */}
              {hasRole(ROLES.RECRUITER) && !hasRole(ROLES.ADMIN) && (
                <>
                  <li className="nav-item dropdown" ref={jobDropdownRef}>
                    <button className="nav-link dropdown-toggle" onClick={toggleJobDropdown}>
                      Upload Job
                    </button>
                    <div className={`dropdown-menu ${isJobDropdownOpen ? 'show' : ''}`}>
                      <Link to="/upload-job" className="dropdown-item" onClick={() => setIsJobDropdownOpen(false)}>
                        Upload PDF/DOCX
                      </Link>
                      <Link to="/upload-job-form" className="dropdown-item" onClick={() => setIsJobDropdownOpen(false)}>
                        Create from Form
                      </Link>
                    </div>
                  </li>
                  <li className="nav-item">
                    <Link to="/upload-resumes" className="nav-link" onClick={() => setIsMobileNavOpen(false)}>
                      Upload Resumes
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link to="/candidates" className="nav-link" onClick={() => setIsMobileNavOpen(false)}>
                      Candidates
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link to="/recruiter/analyzed-resumes" className="nav-link" onClick={() => setIsMobileNavOpen(false)}>
                      Analyzed Resumes
                    </Link>
                  </li>
                </>
              )}

              {/* CANDIDATE ONLY */}
              {hasRole(ROLES.CANDIDATE) && (
                <>
                  <li className="nav-item">
                    <Link to="/my-status" className="nav-link" onClick={() => setIsMobileNavOpen(false)}>
                      My Status
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link to="/candidate/analysis/latest" className="nav-link" onClick={() => setIsMobileNavOpen(false)}>
                      Skill Analysis
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link to="/browse-jobs" className="nav-link" onClick={() => setIsMobileNavOpen(false)}>
                      Browse Jobs
                    </Link>
                  </li>
                </>
              )}
            </ul>

            <ul className="navbar-nav ms-auto">
              <li className="nav-item">
                <span className="navbar-text">
                  Welcome, {user?.firstName || user?.username} ({user?.role})
                </span>
              </li>
              <li className="nav-item">
                 <ThemeToggle /> {/* Add the theme toggle button here */}
              </li>
              <li className="nav-item">
                <button className="btn btn-logout" onClick={handleLogout}>
                  Logout
                </button>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      <main className="container main-content">
        <Outlet />
      </main>
    </>
  );
};

export default Layout;