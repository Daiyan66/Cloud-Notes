import React from 'react';
import { useTheme } from '../contexts/ThemeContext';
import '../styles/components/ThemeToggle.css'; // We will create this CSS file

const ThemeToggle = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <button className="theme-toggle-btn" onClick={toggleTheme} aria-label="Toggle theme">
      {theme === 'light' ? '🌙' : '☀️'}
    </button>
  );
};

export default ThemeToggle;