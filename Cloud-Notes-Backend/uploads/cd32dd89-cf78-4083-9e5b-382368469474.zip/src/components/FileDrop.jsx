import { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import Spinner from './Spinner'; // Import our custom Spinner
import '../styles/components/FileDrop.css'; // Import our custom CSS

// Note: The 'Alert' component was imported but not used, so I've removed it.

const FileDrop = ({ onDrop, multiple = false, accept = {}, uploading = false }) => {
  const handleDrop = useCallback(
    (acceptedFiles) => {
      if (onDrop) onDrop(multiple ? acceptedFiles : acceptedFiles[0]);
    },
    [onDrop, multiple]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: handleDrop,
    multiple,
    accept,
    maxSize: 50 * 1024 * 1024, // 50 MB
  });

  return (
    <div
      {...getRootProps()}
      className={`file-drop-zone ${isDragActive ? 'file-drop-zone--active' : ''}`}
    >
      <input {...getInputProps()} />
      {uploading ? (
        <Spinner size="2rem" />
      ) : isDragActive ? (
        <p>Drop the files here...</p>
      ) : (
        <p>Drag & drop files here, or click to select</p>
      )}
    </div>
  );
};

export default FileDrop;