import React from 'react';
import '../styles/components/Spinner.css';

const Spinner = ({ size = '1rem' }) => {
  return <div className="spinner" style={{ width: size, height: size }}></div>;
};

export default Spinner;