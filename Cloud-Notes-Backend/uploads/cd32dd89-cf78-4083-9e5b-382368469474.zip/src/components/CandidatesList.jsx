import React, { useState, useEffect } from 'react';
import recruiterService from '../services/recruiterService';
import Spinner from './Spinner'; // Import our custom Spinner
import '../styles/components/CandidatesList.css'; // Import our custom CSS

const CandidatesList = ({ jobId }) => {
  const [candidates, setCandidates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCandidates = async () => {
      try {
        setLoading(true);
        const data = await recruiterService.getCandidatesForJob(jobId);
        setCandidates(data);
        setError(null);
      } catch (err) {
        console.error('Error fetching candidates:', err);
        setError('Failed to fetch candidates. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    if (jobId) {
      fetchCandidates();
    }
  }, [jobId]);

  const handleAccept = async (applicationId) => {
    try {
      await recruiterService.acceptApplication(applicationId);
      setCandidates(candidates.map(candidate => 
        candidate.applicationId === applicationId 
          ? { ...candidate, status: 'ACCEPTED' } 
          : candidate
      ));
    } catch (err) {
      console.error('Error accepting application:', err);
      setError('Failed to accept application. Please try again.');
    }
  };

  const handleReject = async (applicationId) => {
    try {
      await recruiterService.rejectApplication(applicationId);
      setCandidates(candidates.map(candidate => 
        candidate.applicationId === applicationId 
          ? { ...candidate, status: 'REJECTED' } 
          : candidate
      ));
    } catch (err) {
      console.error('Error rejecting application:', err);
      setError('Failed to reject application. Please try again.');
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'ACCEPTED':
        return <span className="badge badge--success">Accepted</span>;
      case 'REJECTED':
        return <span className="badge badge--danger">Rejected</span>;
      case 'PENDING':
        return <span className="badge badge--warning">Pending</span>;
      default:
        return <span className="badge badge--secondary">{status}</span>;
    }
  };

  const getScoreBadge = (score) => {
    if (score >= 70) {
      return <span className="badge badge--success">{score}%</span>;
    } else if (score >= 50) {
      return <span className="badge badge--warning">{score}%</span>;
    } else {
      return <span className="badge badge--danger">{score}%</span>;
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (loading) {
    return (
      <div className="candidates-list__loading">
        <Spinner size="3rem" />
      </div>
    );
  }

  if (error) {
    return <div className="alert alert--danger">{error}</div>;
  }

  if (candidates.length === 0) {
    return <div className="alert alert--info">No candidates have applied for this job yet.</div>;
  }

  return (
    <div className="candidates-list">
      <h5 className="candidates-list__header">Candidates for this Job</h5>
      <div className="candidates-list__body">
        <div className="table-wrapper">
          <table className="candidates-list__table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Match Score</th>
                <th>Skills</th>
                <th>Experience</th>
                <th>Applied At</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {candidates.map((candidate) => (
                <tr key={candidate.applicationId}>
                  <td>{candidate.candidateName}</td>
                  <td>{candidate.email}</td>
                  <td>{getScoreBadge(Math.round(candidate.matchScore * 100))}</td>
                  <td>
                    <div className="candidates-list__skills-cell" title={candidate.skills}>
                      {candidate.skills}
                    </div>
                  </td>
                  <td>{candidate.experience} years</td>
                  <td>{formatDate(candidate.appliedAt)}</td>
                  <td>{getStatusBadge(candidate.status)}</td>
                  <td>
                    <div className="candidates-list__actions">
                      <button 
                        className="btn btn-success btn-sm"
                        disabled={candidate.status === 'ACCEPTED' || candidate.status === 'REJECTED'}
                        onClick={() => handleAccept(candidate.applicationId)}
                      >
                        Accept
                      </button>
                      <button 
                        className="btn btn-danger btn-sm"
                        disabled={candidate.status === 'ACCEPTED' || candidate.status === 'REJECTED'}
                        onClick={() => handleReject(candidate.applicationId)}
                      >
                        Reject
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CandidatesList;