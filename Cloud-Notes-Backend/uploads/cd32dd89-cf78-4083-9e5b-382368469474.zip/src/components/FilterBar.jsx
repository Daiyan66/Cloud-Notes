import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import '../styles/components/FilterBar.css'; // Import our custom CSS

const EDUCATION_LEVELS = ['High-School', 'Diploma', 'Bachelor', 'Master', 'PhD'];
const SKILL_OPTIONS = ['Java', 'Spring', 'React', 'MySQL', 'Python', 'Docker'];

export default function FilterBar() {
  const [searchParams, setSearchParams] = useSearchParams();

  // read from URL on first load
  const [skills, setSkills] = useState(searchParams.get('skills')?.split(',') || []);
  const [experienceMin, setExperienceMin] = useState(Number(searchParams.get('experience') || 0));
  const [education, setEducation] = useState(searchParams.get('education') || '');

  const toggleSkill = (s) =>
    setSkills((prev) =>
      prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]
    );

  const handleApply = () => {
    const params = {};
    if (skills.length) params.skills = skills.join(',');
    if (experienceMin) params.experience = experienceMin;
    if (education) params.education = education;
    
    const currentSort = searchParams.get('sort');
    if (currentSort) {
        params.sort = currentSort;
    }
    
    setSearchParams(params, { replace: true });
  };

  const handleReset = () => {
    setSkills([]);
    setExperienceMin(0);
    setEducation('');
    
    const currentSort = searchParams.get('sort');
    const resetParams = currentSort ? { sort: currentSort } : {};
    
    setSearchParams(resetParams, { replace: true });
  };

  return (
    <div className="filter-bar">
      <div className="filter-bar__row">
        <div className="filter-bar__col filter-bar__col--skills">
          <label className="form-label">Skills</label>
          <div className="filter-bar__skills-container">
            {SKILL_OPTIONS.map((s) => (
              <span
                key={s}
                className={`badge ${skills.includes(s) ? 'badge--active' : 'badge--inactive'}`}
                onClick={() => toggleSkill(s)}
                role="button"
                tabIndex="0"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    toggleSkill(s);
                  }
                }}
              >
                {s}
              </span>
            ))}
          </div>
        </div>

        <div className="filter-bar__col filter-bar__col--experience">
          <label className="form-label">Min Experience ({experienceMin} yrs)</label>
          <input
            type="range"
            className="form-range"
            min={0}
            max={30}
            value={experienceMin}
            onChange={(e) => setExperienceMin(Number(e.target.value))}
          />
        </div>

        <div className="filter-bar__col filter-bar__col--education">
          <label className="form-label">Education</label>
          <select className="form-select" value={education} onChange={(e) => setEducation(e.target.value)}>
            <option value="">Any</option>
            {EDUCATION_LEVELS.map((e) => (
              <option key={e} value={e}>{e}</option>
            ))}
          </select>
        </div>

        <div className="filter-bar__col filter-bar__col--actions">
          <button className="btn btn-primary" onClick={handleApply}>Apply</button>
          <button className="btn btn-outline-secondary" onClick={handleReset}>Reset</button>
        </div>
      </div>
    </div>
  );
}