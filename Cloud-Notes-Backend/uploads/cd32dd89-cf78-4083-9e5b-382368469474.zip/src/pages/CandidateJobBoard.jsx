import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import api from '../api/axios';
import FileDrop from '../components/FileDrop';
import Spinner from '../components/Spinner'; // <-- CORRECTED PATH
import '../styles/components/CandidateJobBoard.css';
import '../styles/components/Modal.css';

const CandidateJobBoard = () => {
  const [filters, setFilters] = useState({ title: '', skills: '', education: '', expMin: '' });
  const [selectedJob, setSelectedJob] = useState(null);
  const [file, setFile] = useState(null);
  const [msg, setMsg] = useState({ text: '', type: 'warning' });
  const [showModal, setShowModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const params = new URLSearchParams(filters).toString();
  const { data: jobs = [], isLoading: isLoadingJobs } = useQuery({
    queryKey: ['jobs', params],
    queryFn: () => api.get(`/api/candidate/jobs?${params}`).then((r) => r.data),
  });

  const { data: recommendedJobs = [], isLoading: isLoadingRecommendations } = useQuery({
    queryKey: ['recommendedJobs'],
    queryFn: () => api.get('/api/candidate/recommendations').then(r => r.data),
    refetchInterval: 60000
  });

  const handleApply = async (jobId) => {
    if (!file) return setMsg({ text: 'Please upload your resume first.', type: 'warning' });
    
    setIsSubmitting(true);
    const form = new FormData();
    form.append('resume', file);
    form.append('jobId', jobId);
    try {
      const res = await api.post('/api/candidate/apply', form, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setMsg({ text: res.data.message, type: 'success' });
      setFile(null);
      setSelectedJob(null);
      setShowModal(false);
    } catch (e) {
      setMsg({ text: e.response?.data?.message || 'An unexpected error occurred.', type: 'danger' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const openApplyModal = (job) => {
    setSelectedJob(job);
    setShowModal(true);
    setFile(null);
  };

  const closeApplyModal = () => {
    if (isSubmitting) return;
    setShowModal(false);
    setSelectedJob(null);
    setFile(null);
  };

  return (
    <div className="candidate-job-board">
      <h1 className="page-title">Candidate Home</h1>
      {msg.text && <div className={`alert alert--${msg.type}`}>{msg.text}</div>}

      <div className="recommended-jobs-card">
        <div className="recommended-jobs-card__header">Recommended for You</div>
        <div className="recommended-jobs-card__body">
          {isLoadingRecommendations ? (
            <div className="candidate-job-board__loading">
              <Spinner size="2rem" />
            </div>
          ) : recommendedJobs.length > 0 ? (
            <ul className="job-list">
              {recommendedJobs.map((job) => (
                <li key={job.id} className="job-list__item">
                  <div className="job-list__details">
                    <strong>{job.title}</strong>
                    <small>{job.skillsRequired}</small>
                  </div>
                  <button onClick={() => openApplyModal(job)} className="btn btn-primary">Apply</button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="candidate-job-board__empty-state">No new recommendations at the moment. Check back soon!</p>
          )}
        </div>
      </div>

      <section className="browse-jobs-section">
        <h2 className="section-title">Browse All Jobs</h2>
        <div className="filter-bar">
          <input 
            type="text" 
            className="form-control" 
            placeholder="Job Title" 
            value={filters.title} 
            onChange={(e) => setFilters({ ...filters, title: e.target.value })} 
          />
          <input 
            type="text" 
            className="form-control" 
            placeholder="Skills" 
            value={filters.skills} 
            onChange={(e) => setFilters({ ...filters, skills: e.target.value })} 
          />
          <input 
            type="text" 
            className="form-control" 
            placeholder="Education" 
            value={filters.education} 
            onChange={(e) => setFilters({ ...filters, education: e.target.value })} 
          />
          <input 
            type="number" 
            className="form-control" 
            placeholder="Min. Experience (yrs)" 
            value={filters.expMin} 
            onChange={(e) => setFilters({ ...filters, expMin: e.target.value })} 
          />
        </div>

        {isLoadingJobs ? (
          <div className="candidate-job-board__loading">Loading jobs…</div>
        ) : (
          <div className="jobs-table-wrapper">
            <table className="jobs-table">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Skills Required</th>
                  <th>Education</th>
                  <th>Experience</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {jobs.map((j) => (
                  <tr key={j.id}>
                    <td>{j.title}</td>
                    <td>{j.skillsRequired}</td>
                    <td>{j.educationLevel}</td>
                    <td>{j.experienceRequired} yrs</td>
                    <td><button onClick={() => openApplyModal(j)} className="btn btn-primary">Apply</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* --- APPLICATION MODAL --- */}
      {showModal && (
        <div className={`modal-overlay ${showModal ? 'show' : ''}`} onClick={closeApplyModal}>
          <div className={`modal modal--lg apply-modal`}>
            <div className="modal__header">
              <h5 className="modal__title">Apply for: {selectedJob?.title}</h5>
              <button className="modal__close-button" onClick={closeApplyModal} aria-label="Close">
                &times;
              </button>
            </div>
            <div className="modal__body">
              {selectedJob && (
                <>
                  <div className="apply-modal__job-details">
                    <h6>Job Details</h6>
                    <p><strong>Skills Required:</strong> {selectedJob.skillsRequired}</p>
                    <p><strong>Education Level:</strong> {selectedJob.educationLevel}</p>
                    <p><strong>Experience Required:</strong> {selectedJob.experienceRequired} years</p>
                  </div>
                  
                  <div className="apply-modal__submission-area">
                    <h6>Upload Your Resume</h6>
                    <div style={{ position: 'relative', opacity: isSubmitting ? 0.6 : 1 }}>
                      <FileDrop 
                        onDrop={setFile} 
                        accept={{ 'application/pdf': ['.pdf'], 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'] }} 
                      />
                    </div>
                    
                    {file && (
                      <div className="alert alert--info">
                        <p>Selected: {file.name}</p>
                        <button 
                          onClick={() => handleApply(selectedJob.id)} 
                          className="btn btn-success"
                          disabled={isSubmitting}
                        >
                          {isSubmitting ? (
                            <>
                              <Spinner size="1rem" />
                              {' '}Submitting...
                            </>
                          ) : (
                            'Submit Application'
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                </>
              )}
            </div>
            <div className="modal__footer">
              <button className="btn btn-secondary" onClick={closeApplyModal} disabled={isSubmitting}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CandidateJobBoard;