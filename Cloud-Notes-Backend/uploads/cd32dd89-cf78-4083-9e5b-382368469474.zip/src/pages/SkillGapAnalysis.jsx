import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import api from '../api/axios';
import Spinner from '../components/Spinner'; // Import our custom Spinner
import '../styles/components/SkillGapAnalysis.css'; // Import our custom CSS

const SkillGapAnalysis = () => {
    const { applicationId } = useParams();

    const { data: analysis, isLoading, error } = useQuery({
        queryKey: ['skillGapAnalysis', applicationId],
        queryFn: () => api.get(`/api/candidate/analysis/${applicationId}`).then(res => res.data),
        enabled: !!applicationId,
    });

    const generateResourceLink = (skill) => {
        return `https://www.google.com/search?q=learn+${encodeURIComponent(skill)}`;
    };

    if (isLoading) {
        return (
            <div className="skill-gap-analysis">
                <div className="candidate-status__loading"> {/* Reusing loading class */}
                    <Spinner size="3rem" />
                </div>
            </div>
        );
    }

    if (error) {
        return <div className="skill-gap-analysis"><div className="alert alert--danger">Error loading skill analysis. This application might not have detailed data available.</div></div>;
    }
    
    if (!analysis || !analysis.rawSkillGapJson) {
        return <div className="skill-gap-analysis"><div className="alert alert--info">No detailed skill gap analysis is available for this application.</div></div>;
    }

    let skillGap = {};
    try {
        skillGap = JSON.parse(analysis.rawSkillGapJson);
    } catch (e) {
        return <div className="skill-gap-analysis"><div className="alert alert--warning">Could not parse the skill analysis data.</div></div>;
    }

    const { matchedSkills = [], missingSkills = [] } = skillGap;

    return (
        <div className="skill-gap-analysis">
            <h1 className="page-title">Skill Gap Analysis</h1>
            <p className="page-subtitle">Detailed breakdown for your application to: <strong>{analysis.jobTitle}</strong></p>
            
            <div className="skill-gap-analysis__grid">
                <div className="skill-gap-card">
                    <div className="skill-gap-card__header">✅ Your Matched Skills</div>
                    <div className="skill-gap-card__body">
                        {matchedSkills.length > 0 ? (
                            <ul className="skill-list">
                                {matchedSkills.map((skill, index) => (
                                    <li key={index} className="skill-list__item">{skill}</li>
                                ))}
                            </ul>
                        ) : (
                            <p className="text-muted">No specific skills were identified as a direct match.</p>
                        )}
                    </div>
                </div>
                <div className="skill-gap-card">
                    <div className="skill-gap-card__header">🎯 Recommended Skills to Improve</div>
                    <div className="skill-gap-card__body">
                        {missingSkills.length > 0 ? (
                            <ul className="skill-list">
                                {missingSkills.map((skill, index) => (
                                    <li key={index} className="skill-list__item skill-list__item--has-action">
                                        <span>{skill}</span>
                                        <a 
                                            href={generateResourceLink(skill)} 
                                            target="_blank" 
                                            rel="noopener noreferrer" 
                                            className="badge badge--info"
                                        >
                                            Learn More
                                        </a>
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p className="alert alert--success">Great job! Your profile covers all the key required skills.</p>
                        )}
                    </div>
                </div>
            </div>
            <div className="back-button-container">
                <button className="btn btn-secondary" onClick={() => window.history.back()}>
                    Back to Status
                </button>
            </div>
        </div>
    );
};

export default SkillGapAnalysis;