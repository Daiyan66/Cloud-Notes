import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import api from '../api/axios';
import Spinner from '../components/Spinner'; // Import our custom Spinner
import '../styles/components/CandidateStatus.css'; // Import our custom CSS

const CandidateStatus = () => {
    const { data: applications = [], isLoading, error } = useQuery({
        queryKey: ['myApplications'],
        queryFn: () => api.get('/api/candidate/applications').then(res => res.data),
    });

    const getStatusBadge = (status) => {
        switch (status) {
            case 'ACCEPTED': return <span className="badge badge--success">Accepted</span>;
            case 'REJECTED': return <span className="badge badge--danger">Rejected</span>;
            case 'PENDING': return <span className="badge badge--warning">Pending</span>;
            default: return <span className="badge badge--secondary">{status}</span>;
        }
    };

    const getScoreBadge = (score) => {
        const displayScore = Math.round(score);
        if (displayScore >= 70) return <span className="badge badge--success">{displayScore}%</span>;
        if (displayScore >= 50) return <span className="badge badge--warning">{displayScore}%</span>;
        return <span className="badge badge--danger">{displayScore}%</span>;
    };
    
    const formatDate = (dateString) => {
        if (!dateString) return 'N/A';
        return new Date(dateString).toLocaleString();
    };

    if (isLoading) {
        return (
            <div className="candidate-status__loading">
                <Spinner size="3rem" />
            </div>
        );
    }

    if (error) {
        return <div className="alert alert--danger">Error loading your application status.</div>;
    }

    return (
        <div className="candidate-status">
            <h1 className="page-title">My Application Status</h1>
            <p className="page-subtitle">Track the status of your job applications.</p>
            
            {applications.length === 0 ? (
                <div className="alert alert--info">
                    You haven't applied for any jobs yet. <Link to="/browse-jobs">Browse jobs to get started!</Link>
                </div>
            ) : (
                <div className="status-table-wrapper">
                    <table className="status-table">
                        <thead>
                            <tr>
                                <th>Job Title</th>
                                <th>Match Score</th>
                                <th>Status</th>
                                <th>Applied On</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {applications.map((app) => (
                                <tr key={app.applicationId}>
                                    <td>{app.jobTitle}</td>
                                    <td>{getScoreBadge(app.matchScore)}</td>
                                    <td>{getStatusBadge(app.status)}</td>
                                    <td>{formatDate(app.appliedAt)}</td>
                                    <td>
                                        <Link to={`/candidate/analysis/${app.applicationId}`}>
                                            <button className="btn btn-primary">
                                                View Skill Analysis
                                            </button>
                                        </Link>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
};

export default CandidateStatus;