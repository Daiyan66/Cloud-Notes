import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import api from '../api/axios';
import Spinner from '../components/Spinner';
import '../styles/components/Dashboard.css'; // Make sure this file exists

const RecruiterDashboard = () => {
    const navigate = useNavigate();

    const { data: stats, isLoading, error } = useQuery({
        queryKey: ['recruiterStats'],
        queryFn: () => api.get('/api/recruiter/stats').then(res => res.data),
    });

    const { data: applications = [] } = useQuery({
        queryKey: ['recentApplications'],
        queryFn: () => api.get('/api/recruiter/applications/recent').then(res => res.data),
    });

    if (isLoading) return <div className="recruiter-dashboard"><div className="candidate-status__loading"><Spinner size="3rem" /></div></div>;
    if (error) return <div className="recruiter-dashboard"><div className="alert alert--danger">Error loading dashboard.</div></div>;

    const metricsData = [
        { label: 'Total Candidates', value: stats.totalCandidates || 0 },
        { label: 'Pending Applications', value: stats.pendingApplications || 0 },
        { label: 'Active Job Postings', value: stats.activeJobs || 0 },
        { label: 'New Resumes Today', value: stats.newResumesToday || 0 },
    ];

    return (
        <div className="recruiter-dashboard">
            <div>
                <h1 className="page-title">Recruiter Dashboard</h1>
                <p className="page-subtitle">Manage your job postings and track candidate applications.</p>
            </div>

            <div className="metrics-grid">
                {metricsData.map((metric, index) => (
                    <div key={index} className="metric-card">
                        <p className="metric-card__number">{metric.value}</p>
                        <p className="metric-card__label">{metric.label}</p>
                    </div>
                ))}
            </div>

            <div className="dashboard-content-grid">
                <div className="dashboard-card">
                    <div className="dashboard-card__header">Application Trend (Last 7 Days)</div>
                    <div className="dashboard-card__body">
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={stats.applicationTrend || []}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                                <XAxis dataKey="date" stroke="#757575" />
                                <YAxis stroke="#757575" />
                                <Tooltip 
                                    contentStyle={{ backgroundColor: '#ffffff', border: '1px solid #e0e0e0', borderRadius: '4px' }}
                                    labelStyle={{ color: '#212121' }}
                                />
                                <Legend />
                                <Bar dataKey="applications" fill="#3f51b5" />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                <div>
                    <div className="dashboard-card mb-3">
                        <div className="dashboard-card__header">Quick Actions</div>
                        <div className="dashboard-card__body">
                            <div className="quick-actions-grid">
                                <button className="btn btn-primary" onClick={() => navigate('/candidates')}>
                                    View All Candidates
                                </button>
                                <button className="btn btn-success" onClick={() => navigate('/upload-job')}>
                                    Post New Job
                                </button>
                                <button className="btn btn-secondary" onClick={() => navigate('/upload-job-form')}>
                                    Post Job via Form
                                </button>
                                <button className="btn btn-info" onClick={() => navigate('/upload-resumes')}>
                                    Upload Resumes
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className="dashboard-card">
                        <div className="dashboard-card__header">Recent Applications</div>
                        <div className="dashboard-card__body">
                            {applications.length > 0 ? (
                                <ul className="recent-activity-list">
                                    {applications.map(app => (
                                        <li key={app.applicationId}>
                                            <strong>{app.candidateName}</strong>
                                            <span> applied for Job ID: {app.jobId}</span>
                                            <small>
                                                Status: {app.status} | Match Score: {app.matchScore ? `${Math.round(app.matchScore * 100)}%` : 'N/A'}
                                            </small>
                                        </li>
                                    ))}
                                </ul>
                            ) : (
                                <p className="text-muted">No recent activity.</p>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default RecruiterDashboard;