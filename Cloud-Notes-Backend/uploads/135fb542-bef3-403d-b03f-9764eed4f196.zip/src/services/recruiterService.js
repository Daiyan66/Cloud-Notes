// frontend/src/services/recruiterService.js

// --- FIX: Import the configured api instance ---
import api from '../api/axios';

// --- FIX: The viewResume function now uses the 'api' instance ---
export const viewResume = async (resumeId) => {
    try {
        // IMPORTANT: responseType: 'blob' is crucial for handling files
        const response = await api.get(`api/files/resumes/${resumeId}`, {
            responseType: 'blob',
        });
        return response;
    } catch (error) {
        console.error("Error fetching resume file:", error);
        throw error;
    }
};

// --- FIX: All other functions now also use the 'api' instance for consistency ---
const recruiterService = {
  // Get candidates for a specific job
  getCandidatesForJob: async (jobId) => {
    try {
      const response = await api.get(`/recruiter/jobs/${jobId}/candidates`);
      return response.data;
    } catch (error) {
      console.error('Error fetching candidates:', error);
      throw error;
    }
  },

  // Accept an application
  acceptApplication: async (applicationId) => {
    try {
      const response = await api.post(`/recruiter/applications/${applicationId}/accept`);
      return response.data;
    } catch (error) {
      console.error('Error accepting application:', error);
      throw error;
    }
  },

  // Reject an application
  rejectApplication: async (applicationId) => {
    try {
      const response = await api.post(`/recruiter/applications/${applicationId}/reject`);
      return response.data;
    } catch (error) {
      console.error('Error rejecting application:', error);
      throw error;
    }
  },

  // Get all jobs
  getJobs: async () => {
    try {
      const response = await api.get(`/recruiter/jobs`);
      return response.data;
    } catch (error) {
      console.error('Error fetching jobs:', error);
      throw error;
    }
  }
};

export default recruiterService;