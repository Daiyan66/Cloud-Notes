import api from '../api/axios';

// Service for handling recruiter requests
const recruiterRequestService = {
  // Public: Submit a new request to become a recruiter
  createRequest: (requestData) => {
    // This correctly maps to the RecruiterRequestController
    return api.post('/api/recruiter-requests', requestData);
  },

  // Admin: Get all pending requests
  getPendingRequests: () => {
    // This correctly maps to the AdminController
    return api.get('/api/admin/recruiter-requests');
  },

  // Admin: Approve a request
  approveRequest: (requestId) => {
    // This correctly maps to the AdminController
    return api.post(`/api/admin/recruiter-requests/${requestId}/approve`);
  },

  // Admin: Reject a request
  rejectRequest: (requestId) => {
    // This correctly maps to the AdminController
    return api.post(`/api/admin/recruiter-requests/${requestId}/reject`);
  },

  // Public: Validate an invitation token
  validateInviteToken: (token) => {
    // --- FIX: Added the /api prefix ---
    // This now correctly maps to the AuthController
    return api.get(`/api/auth/invite/validate?token=${token}`);
  },

  // Public: Register a new user from an invite
  registerFromInvite: (registrationData) => {
    // --- FIX: Added the /api prefix ---
    // This now correctly maps to the AuthController
    return api.post('/api/auth/invite/register', registrationData);
  },
};

export default recruiterRequestService;