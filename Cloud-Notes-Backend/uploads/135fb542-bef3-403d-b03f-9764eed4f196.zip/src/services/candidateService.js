import api from '../api/axios';

// Gets all applications for the "My Status" page
export const getMyApplications = () => {
    return api.get('/api/candidate/applications').then(res => res.data);
};

// --- ADD THIS NEW FUNCTION ---
// Gets recommended jobs for the dashboard
export const getRecommendedJobs = () => {
    return api.get('/api/candidate/recommendations').then(res => res.data);
};