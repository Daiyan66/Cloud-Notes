import { createContext, useState, useContext, useEffect } from 'react';
import api from '../api/axios';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Check for existing token on app load
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      // Set the token for all subsequent API requests
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      
      api.get('/api/auth/me')
        .then(res => {
          // The backend returns { username, role }
          setUser(res.data);
        })
        .catch(() => {
          // If the token is invalid, remove it
          localStorage.removeItem('token');
          delete api.defaults.headers.common['Authorization'];
        })
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  // --- LOGIN FUNCTION (for standard login) ---
  const login = async (username, password) => {
    try {
      const res = await api.post('/api/auth/login', { username, password });
      console.log("LOGIN SUCCESS! Response from server:", res.data);
      const { token, username: loggedInUsername, role } = res.data;

      localStorage.setItem('token', token);
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;

      console.log("SETTING USER STATE TO:", { username: loggedInUsername, role });
      setUser({ username: loggedInUsername, role });
      
      return { username: loggedInUsername, role };
    } catch (error) {
      console.error("Login failed:", error);
      throw error;
    }
  };

  // --- REGISTER FUNCTION (for standard registration) ---
  const register = async (userData) => {
    // userData should be an object like { username, email, password }
    const res = await api.post('/api/auth/register', userData);
    const { token, username: registeredUsername, role } = res.data;

    // Store token and set default header for future requests
    localStorage.setItem('token', token);
    api.defaults.headers.common['Authorization'] = `Bearer ${token}`;

    // Update user state
    setUser({ username: registeredUsername, role });

    return { username: registeredUsername, role };
  };

  // --- NEW: LOGIN FROM INVITE FUNCTION ---
  const loginFromInvite = (token, username, role) => {
    console.log("LOGIN FROM INVITE! Setting user state to:", { username, role });
    
    // Store the token and set the default header
    localStorage.setItem('token', token);
    api.defaults.headers.common['Authorization'] = `Bearer ${token}`;

    // Update the user state directly, without a new API call
    setUser({ username, role });
  };

  const logout = () => {
    // Remove token from storage and API headers
    localStorage.removeItem('token');
    delete api.defaults.headers.common['Authorization'];
    
    // Clear user state
    setUser(null);
    
    // Redirect to login page
    window.location.href = '/login';
  };

  // Helper function to check if the user has a specific role
  const hasRole = (role) => user?.role === role;

  return (
    <AuthContext.Provider value={{ user, login, register, loginFromInvite, logout, hasRole, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);