// src/utils/constants.js

export const ROLES = {
  ADMIN: 'ADMIN',
  RECRUITER: 'RECRUITER',
  CANDIDATE: 'CANDIDATE'
};

export const EDUCATION_LEVELS = [
  'High-School',
  'Diploma',
  'Bachelor',
  'Master',
  'PhD',
];