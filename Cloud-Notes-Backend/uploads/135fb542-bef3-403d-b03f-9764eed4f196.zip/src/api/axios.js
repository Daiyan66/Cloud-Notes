// frontend/src/api/axios.js

import axios from 'axios';

const api = axios.create({
  // --- THIS LINE MUST BE EXACTLY THIS ---
  baseURL: 'http://localhost:8080', 
  
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' },
});

// request interceptor – attach JWT
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error)
);

// response interceptor – handle 401
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

export default api;