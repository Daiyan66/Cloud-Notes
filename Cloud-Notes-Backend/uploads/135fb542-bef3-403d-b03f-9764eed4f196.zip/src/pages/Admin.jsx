import React from 'react';
import { Container, Row, Col, Card } from 'react-bootstrap';
import { useQuery } from '@tanstack/react-query';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import api from '../api/axios';
import ManageRecruiterRequests from '../components/ManageRecruiterRequests'; // <-- NEW IMPORT

const AdminDashboard = () => {
    // Fetch comprehensive stats for the admin dashboard
    const { data: stats, isLoading, error } = useQuery({
        queryKey: ['adminStats'],
        queryFn: () => api.get('/api/admin/stats').then(res => res.data),
    });

    if (isLoading) return <div>Loading...</div>;
    if (error) return <div>Error loading admin dashboard.</div>;

    const userRoleData = [
        { name: 'Candidates', value: stats.totalCandidates || 0 },
        { name: 'Recruiters', value: stats.totalRecruiters || 0 },
        { name: 'Admins', value: stats.totalAdmins || 0 },
    ];
    const COLORS = ['#0088FE', '#00C49F', '#FFBB28'];

    return (
        <Container fluid className="my-4">
            <Row className="mb-4">
                <Col>
                    <h2>Admin Dashboard</h2>
                    <p className="text-muted">System overview and management.</p>
                </Col>
            </Row>

            {/* System Overview Cards */}
            <Row className="mb-4">
                <Col md={3}>
                    <Card className="text-center">
                        <Card.Body>
                            <h4>{stats.totalUsers || 0}</h4>
                            <p className="text-muted">Total Users</p>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={3}>
                    <Card className="text-center">
                        <Card.Body>
                            <h4>{stats.totalJobs || 0}</h4>
                            <p className="text-muted">Total Jobs</p>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={3}>
                    <Card className="text-center">
                        <Card.Body>
                            <h4>{stats.totalApplications || 0}</h4>
                            <p className="text-muted">Total Applications</p>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={3}>
                    <Card className="text-center">
                        <Card.Body>
                            <h4>{stats.totalResumes || 0}</h4>
                            <p className="text-muted">Total Resumes</p>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            {/* --- NEW SECTION FOR MANAGING REQUESTS --- */}
            <Row className="mb-4">
                <Col>
                    <ManageRecruiterRequests />
                </Col>
            </Row>

            <Row>
                {/* User Distribution Pie Chart */}
                <Col md={6}>
                    <Card>
                        <Card.Header as="h5">User Distribution by Role</Card.Header>
                        <Card.Body>
                            <ResponsiveContainer width="100%" height={300}>
                                <PieChart>
                                    <Pie
                                        data={userRoleData}
                                        cx="50%"
                                        cy="50%"
                                        labelLine={false}
                                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                                        outerRadius={80}
                                        fill="#8884d8"
                                        dataKey="value"
                                    >
                                        {userRoleData.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                        ))}
                                        </Pie>
                                    <Tooltip />
                                </PieChart>
                            </ResponsiveContainer>
                        </Card.Body>
                    </Card>
                </Col>

                {/* System Activity Line Chart */}
                <Col md={6}>
                    <Card>
                        <Card.Header as="h5">System Activity (Last 7 Days)</Card.Header>
                        <Card.Body>
                            <ResponsiveContainer width="100%" height={300}>
                                <LineChart data={stats.activityTrend || []}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="date" />
                                    <YAxis />
                                    <Tooltip />
                                    <Legend />
                                    <Line type="monotone" dataKey="registrations" stroke="#8884d8" activeDot={{ r: 8 }} />
                                    <Line type="monotone" dataKey="applications" stroke="#82ca9d" />
                                </LineChart>
                            </ResponsiveContainer>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
};

export default AdminDashboard;