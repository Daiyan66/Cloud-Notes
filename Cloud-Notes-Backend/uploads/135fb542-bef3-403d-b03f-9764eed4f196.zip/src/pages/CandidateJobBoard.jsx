import { useState } from 'react';
import { Container, Table, Button, Form, Alert, Card, ListGroup, Spinner, Modal } from 'react-bootstrap';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import api from '../api/axios';
import FileDrop from '../components/FileDrop';

const CandidateJobBoard = () => {
  const [filters, setFilters] = useState({ title: '', skills: '', education: '', expMin: '' });
  const [selectedJob, setSelectedJob] = useState(null);
  const [file, setFile] = useState(null);
  const [msg, setMsg] = useState({ text: '', type: 'warning' });
  const [showModal, setShowModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false); // <-- NEW: Loading state

  const params = new URLSearchParams(filters).toString();
  const { data: jobs = [], isLoading: isLoadingJobs } = useQuery({
    queryKey: ['jobs', params],
    queryFn: () => api.get(`/api/candidate/jobs?${params}`).then((r) => r.data),
  });

  const { data: recommendedJobs = [], isLoading: isLoadingRecommendations } = useQuery({
    queryKey: ['recommendedJobs'],
    queryFn: () => api.get('/api/candidate/recommendations').then(r => r.data),
    refetchInterval: 60000
  });

  const handleApply = async (jobId) => {
    if (!file) return setMsg({ text: 'Please upload your resume first.', type: 'warning' });
    
    setIsSubmitting(true); // <-- Start loading
    const form = new FormData();
    form.append('resume', file);
    form.append('jobId', jobId);
    try {
      const res = await api.post('/api/candidate/apply', form, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setMsg({ text: res.data.message, type: 'success' });
      setFile(null);
      setSelectedJob(null);
      setShowModal(false);
    } catch (e) {
      setMsg({ text: e.response?.data?.message || 'An unexpected error occurred.', type: 'danger' });
    } finally {
      setIsSubmitting(false); // <-- Stop loading, regardless of success or failure
    }
  };

  const openApplyModal = (job) => {
    setSelectedJob(job);
    setShowModal(true);
    setFile(null);
  };

  const closeApplyModal = () => {
    // Prevent closing if submission is in progress
    if (isSubmitting) return;
    setShowModal(false);
    setSelectedJob(null);
    setFile(null);
  };

  return (
    <Container className="mt-4">
      <h3>Candidate Home</h3>
      {msg.text && <Alert variant={msg.type} dismissible onClose={() => setMsg({ text: '', type: '' })}>{msg.text}</Alert>}

      <Card className="mb-4">
        <Card.Header as="h5">Recommended for You</Card.Header>
        <Card.Body>
          {isLoadingRecommendations ? (
            <div className="d-flex justify-content-center"><Spinner animation="border" /></div>
          ) : recommendedJobs.length > 0 ? (
            <ListGroup variant="flush">
              {recommendedJobs.map((job) => (
                <ListGroup.Item key={job.id} action>
                  <div>
                    <strong>{job.title}</strong>
                    <br />
                    <small className="text-muted">{job.skillsRequired}</small>
                  </div>
                  <Button onClick={() => openApplyModal(job)} variant="primary" size="sm">Apply</Button>
                </ListGroup.Item>
              ))}
            </ListGroup>
          ) : (
            <p className="text-muted">No new recommendations at the moment. Check back soon!</p>
          )}
        </Card.Body>
      </Card>

      <h4>Browse All Jobs</h4>
      <div className="row mb-3">
        <div className="col"><Form.Control placeholder="Title" value={filters.title} onChange={(e) => setFilters({ ...filters, title: e.target.value })} /></div>
        <div className="col"><Form.Control placeholder="Skills" value={filters.skills} onChange={(e) => setFilters({ ...filters, skills: e.target.value })} /></div>
        <div className="col"><Form.Control placeholder="Education" value={filters.education} onChange={(e) => setFilters({ ...filters, education: e.target.value })} /></div>
        <div className="col"><Form.Control type="number" placeholder="Min Exp" value={filters.expMin} onChange={(e) => setFilters({ ...filters, expMin: e.target.value })} /></div>
      </div>

      {isLoadingJobs ? <div className="p-3">Loading jobs…</div> : (
        <Table striped bordered hover responsive>
          <thead><tr><th>Title</th><th>Skills</th><th>Education</th><th>Experience</th><th>Action</th></tr></thead>
          <tbody>
            {jobs.map((j) => (
              <tr key={j.id}>
                <td>{j.title}</td><td>{j.skillsRequired}</td><td>{j.educationLevel}</td><td>{j.experienceRequired} yrs</td>
                <td><Button onClick={() => openApplyModal(j)} variant="primary" size="sm">Apply</Button></td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}

      {/* --- APPLICATION MODAL --- */}
      <Modal show={showModal} onHide={closeApplyModal} centered backdrop={isSubmitting ? 'static' : true}>
        <Modal.Header closeButton>
          <Modal.Title>Apply for: {selectedJob?.title}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedJob && (
            <>
              <div className="mb-3">
                <h6>Job Details</h6>
                <p><strong>Skills Required:</strong> {selectedJob.skillsRequired}</p>
                <p><strong>Education Level:</strong> {selectedJob.educationLevel}</p>
                <p><strong>Experience Required:</strong> {selectedJob.experienceRequired} years</p>
              </div>
              
              <h6>Upload Your Resume</h6>
              {/* Disable the file drop while submitting */}
              <div style={{ position: 'relative', opacity: isSubmitting ? 0.6 : 1 }}>
                <FileDrop 
                  onDrop={setFile} 
                  accept={{ 'application/pdf': ['.pdf'], 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'] }} 
                />
              </div>
              
              {file && (
                <div className="mt-3">
                  <Alert variant="info">
                    <p>Selected: {file.name}</p>
                    <Button 
                      onClick={() => handleApply(selectedJob.id)} 
                      variant="success"
                      disabled={isSubmitting} // <-- Disable button during submission
                    >
                      {isSubmitting ? (
                        <>
                          <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />
                          {' '}Submitting...
                        </>
                      ) : (
                        'Submit Application'
                      )}
                    </Button>
                  </Alert>
                </div>
              )}
            </>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={closeApplyModal} disabled={isSubmitting}>
            Cancel
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
};

export default CandidateJobBoard;