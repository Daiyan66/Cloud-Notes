import { useState } from 'react';
import { Container, Table, Button, Card, Tabs, Tab, Badge, Alert, Spinner } from 'react-bootstrap';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import api from '../api/axios';
import FilterBar from '../components/FilterBar';
import RejectModal from '../components/RejectModal';
import { viewResume } from '../services/recruiterService';

const Candidates = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const queryClient = useQueryClient();
  const [rejecting, setRejecting] = useState(null);
  const [sort, setSort] = useState(searchParams.get('sort') || 'score desc');
  const [activeTab, setActiveTab] = useState('all');
  const navigate = useNavigate();
  
  const jobId = searchParams.get('jobId');

  const filters = {
    skills: searchParams.get('skills'),
    experience: searchParams.get('experience'),
    education: searchParams.get('education'),
  };

  const { data: allCandidates = [], isLoading: allLoading, refetch: refetchAllCandidates } = useQuery({
    queryKey: ['candidates', filters, sort],
    queryFn: async () => {
      const params = new URLSearchParams({ sort, ...Object.fromEntries(Object.entries(filters).filter(([k, v]) => v != null)) });
      const res = await api.get(`/api/recruiter/candidates?${params}`);
      return res.data;
    },
    enabled: !jobId,
    keepPreviousData: true,
  });

  const { data: jobCandidates = [], isLoading: jobLoading, refetch: refetchJobCandidates } = useQuery({
    queryKey: ['jobCandidates', jobId],
    queryFn: async () => {
      const res = await api.get(`/api/recruiter/jobs/${jobId}/candidates`);
      return res.data;
    },
    enabled: !!jobId,
  });

  const candidates = jobId ? jobCandidates : allCandidates;
  const isLoading = jobId ? jobLoading : allLoading;

  const handleSort = (field) => {
    const [currentField, currentDir] = sort.split(' ');
    const dir = currentField === field && currentDir === 'asc' ? 'desc' : 'asc';
    const newSort = `${field} ${dir}`;
    setSort(newSort);
    setSearchParams({ ...Object.fromEntries(searchParams), sort: newSort }, { replace: true });
  };

  const SortIcon = ({ field }) => {
    const [f, d] = sort.split(' ');
    if (f !== field) return <span className="ms-1 text-muted">↕</span>;
    return <span className="ms-1">{d === 'asc' ? '↑' : '↓'}</span>;
  };

  const handleReject = (candidate) => {
    setRejecting(candidate);
  };

  const sendRejection = async (applicationId, feedback) => {
    const params = new URLSearchParams({
      feedback,
      accepted: 'false',
      sendMail: 'true',
    });
    await api.put(`/api/recruiter/applications/${applicationId}?${params}`);
    queryClient.invalidateQueries(['candidates']);
    if (jobId) {
      queryClient.invalidateQueries(['jobCandidates']);
    }
  };

  const handleAccept = async (applicationId) => {
    try {
      await api.post(`/recruiter/applications/${applicationId}/accept`);
      queryClient.invalidateQueries(['candidates']);
      if (jobId) {
        queryClient.invalidateQueries(['jobCandidates']);
      }
    } catch (error) {
      console.error('Error accepting application:', error);
    }
  };

  const handleViewResume = async (resumeId) => {
    try {
      const response = await viewResume(resumeId);
      const fileURL = URL.createObjectURL(response.data);
      window.open(fileURL, '_blank');
    } catch (error) {
      console.error("Failed to view resume:", error);
      alert("Could not open the resume. Please try again later.");
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'ACCEPTED': return <Badge bg="success">Accepted</Badge>;
      case 'REJECTED': return <Badge bg="danger">Rejected</Badge>;
      case 'PENDING': return <Badge bg="warning">Pending</Badge>;
      default: return <Badge bg="secondary">{status}</Badge>;
    }
  };

  const getScoreBadge = (score) => {
    let displayScore = Math.round(score);
    if (displayScore >= 70) {
        return <Badge bg="success">{displayScore}%</Badge>;
    } else if (displayScore >= 50) {
        return <Badge bg="warning">{displayScore}%</Badge>;
    } else {
        return <Badge bg="danger">{displayScore}%</Badge>;
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (isLoading) {
    return (
      <div className="d-flex justify-content-center my-5">
        <Spinner animation="border" role="status">
          <span className="visually-hidden">Loading...</span>
        </Spinner>
      </div>
    );
  }

  return (
    <Container className="mt-4">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h3>{jobId ? 'Candidates for this Job' : 'All Candidates'}</h3>
        {jobId && (
          <Button variant="outline-secondary" onClick={() => navigate('/recruiter/candidates')}>
            View All Candidates
          </Button>
        )}
      </div>

      {jobId && (
        <Alert variant="info">
          Showing candidates who have applied for this specific job. 
          <Button variant="link" className="p-0 ms-1" onClick={() => setActiveTab('all')}>
            View all candidates instead
          </Button>
        </Alert>
      )}

      <FilterBar />

      <Table striped bordered hover responsive className="mt-3">
        <thead>
          <tr>
            <th style={{ cursor: 'pointer' }} onClick={() => handleSort('score')}>
              Score <SortIcon field="score" />
            </th>
            <th>Name</th>
            <th>Email</th>
            <th style={{ cursor: 'pointer' }} onClick={() => handleSort('experience')}>
              Experience <SortIcon field="experience" />
            </th>
            <th style={{ cursor: 'pointer' }} onClick={() => handleSort('education')}>
              Education <SortIcon field="education" />
            </th>
            <th>Skills</th>
            {jobId && <th>Applied At</th>}
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {candidates.length === 0 ? (
            <tr>
              <td colSpan={jobId ? "9" : "8"} className="text-center">
                {jobId ? 'No candidates have applied for this job yet.' : 'No candidates found.'}
              </td>
            </tr>
          ) : (
            candidates.map((c) => (
              <tr key={c.id || c.applicationId}>
                <td>{getScoreBadge(c.matchScore)}</td>
                <td>{c.candidateName}</td>
                <td>{c.email}</td>
                <td>{c.experience} yrs</td>
                <td>{c.education}</td>
                <td>
                  <div style={{ maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {Array.isArray(c.skills) ? c.skills.join(', ') : c.skills}
                  </div>
                </td>
                {jobId && <td>{formatDate(c.createdAt || c.appliedAt)}</td>}
                <td>{c.status ? getStatusBadge(c.status) : <Badge bg="secondary">Unknown</Badge>}</td>
                <td>
                  <Button 
                    size="sm" 
                    variant="outline-primary" 
                    className="me-2"
                    onClick={() => handleViewResume(c.resumeId)}
                  >
                    View Resume
                  </Button>
                  {jobId && (
                    <Button
                      size="sm"
                      variant="outline-success"
                      className="me-2"
                      disabled={c.status === 'ACCEPTED' || c.status === 'REJECTED'}
                      onClick={() => handleAccept(c.applicationId)}
                    >
                      Accept
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="outline-danger"
                    disabled={c.status === 'ACCEPTED' || c.status === 'REJECTED'}
                    onClick={() => handleReject(c)}
                  >
                    Reject
                  </Button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </Table>

      {rejecting && (
        <RejectModal
          show={!!rejecting}
          onHide={() => setRejecting(null)}
          candidate={rejecting}
          onSend={(feedback) => sendRejection(rejecting.applicationId, feedback)}
        />
      )}
    </Container>
  );
};

export default Candidates;