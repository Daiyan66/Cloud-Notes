import React from 'react';
export default function XXX() { return <div>XXX page</div>; }