import React from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import api from '../api/axios';

const RecruiterDashboard = () => {
    const navigate = useNavigate();

    // Fetch key stats for the dashboard
    const { data: stats, isLoading, error } = useQuery({
        queryKey: ['recruiterStats'],
        queryFn: () => api.get('/api/recruiter/stats').then(res => res.data),
    });

    // Fetch recent applications
    const { data: applications = [] } = useQuery({
        queryKey: ['recentApplications'],
        queryFn: () => api.get('/api/recruiter/applications/recent').then(res => res.data),
    });

    if (isLoading) return <div>Loading...</div>;
    if (error) return <div>Error loading dashboard.</div>;

    return (
        <Container fluid className="my-4">
            <Row className="mb-4">
                <Col>
                    <h2>Recruiter Dashboard</h2>
                    <p className="text-muted">Manage your job postings and track candidate applications.</p>
                </Col>
            </Row>

            {/* Key Metrics */}
            <Row className="mb-4">
                <Col md={3}>
                    <Card className="text-center">
                        <Card.Body>
                            <h2>{stats.totalCandidates || 0}</h2>
                            <p className="text-muted">Total Candidates</p>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={3}>
                    <Card className="text-center">
                        <Card.Body>
                            <h2>{stats.pendingApplications || 0}</h2>
                            <p className="text-muted">Pending Applications</p>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={3}>
                    <Card className="text-center">
                        <Card.Body>
                            <h2>{stats.activeJobs || 0}</h2>
                            <p className="text-muted">Active Job Postings</p>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={3}>
                    <Card className="text-center">
                        <Card.Body>
                            <h2>{stats.newResumesToday || 0}</h2>
                            <p className="text-muted">New Resumes Today</p>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            <Row>
                {/* Application Trend Chart */}
                <Col md={8}>
                    <Card>
                        <Card.Header as="h5">Application Trend (Last 7 Days)</Card.Header>
                        <Card.Body>
                            <ResponsiveContainer width="100%" height={300}>
                                <BarChart data={stats.applicationTrend || []}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="date" />
                                    <YAxis />
                                    <Tooltip />
                                    <Legend />
                                    <Bar dataKey="applications" fill="#8884d8" />
                                </BarChart>
                            </ResponsiveContainer>
                        </Card.Body>
                    </Card>
                </Col>

                {/* Quick Actions & Recent Activity */}
                <Col md={4}>
                    <Card className="mb-3">
                        <Card.Header as="h5">Quick Actions</Card.Header>
                        <Card.Body>
                            <Button variant="primary" className="w-100 mb-2" onClick={() => navigate('/candidates')}>
                                View All Candidates
                            </Button>
                            <Button variant="success" className="w-100 mb-2" onClick={() => navigate('/upload-job')}>
                                Post New Job
                            </Button>
                            {/* --- NEW BUTTON ADDED HERE --- */}
                            <Button variant="secondary" className="w-100 mb-2" onClick={() => navigate('/upload-job-form')}>
                                Post Job via Form
                            </Button>
                            <Button variant="info" className="w-100" onClick={() => navigate('/upload-resumes')}>
                                Upload Resumes
                            </Button>
                        </Card.Body>
                    </Card>
                    <Card>
                        <Card.Header as="h5">Recent Applications</Card.Header>
                        <Card.Body>
                            {applications.length > 0 ? (
                                <ul className="list-unstyled">
                                    {applications.map(app => (
                                        <li key={app.applicationId} className="mb-2">
                                            <div>
                                                <strong>{app.candidateName}</strong>
                                                <span className="text-muted"> applied for Job ID: {app.jobId}</span>
                                            </div>
                                            <small className="text-muted">
                                                Status: {app.status} | Match Score: {app.matchScore ? `${Math.round(app.matchScore * 100)}%` : 'N/A'}
                                            </small>
                                        </li>
                                    ))}
                                </ul>
                            ) : (
                                <p className="text-muted">No recent activity.</p>
                            )}
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
};

export default RecruiterDashboard;