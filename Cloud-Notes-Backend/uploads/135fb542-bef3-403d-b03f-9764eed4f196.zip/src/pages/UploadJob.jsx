import { useState } from 'react';
import { Container, Button, Alert } from 'react-bootstrap';
import FileDrop from '../components/FileDrop';
import api from '../api/axios';

const UploadJob = () => {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [msg, setMsg] = useState({ text: '', type: '' });

  const handleUpload = async () => {
    if (!file) return;
    setUploading(true);
    const form = new FormData();
    form.append('file', file);
    try {
      const res = await api.post('/api/recruiter/jobs', form, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setMsg({ text: `Job uploaded. ID: ${res.data.jobId}`, type: 'success' });
      setFile(null);
    } catch (e) {
      setMsg({ text: e.response?.data?.message || 'Upload failed', type: 'danger' });
    } finally {
      setUploading(false);
    }
  };

  return (
    <Container className="mt-4">
      <h3>Upload Job Description</h3>
      {msg.text && <Alert variant={msg.type}>{msg.text}</Alert>}
      <FileDrop
  onDrop={setFile}
  accept={{
    'application/pdf': ['.pdf'],
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
    'text/plain': ['.txt']          // ← NEW
  }}
  uploading={uploading}
/>
      {file && (
        <div className="mt-3">
          <p>Selected: {file.name}</p>
          <Button onClick={handleUpload} disabled={uploading}>
            {uploading ? 'Uploading…' : 'Upload'}
          </Button>
        </div>
      )}
    </Container>
  );
};

export default UploadJob;