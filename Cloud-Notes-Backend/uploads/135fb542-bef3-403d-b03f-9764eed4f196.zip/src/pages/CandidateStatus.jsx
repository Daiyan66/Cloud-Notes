import { useQuery } from '@tanstack/react-query';
import { Container, Card, Badge, Button, Spinner, Alert, Table } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import api from '../api/axios';

const CandidateStatus = () => {
    const { data: applications = [], isLoading, error } = useQuery({
        queryKey: ['myApplications'],
        queryFn: () => api.get('/api/candidate/applications').then(res => res.data),
    });

    const getStatusBadge = (status) => {
        switch (status) {
            case 'ACCEPTED': return <Badge bg="success">Accepted</Badge>;
            case 'REJECTED': return <Badge bg="danger">Rejected</Badge>;
            case 'PENDING': return <Badge bg="warning">Pending</Badge>;
            default: return <Badge bg="secondary">{status}</Badge>;
        }
    };

    const getScoreBadge = (score) => {
        const displayScore = Math.round(score);
        if (displayScore >= 70) return <Badge bg="success">{displayScore}%</Badge>;
        if (displayScore >= 50) return <Badge bg="warning">{displayScore}%</Badge>;
        return <Badge bg="danger">{displayScore}%</Badge>;
    };
    
    const formatDate = (dateString) => {
        if (!dateString) return 'N/A';
        return new Date(dateString).toLocaleString();
    };

    if (isLoading) {
        return (
            <div className="d-flex justify-content-center my-5">
                <Spinner animation="border" role="status" />
            </div>
        );
    }

    if (error) {
        return <Alert variant="danger">Error loading your application status.</Alert>;
    }

    return (
        <Container className="mt-4">
            <h3>My Application Status</h3>
            <p className="text-muted">Track the status of your job applications.</p>
            
            {applications.length === 0 ? (
                <Alert variant="info">
                    You haven't applied for any jobs yet. <Link to="/browse-jobs">Browse jobs to get started!</Link>
                </Alert>
            ) : (
                <Table striped bordered hover responsive>
                    <thead>
                        <tr>
                            <th>Job Title</th>
                            <th>Match Score</th>
                            <th>Status</th>
                            <th>Applied On</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {applications.map((app) => (
                            <tr key={app.applicationId}>
                                <td>{app.jobTitle}</td>
                                <td>{getScoreBadge(app.matchScore)}</td>
                                <td>{getStatusBadge(app.status)}</td>
                                <td>{formatDate(app.appliedAt)}</td>
                                <td>
                                    {/* --- THIS IS THE "SPECIFIC ANALYSIS" BUTTON --- */}
                                    <Link to={`/candidate/analysis/${app.applicationId}`}>
                                        <Button variant="primary" size="sm">
                                            View Skill Analysis
                                        </Button>
                                    </Link>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
            )}
        </Container>
    );
};

export default CandidateStatus;