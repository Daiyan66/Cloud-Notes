// src/pages/AddRecruiter.jsx

import { useState } from 'react';
import { Form, Button, Container, Row, Col, Alert, Card } from 'react-bootstrap';
import { useAuth } from '../auth/AuthProvider';
import api from '../api/axios';

const AddRecruiter = () => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState({ text: '', type: '' });

  // Simple frontend guard to prevent non-admins from seeing the form
  if (user?.role !== 'admin') {
    return (
      <Container className="mt-5">
        <Alert variant="danger">
          You don't have permission to access this page.
        </Alert>
      </Container>
    );
  }

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage({ text: '', type: '' });
    
    try {
      // This will call the new backend endpoint we need to create
      const response = await api.post('/api/admin/add-recruiter', formData);
      setMessage({ 
        text: `Success! Recruiter account created for ${formData.name}. Login credentials have been sent to ${formData.email}.`, 
        type: 'success' 
      });
      // Reset the form
      setFormData({ name: '', email: '', company: '' });
    } catch (error) {
      setMessage({ 
        text: error.response?.data?.message || 'Failed to create recruiter account.', 
        type: 'danger' 
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Container className="mt-5">
      <Row className="justify-content-md-center">
        <Col md={8} lg={6}>
          <Card>
            <Card.Header as="h4">Add New Recruiter</Card.Header>
            <Card.Body>
              <p className="text-muted">
                Fill in the details below to create an account for a new recruiter. 
                They will receive an email with their login credentials.
              </p>
              
              {message.text && <Alert variant={message.type}>{message.text}</Alert>}
              
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3">
                  <Form.Label>Recruiter's Full Name</Form.Label>
                  <Form.Control
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="e.g., Jane Doe"
                    required
                  />
                </Form.Group>
                
                <Form.Group className="mb-3">
                  <Form.Label>Work Email Address</Form.Label>
                  <Form.Control
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="e.g., jane.doe@company.com"
                    required
                  />
                </Form.Group>
                
                <Form.Group className="mb-3">
                  <Form.Label>Company Name</Form.Label>
                  <Form.Control
                    type="text"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    placeholder="e.g., Tech Corp"
                    required
                  />
                </Form.Group>
                
                <Button 
                  variant="primary" 
                  type="submit" 
                  disabled={isLoading}
                  className="w-100"
                >
                  {isLoading ? 'Creating Account...' : 'Create Recruiter Account & Send Invite'}
                </Button>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default AddRecruiter;