import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Container, Card, ListGroup, Badge, Spinner, Alert, Button, Row, Col } from 'react-bootstrap';
import api from '../api/axios';

const SkillGapAnalysis = () => {
    const { applicationId } = useParams();

    const { data: analysis, isLoading, error } = useQuery({
        queryKey: ['skillGapAnalysis', applicationId],
        queryFn: () => api.get(`/api/candidate/analysis/${applicationId}`).then(res => res.data),
        enabled: !!applicationId,
    });

    const generateResourceLink = (skill) => {
        return `https://www.google.com/search?q=learn+${encodeURIComponent(skill)}`;
    };

    if (isLoading) {
        return (
            <div className="d-flex justify-content-center my-5">
                <Spinner animation="border" role="status" />
            </div>
        );
    }

    if (error) {
        return <Alert variant="danger">Error loading skill analysis. This application might not have detailed data available.</Alert>;
    }
    
    if (!analysis || !analysis.rawSkillGapJson) {
        return <Alert variant="info">No detailed skill gap analysis is available for this application.</Alert>;
    }

    let skillGap = {};
    try {
        skillGap = JSON.parse(analysis.rawSkillGapJson);
    } catch (e) {
        return <Alert variant="warning">Could not parse the skill analysis data.</Alert>;
    }

    const { matchedSkills = [], missingSkills = [] } = skillGap;

    return (
        <Container className="mt-4">
            <h3>Skill Gap Analysis</h3>
            <p className="text-muted">Detailed breakdown for your application to: <strong>{analysis.jobTitle}</strong></p>
            
            <Row className="mt-4">
                <Col md={6}>
                    <Card>
                        <Card.Header as="h5">✅ Your Matched Skills</Card.Header>
                        <Card.Body>
                            {matchedSkills.length > 0 ? (
                                <ListGroup variant="flush">
                                    {matchedSkills.map((skill, index) => (
                                        <ListGroup.Item key={index}>{skill}</ListGroup.Item>
                                    ))}
                                </ListGroup>
                            ) : (
                                <p className="text-muted">No specific skills were identified as a direct match.</p>
                            )}
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={6}>
                    <Card>
                        <Card.Header as="h5">🎯 Recommended Skills to Improve</Card.Header>
                        <Card.Body>
                            {missingSkills.length > 0 ? (
                                <ListGroup variant="flush">
                                    {missingSkills.map((skill, index) => (
                                        <ListGroup.Item key={index} className="d-flex justify-content-between align-items-center">
                                            <span>{skill}</span>
                                            <Badge bg="info" as="a" href={generateResourceLink(skill)} target="_blank" rel="noopener noreferrer" style={{ cursor: 'pointer' }}>
                                                Learn More
                                            </Badge>
                                        </ListGroup.Item>
                                    ))}
                                </ListGroup>
                            ) : (
                                <p className="text-success">Great job! Your profile covers all the key required skills.</p>
                            )}
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
            <div className="mt-4">
                <Button variant="secondary" onClick={() => window.history.back()}>
                    Back to Status
                </Button>
            </div>
        </Container>
    );
};

export default SkillGapAnalysis;