import { useForm } from 'react-hook-form';
import { Link, useNavigate } from 'react-router-dom';
import { Form, Button, Container, Row, Col, Alert, Card } from 'react-bootstrap';
import { useState } from 'react';
import recruiterRequestService from '../services/recruiterRequestService';

const RequestRecruiterAccessPage = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const onSubmit = async (data) => {
    setIsLoading(true);
    setMessage('');
    try {
      await recruiterRequestService.createRequest(data);
      setMessage('Your request has been submitted successfully! The admin will review it shortly.');
      // Optional: redirect after a few seconds
      setTimeout(() => navigate('/login'), 5000);
    } catch (error) {
      setMessage(error.response?.data?.message || 'An error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Container className="mt-5" style={{ maxWidth: '600px' }}>
      <Card>
        <Card.Body>
          <h2 className="text-center mb-4">Request Recruiter Access</h2>
          <p className="text-muted text-center">
            Please fill out the form below to request access to the recruitment platform.
          </p>
          
          {message && <Alert variant={message.includes('successfully') ? 'success' : 'danger'}>{message}</Alert>}
          
          <Form onSubmit={handleSubmit(onSubmit)}>
            {/* --- FIX: Ask for First Name and Last Name separately --- */}
            <Row>
              <Col md={6}>
                <Form.Group className="mb-3" controlId="formFirstName">
                  <Form.Label>First Name</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter your first name"
                    {...register('firstName', { required: 'First name is required' })}
                    isInvalid={!!errors.firstName}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.firstName?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>

              <Col md={6}>
                <Form.Group className="mb-3" controlId="formLastName">
                  <Form.Label>Last Name</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter your last name"
                    {...register('lastName', { required: 'Last name is required' })}
                    isInvalid={!!errors.lastName}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.lastName?.message}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>

            <Form.Group className="mb-3" controlId="formEmail">
              <Form.Label>Email Address</Form.Label>
              <Form.Control
                type="email"
                placeholder="Enter your email"
                {...register('email', { required: 'Email is required' })}
                isInvalid={!!errors.email}
              />
              <Form.Control.Feedback type="invalid">
                {errors.email?.message}
              </Form.Control.Feedback>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formCompany">
              <Form.Label>Company</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter your company name"
                {...register('company', { required: 'Company is required' })}
                isInvalid={!!errors.company}
              />
              <Form.Control.Feedback type="invalid">
                {errors.company?.message}
              </Form.Control.Feedback>
            </Form.Group>
            
            <Form.Group className="mb-3" controlId="formMessage">
              <Form.Label>Message (Optional)</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                placeholder="Any additional information for the admin..."
                {...register('message')}
              />
            </Form.Group>
            
            <Button variant="primary" type="submit" className="w-100" disabled={isLoading}>
              {isLoading ? 'Submitting...' : 'Submit Request'}
            </Button>
          </Form>

          <div className="text-center mt-3">
            <span>Already have an account? </span>
            <Link to="/login">Sign In</Link>
          </div>
        </Card.Body>
      </Card>
    </Container>
  );
};

export default RequestRecruiterAccessPage;