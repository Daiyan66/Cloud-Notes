// src/pages/RegisterPage.jsx

import { useForm } from 'react-hook-form';
import { useAuth } from '../auth/AuthProvider';
import { useNavigate, Link } from 'react-router-dom';
import { Form, Button, Container, Row, Col, Alert, Card } from 'react-bootstrap';
import { useState } from 'react';

const RegisterPage = () => {
  const { register, handleSubmit, formState: { errors }, watch } = useForm();
  const { register: registerUser } = useAuth();
  const nav = useNavigate();
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const password = watch('password'); // Watch password value for confirmation

  const onSubmit = async (data) => {
    setIsLoading(true);
    setError('');
    try {
      // The registerUser function in AuthProvider now handles the role automatically
      await registerUser(data);
      nav('/'); // --- FIX: Redirect to dashboard after successful registration
    } catch (e) {
      setError(e.response?.data?.message || 'Registration failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Container fluid className="vh-100 p-0 overflow-hidden">
      <Row className="h-100 g-0">
        {/* Left Side - Registration Form (40%) */}
        <Col md={5} className="d-flex flex-column justify-content-center align-items-center bg-light p-4">
          <div className="w-100" style={{ maxWidth: '400px' }}>
            <div className="text-center mb-4">
              <h2 className="fw-bold">Create Account</h2>
              <p className="text-muted">Join our platform as a candidate</p>
            </div>
            
            {error && <Alert variant="danger">{error}</Alert>}
            
            <Form onSubmit={handleSubmit(onSubmit)}>
              {/* --- NEW: First Name and Last Name Fields --- */}
              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3" controlId="formFirstName">
                    <Form.Label>First Name</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="First name"
                      {...register('firstName', { required: 'First name is required' })}
                      isInvalid={!!errors.firstName}
                    />
                    <Form.Control.Feedback type="invalid">
                      {errors.firstName?.message}
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3" controlId="formLastName">
                    <Form.Label>Last Name</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Last name"
                      {...register('lastName', { required: 'Last name is required' })}
                      isInvalid={!!errors.lastName}
                    />
                    <Form.Control.Feedback type="invalid">
                      {errors.lastName?.message}
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>
              </Row>

              {/* --- FIX: Changed from 'name' to 'username' --- */}
              <Form.Group className="mb-3" controlId="formUsername">
                <Form.Label>Username</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Choose a username"
                  {...register('username', { required: 'Username is required' })}
                  isInvalid={!!errors.username}
                />
                <Form.Control.Feedback type="invalid">
                  {errors.username?.message}
                </Form.Control.Feedback>
              </Form.Group>

              <Form.Group className="mb-3" controlId="formEmail">
                <Form.Label>Email</Form.Label>
                <Form.Control
                  type="email"
                  placeholder="Enter your email"
                  {...register('email', { 
                    required: 'Email is required',
                    pattern: {
                      value: /^\S+@\S+$/i,
                      message: "Invalid email address"
                    }
                  })}
                  isInvalid={!!errors.email}
                />
                <Form.Control.Feedback type="invalid">
                  {errors.email?.message}
                </Form.Control.Feedback>
              </Form.Group>
              
              <Form.Group className="mb-3" controlId="formPassword">
                <Form.Label>Password</Form.Label>
                <Form.Control
                  type="password"
                  placeholder="Create a password"
                  {...register('password', { 
                    required: 'Password is required',
                    minLength: {
                      value: 6,
                      message: "Password must be at least 6 characters"
                    }
                  })}
                  isInvalid={!!errors.password}
                />
                <Form.Control.Feedback type="invalid">
                  {errors.password?.message}
                </Form.Control.Feedback>
              </Form.Group>
              
              <Form.Group className="mb-3" controlId="formConfirmPassword">
                <Form.Label>Confirm Password</Form.Label>
                <Form.Control
                  type="password"
                  placeholder="Confirm your password"
                  {...register('confirmPassword', { 
                    required: 'Please confirm your password',
                    validate: value => value === password || "Passwords do not match"
                  })}
                  isInvalid={!!errors.confirmPassword}
                />
                <Form.Control.Feedback type="invalid">
                  {errors.confirmPassword?.message}
                </Form.Control.Feedback>
              </Form.Group>
              
              <Button 
                variant="primary" 
                type="submit" 
                className="w-100 py-2 mb-3"
                disabled={isLoading}
              >
                {isLoading ? 'Creating Account...' : 'Create Account'}
              </Button>
              
              <div className="text-center">
                <span className="text-muted">Already have an account? </span>
                <Link to="/login" className="text-decoration-none">Sign in here</Link>
              </div>
            </Form>
          </div>
        </Col>
        
        {/* Right Side - Features (60%) */}
        <Col md={7} className="d-none d-md-flex flex-column justify-content-center text-white p-5" style={{ backgroundColor: '#e3f2fd' }}>
          <div className="mb-5">
            <h1 className="display-4 fw-bold mb-4 text-dark">Join Our Talent Community</h1>
            <p className="lead text-dark">Create an account to access job opportunities tailored to your skills and experience.</p>
          </div>
          
          <Row className="g-4">
            <Col md={6}>
              <Card className="bg-white text-dark mb-4 h-100 shadow-sm">
                <Card.Body>
                  <div className="d-flex align-items-center mb-3">
                    <div className="rounded-circle bg-info d-flex align-items-center justify-content-center me-3" style={{ width: '50px', height: '50px' }}>
                      <i className="bi bi-person-check fs-4 text-white"></i>
                    </div>
                    <h4 className="mb-0">Create Your Profile</h4>
                  </div>
                  <p>Build a comprehensive profile showcasing your skills, experience, and qualifications.</p>
                </Card.Body>
              </Card>
            </Col>
            
            <Col md={6}>
              <Card className="bg-white text-dark mb-4 h-100 shadow-sm">
                <Card.Body>
                  <div className="d-flex align-items-center mb-3">
                    <div className="rounded-circle bg-info d-flex align-items-center justify-content-center me-3" style={{ width: '50px', height: '50px' }}>
                      <i className="bi bi-search fs-4 text-white"></i>
                    </div>
                    <h4 className="mb-0">Find Jobs</h4>
                  </div>
                  <p>Discover job opportunities that match your skills and career aspirations.</p>
                </Card.Body>
              </Card>
            </Col>
            
            <Col md={6}>
              <Card className="bg-white text-dark mb-4 h-100 shadow-sm">
                <Card.Body>
                  <div className="d-flex align-items-center mb-3">
                    <div className="rounded-circle bg-info d-flex align-items-center justify-content-center me-3" style={{ width: '50px', height: '50px' }}>
                      <i className="bi bi-file-earmark-text fs-4 text-white"></i>
                    </div>
                    <h4 className="mb-0">Upload Resume</h4>
                  </div>
                  <p>Upload your resume for AI-powered analysis and personalized job recommendations.</p>
                </Card.Body>
              </Card>
            </Col>
            
            <Col md={6}>
              <Card className="bg-white text-dark mb-4 h-100 shadow-sm">
                <Card.Body>
                  <div className="d-flex align-items-center mb-3">
                    <div className="rounded-circle bg-info d-flex align-items-center justify-content-center me-3" style={{ width: '50px', height: '50px' }}>
                      <i className="bi bi-graph-up fs-4 text-white"></i>
                    </div>
                    <h4 className="mb-0">Track Applications</h4>
                  </div>
                  <p>Monitor the status of your job applications and receive updates in real-time.</p>
                </Card.Body>
              </Card>
            </Col>
          </Row>
          
          <div className="mt-5 text-center">
            <h3 className="mb-3 text-dark">Join Thousands of Job Seekers</h3>
            <p className="text-dark">Start your journey to a fulfilling career today</p>
          </div>
        </Col>
      </Row>
    </Container>
  );
};

export default RegisterPage;