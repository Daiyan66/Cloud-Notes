import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Container, Card, Form, Button, Alert, Spinner } from 'react-bootstrap';
import { useAuth } from '../auth/AuthProvider';
import recruiterRequestService from '../services/recruiterRequestService';

const InviteRegistrationPage = () => {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  const navigate = useNavigate();
  const { loginFromInvite } = useAuth(); // <-- USE THE NEW FUNCTION

  const { register, handleSubmit, formState: { errors }, setValue, watch } = useForm(); 
  
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [isValidToken, setIsValidToken] = useState(false);

  useEffect(() => {
    if (!token) {
      setError('Invalid invitation link. No token provided.');
      setIsLoading(false);
      return;
    }

    const validateToken = async () => {
      try {
        const response = await recruiterRequestService.validateInviteToken(token);
        setValue('email', response.data.email);
        setIsValidToken(true);
      } catch (err) {
        setError('This invitation link is invalid or has expired.');
      } finally {
        setIsLoading(false);
      }
    };

    validateToken();
  }, [token, setValue]);

  const onSubmit = async (data) => {
    setIsSubmitting(true);
    setError('');
    try {
      const registrationPayload = { token, password: data.password };
      const response = await recruiterRequestService.registerFromInvite(registrationPayload);
      
      // --- FIX: Use the new loginFromInvite function ---
      // It takes the token and user info from the registration response
      // and sets the auth state without making another API call.
      loginFromInvite(response.data.token, response.data.username, response.data.role);
      
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <Container className="d-flex justify-content-center align-items-center" style={{ height: '80vh' }}>
        <Spinner animation="border" />
      </Container>
    );
  }

  if (error || !isValidToken) {
    return (
      <Container className="mt-5" style={{ maxWidth: '500px' }}>
        <Alert variant="danger">{error}</Alert>
      </Container>
    );
  }

  return (
    <Container className="mt-5" style={{ maxWidth: '500px' }}>
      <Card>
        <Card.Body>
          <h2 className="text-center mb-4">Set Your Password</h2>
          <p className="text-muted text-center mb-4">
            Your email is confirmed. Please create a password to complete your registration.
          </p>
          
          <Form onSubmit={handleSubmit(onSubmit)}>
            <Form.Group className="mb-3" controlId="formEmail">
              <Form.Label>Email address</Form.Label>
              <Form.Control
                type="email"
                {...register('email')}
                disabled
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formPassword">
              <Form.Label>Password</Form.Label>
              <Form.Control
                type="password"
                placeholder="Enter your password"
                {...register('password', { 
                    required: 'Password is required',
                    minLength: { value: 6, message: 'Password must be at least 6 characters long' }
                })}
                isInvalid={!!errors.password}
              />
              <Form.Control.Feedback type="invalid">
                {errors.password?.message}
              </Form.Control.Feedback>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formConfirmPassword">
              <Form.Label>Confirm Password</Form.Label>
              <Form.Control
                type="password"
                placeholder="Confirm your password"
                {...register('confirmPassword', { 
                    required: 'Please confirm your password',
                    validate: value => value === watch('password') || "Passwords do not match" // watch is now available
                })}
                isInvalid={!!errors.confirmPassword}
              />
              <Form.Control.Feedback type="invalid">
                {errors.confirmPassword?.message}
              </Form.Control.Feedback>
            </Form.Group>
            
            <Button variant="primary" type="submit" className="w-100" disabled={isSubmitting}>
              {isSubmitting ? 'Registering...' : 'Register & Log In'}
            </Button>
          </Form>
        </Card.Body>
      </Card>
    </Container>
  );
};

export default InviteRegistrationPage;