import { useParams } from 'react-router-dom';
import { Container, Table, Button, Badge } from 'react-bootstrap';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import api from '../api/axios';

const RecruiterApplications = () => {
  const { jobId } = useParams();
  const queryClient = useQueryClient();

  const { data: apps = [], isLoading } = useQuery({
    queryKey: ['applications', jobId],
    queryFn: () => api.get(`/api/recruiter/applications/${jobId}`).then((r) => r.data),
  });

  const decide = async (appId, accepted, feedback = '') => {
    const params = new URLSearchParams({ accepted, feedback, sendMail: !accepted });
    await api.put(`/api/recruiter/applications/${appId}?${params}`);
    queryClient.invalidateQueries(['applications', jobId]);
  };

  if (isLoading) return <div className="p-3">Loading applications…</div>;

  return (
    <Container className="mt-4">
      <h4>Applications for Job #{jobId}</h4>

      <Table striped bordered hover responsive>
        <thead>
          <tr>
            <th>Candidate</th>
            <th>Email</th>
            <th>Match Score</th>
            <th>Status</th>
            <th>Applied</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {apps.map((a) => (
            <tr key={a.applicationId}>
              <td>{a.candidateName}</td>
              <td>{a.candidateEmail}</td>
              <td>{a.matchScore?.toFixed(1)} %</td>
              <td>
                <Badge bg={a.status === 'PENDING' ? 'warning' : a.status === 'ACCEPTED' ? 'success' : 'danger'}>
                  {a.status}
                </Badge>
              </td>
              <td>{new Date(a.appliedAt).toLocaleDateString()}</td>
              <td>
                {a.status === 'PENDING' && (
                  <>
                    <Button
                      size="sm"
                      variant="outline-success"
                      className="me-2"
                      onClick={() => decide(a.applicationId, true, 'Congratulations!')}
                    >
                      Accept
                    </Button>
                    <Button
                      size="sm"
                      variant="outline-danger"
                      onClick={() => decide(a.applicationId, false, 'After review we decided to proceed with other candidates.')}
                    >
                      Reject
                    </Button>
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Container>
  );
};

export default RecruiterApplications;