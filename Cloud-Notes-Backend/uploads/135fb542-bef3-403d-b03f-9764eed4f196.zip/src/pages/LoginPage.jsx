import { useForm } from 'react-hook-form';
import { useAuth } from '../auth/AuthProvider';
import { useNavigate, Link } from 'react-router-dom';
import { Form, Button, Container, Row, Col, Alert, Card } from 'react-bootstrap';
import { useState } from 'react';

const LoginPage = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const { login } = useAuth();
  const nav = useNavigate();
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const onSubmit = async (data) => {
    setIsLoading(true);
    try {
      await login(data.username, data.password);
      nav('/');
    } catch (e) {
      setError(e.response?.data?.message || 'Login failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Container fluid className="vh-100 p-0 overflow-hidden">
      <Row className="h-100 g-0">
        {/* Left Side - Login Form (40%) */}
        <Col md={5} className="d-flex flex-column justify-content-center align-items-center bg-light p-4">
          <div className="w-100" style={{ maxWidth: '400px' }}>
            <div className="text-center mb-4">
              <h2 className="fw-bold">Welcome Back</h2>
              <p className="text-muted">Sign in to continue to your account</p>
            </div>
            
            {error && <Alert variant="danger">{error}</Alert>}
            
            <Form onSubmit={handleSubmit(onSubmit)}>
              <Form.Group className="mb-3" controlId="formUsername">
                <Form.Label>Username</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter your username"
                  {...register('username', { required: true })}
                  isInvalid={!!errors.username}
                />
                <Form.Control.Feedback type="invalid">
                  Username is required
                </Form.Control.Feedback>
              </Form.Group>
              
              <Form.Group className="mb-3" controlId="formPassword">
                <Form.Label>Password</Form.Label>
                <Form.Control
                  type="password"
                  placeholder="Enter your password"
                  {...register('password', { required: true })}
                  isInvalid={!!errors.password}
                />
                <Form.Control.Feedback type="invalid">
                  Password is required
                </Form.Control.Feedback>
              </Form.Group>
              
              <Button 
                variant="primary" 
                type="submit" 
                className="w-100 py-2 mb-3"
                disabled={isLoading}
              >
                {isLoading ? 'Signing in...' : 'Sign In'}
              </Button>
              
              <div className="text-center">
                <span className="text-muted">Don't have an account? </span>
                <Link to="/register" className="text-decoration-none">Register here</Link>
              </div>
            </Form>
          </div>
        </Col>
        
        {/* Right Side - Features (60%) */}
        <Col md={7} className="d-none d-md-flex flex-column justify-content-center bg-info bg-gradient text-white p-5" style={{ backgroundColor: '#e3f2fd' }}>
          <div className="mb-5">
            <h1 className="display-4 fw-bold mb-4 text-dark">Find Your Dream Job</h1>
            <p className="lead text-dark">Join thousands of candidates who have found their perfect career match through our platform.</p>
          </div>
          
          <Row className="g-4">
            <Col md={6}>
              <Card className="bg-white text-dark mb-4 h-100 shadow-sm">
                <Card.Body>
                  <div className="d-flex align-items-center mb-3">
                    <div className="rounded-circle bg-info d-flex align-items-center justify-content-center me-3" style={{ width: '50px', height: '50px' }}>
                      <i className="bi bi-search fs-4 text-white"></i>
                    </div>
                    <h4 className="mb-0">Smart Job Matching</h4>
                  </div>
                  <p>Our AI-powered system matches you with jobs that fit your skills and experience perfectly.</p>
                </Card.Body>
              </Card>
            </Col>
            
            <Col md={6}>
              <Card className="bg-white text-dark mb-4 h-100 shadow-sm">
                <Card.Body>
                  <div className="d-flex align-items-center mb-3">
                    <div className="rounded-circle bg-info d-flex align-items-center justify-content-center me-3" style={{ width: '50px', height: '50px' }}>
                      <i className="bi bi-file-earmark-text fs-4 text-white"></i>
                    </div>
                    <h4 className="mb-0">Resume Analysis</h4>
                  </div>
                  <p>Get detailed feedback on your resume and improve your chances of getting hired.</p>
                </Card.Body>
              </Card>
            </Col>
            
            <Col md={6}>
              <Card className="bg-white text-dark mb-4 h-100 shadow-sm">
                <Card.Body>
                  <div className="d-flex align-items-center mb-3">
                    <div className="rounded-circle bg-info d-flex align-items-center justify-content-center me-3" style={{ width: '50px', height: '50px' }}>
                      <i className="bi bi-graph-up fs-4 text-white"></i>
                    </div>
                    <h4 className="mb-0">Skill Gap Analysis</h4>
                  </div>
                  <p>Identify areas for improvement and get personalized recommendations for skill development.</p>
                </Card.Body>
              </Card>
            </Col>
            
            <Col md={6}>
              <Card className="bg-white text-dark mb-4 h-100 shadow-sm">
                <Card.Body>
                  <div className="d-flex align-items-center mb-3">
                    <div className="rounded-circle bg-info d-flex align-items-center justify-content-center me-3" style={{ width: '50px', height: '50px' }}>
                      <i className="bi bi-briefcase fs-4 text-white"></i>
                    </div>
                    <h4 className="mb-0">Application Tracking</h4>
                  </div>
                  <p>Keep track of all your job applications in one place and get updates on their status.</p>
                </Card.Body>
              </Card>
            </Col>
          </Row>
          
          <div className="mt-5 text-center">
            <h3 className="mb-3 text-dark">Join Our Community Today</h3>
            <p className="text-dark">Over 10,000 candidates have found their dream jobs through our platform</p>
          </div>
        </Col>
      </Row>
    </Container>
  );
};

export default LoginPage;