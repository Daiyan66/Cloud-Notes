import { useQuery } from '@tanstack/react-query';
import { Container, Table, Badge, Spinner, Alert } from 'react-bootstrap';
import api from '../api/axios';

const AnalyzedResumes = () => {
    const { data: resumes = [], isLoading, error } = useQuery({
        queryKey: ['analyzedResumes'],
        queryFn: () => api.get('/api/recruiter/analyzed-resumes').then(res => res.data),
    });

    const getScoreBadge = (score) => {
        const displayScore = Math.round(score);
        if (displayScore >= 70) return <Badge bg="success">{displayScore}%</Badge>;
        if (displayScore >= 50) return <Badge bg="warning">{displayScore}%</Badge>;
        return <Badge bg="danger">{displayScore}%</Badge>;
    };

    const formatDate = (dateString) => {
        if (!dateString) return 'N/A';
        return new Date(dateString).toLocaleString();
    };

    if (isLoading) {
        return (
            <div className="d-flex justify-content-center my-5">
                <Spinner animation="border" role="status" />
            </div>
        );
    }

    if (error) {
        return <Alert variant="danger">Error loading analyzed resumes.</Alert>;
    }

    return (
        <Container className="mt-4">
            <h3>Analyzed Resumes</h3>
            <p className="text-muted">Resumes uploaded and analyzed by recruiters.</p>
            
            {resumes.length === 0 ? (
                <Alert variant="info">No analyzed resumes found.</Alert>
            ) : (
                <Table striped bordered hover responsive>
                    <thead>
                        <tr>
                            <th>File Name</th>
                            <th>Score</th>
                            <th>Date Analyzed</th>
                            <th>Analyzed By</th>
                            <th>Job Title</th>
                        </tr>
                    </thead>
                    <tbody>
                        {resumes.map((resume) => (
                            <tr key={resume.applicationId}>
                                <td>{resume.fileName}</td>
                                <td>{getScoreBadge(resume.matchScore)}</td>
                                <td>{formatDate(resume.analyzedAt)}</td>
                                <td>{resume.analyzedBy}</td>
                                <td>{resume.jobTitle}</td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
            )}
        </Container>
    );
};

export default AnalyzedResumes;