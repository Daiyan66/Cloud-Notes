import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Spinner, Alert, Container } from 'react-bootstrap';
import api from '../api/axios';

const LatestAnalysisRedirect = () => {
    const navigate = useNavigate();

    const { data, isLoading, error } = useQuery({
        queryKey: ['latestAnalysisId'],
        queryFn: () => api.get('/api/candidate/analysis/latest').then(res => res.data),
    });

    useEffect(() => {
        if (data && data.applicationId) {
            navigate(`/candidate/analysis/${data.applicationId}`, { replace: true });
        } else if (data && data.applicationId === null) {
            // We can stop loading, the message below will show
        }
    }, [data, navigate]);

    if (isLoading) {
        return (
            <Container className="mt-4 d-flex justify-content-center">
                <Spinner animation="border" />
            </Container>
        );
    }

    if (error) {
        return <Alert variant="danger">Error finding your latest application.</Alert>;
    }

    if (!data || data.applicationId === null) {
        return (
            <Container className="mt-4">
                <Alert variant="info">
                    You don't have any past applications to analyze yet. <a href="/browse-jobs">Browse jobs to apply!</a>
                </Alert>
            </Container>
        );
    }

    // This component will redirect, so it doesn't need to render anything else.
    return null;
};

export default LatestAnalysisRedirect;