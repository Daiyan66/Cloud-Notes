import { useState, useEffect } from 'react';
import { Container, Button, Alert, ProgressBar, Table, Row, Col, Card } from 'react-bootstrap';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import FileDrop from '../components/FileDrop';
import api from '../api/axios';
import useUploadProgress from '../hooks/useUploadProgress';

const UploadResumes = () => {
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [msg, setMsg] = useState({ text: '', type: '' });
  const [jobId, setJobId] = useState('');
  const [startProgress, setStartProgress] = useState(false);
  
  // --- NEW STATE FOR RESULTS ---
  const [results, setResults] = useState([]);
  const [showResults, setShowResults] = useState(false);

  const token = localStorage.getItem('token');
  const { progress, done, error: progressError } = useUploadProgress(jobId, token, startProgress);

  const handleDrop = (dropped) => setFiles((prev) => [...prev, ...dropped]);
  const removeFile = (idx) => setFiles((f) => f.filter((_, i) => i !== idx));

  const handleUpload = async () => {
    if (!files.length || !jobId) return;
    
    setStartProgress(true);
    setUploading(true);
    setMsg({ text: 'Starting upload...', type: 'info' });
    setShowResults(false); // Hide previous results

    const form = new FormData();
    files.forEach((f) => form.append('files', f));
    form.append('jobId', jobId);

    try {
      await api.post('/api/recruiter/resumes', form, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setMsg({ text: 'Upload done. Parsing...', type: 'info' });
    } catch (e) {
      setStartProgress(false);
      setMsg({ text: e.response?.data?.message || 'Upload failed', type: 'danger' });
      setUploading(false);
    }
  };

  // --- NEW FUNCTION TO FETCH RESULTS ---
  // --- NEW FUNCTION TO FETCH RESULTS ---
const fetchResults = async () => {
    if (!jobId) return;
    try {
        const response = await api.get(`/api/recruiter/jobs/${jobId}/upload-results`);
        const allResults = response.data;

        // --- FIX: Keep only the results from the latest upload ---
        // The `files` state still holds the count of files from the most recent upload.
        // We take that many results from the beginning of the sorted list.
        const latestResults = allResults.slice(0, files.length);

        setResults(latestResults);
        setShowResults(true);
        setMsg({ text: 'Results for the latest upload loaded successfully!', type: 'success' });
    } catch (e) {
        setMsg({ text: 'Failed to load results.', type: 'danger' });
    }
};

  useEffect(() => {
    if (done) {
      setMsg({ text: 'Parsing complete! Fetching results...', type: 'success' });
      setUploading(false);
      setFiles([]);
      setStartProgress(false);
      // Fetch results after processing is complete
      fetchResults();
    }
  }, [done, jobId]); // Added jobId dependency

  useEffect(() => {
    if (progressError) {
      setMsg({ text: progressError, type: 'danger' });
      setUploading(false);
      setStartProgress(false);
    }
  }, [progressError]);

  const total = progress.split('/')[1] || 0;
  const current = progress.split('/')[0] || 0;
  const pct = total > 0 ? Math.round((current / total) * 100) : 0;

  // --- DATA FOR THE CHART ---
  const chartData = results.map(resume => ({
  name: resume.fileName,
  score: Math.round(resume.matchScore),
}));

  return (
    <Container className="mt-4">
      <h3>Upload Resumes</h3>

      {msg.text && <Alert variant={msg.type}>{msg.text}</Alert>}

      <div className="mb-3">
        <label>Job ID</label>
        <input
          className="form-control"
          value={jobId}
          onChange={(e) => setJobId(e.target.value)}
          placeholder="Enter job ID"
          disabled={uploading}
        />
      </div>

      <FileDrop
        onDrop={handleDrop}
        multiple
        accept={{
          'application/pdf': ['.pdf'],
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
        }}
        uploading={uploading}
      />

      {files.length > 0 && (
        <>
          <ul className="list-unstyled mt-2">
            {files.map((f, i) => (
              <li key={i} className="d-flex justify-content-between align-items-center mb-1">
                <span>{f.name}</span>
                <Button size="sm" variant="outline-danger" onClick={() => removeFile(i)} disabled={uploading}>
                  Remove
                </Button>
              </li>
            ))}
          </ul>

          <Button onClick={handleUpload} disabled={uploading || !jobId} className="mb-3">
            {uploading ? 'Uploading…' : 'Upload All'}
          </Button>
        </>
      )}

      {uploading && (
        <div className="mt-3">
          <div className="d-flex justify-content-between">
            <span>Parsing progress</span>
            <span>{progress}</span>
          </div>
          <ProgressBar now={pct} label={`${pct}%`} animated />
        </div>
      )}

      {/* --- NEW RESULTS SECTION --- */}
      {showResults && results.length > 0 && (
        <>
          <Row className="mt-5">
            <Col md={8}>
              <Card>
                <Card.Header as="h5">Resume Scores</Card.Header>
                <Card.Body>
                  <Table striped bordered hover responsive>
                    <thead>
                      <tr>
                        <th>File Name</th>
                        <th>Match Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      {results.map((resume, index) => (
                        <tr key={index}>
                          <td>{resume.fileName}</td>
                          <td>{Math.round(resume.matchScore)}%</td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4}>
              <Card>
                <Card.Header as="h5">Score Distribution</Card.Header>
                <Card.Body>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="score" fill="#8884d8" />
                    </BarChart>
                  </ResponsiveContainer>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </>
      )}
    </Container>
  );
};

export default UploadResumes;