import { useState } from 'react';
import { Container, Form, Button, Row, Col, Badge } from 'react-bootstrap';
import api from '../api/axios';

const SKILL_POOL = ['Java', 'Spring', 'React', 'MySQL', 'Python', 'Docker'];

export default function UploadJobForm() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [skills, setSkills] = useState([]);
  const [experience, setExperience] = useState(0);
  const [education, setEducation] = useState('');
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState({ text: '', type: '' });

  const toggleSkill = (s) =>
    setSkills((prev) => (prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title || !description) return;
    setLoading(true);
    try {
      await api.post('/api/recruiter/jobs-form', {
        title,
        description,
        skills: skills.join(','),
        experienceRequired: experience,
        educationLevel: education,
      });
      setMsg({ text: 'Job created successfully!', type: 'success' });
      // reset form
      setTitle(''); setDescription(''); setSkills([]); setExperience(0); setEducation('');
    } catch (err) {
      setMsg({ text: err.response?.data?.message || 'Failed', type: 'danger' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container className="mt-4">
      <h3>Create Job (Form)</h3>
      {msg.text && <div className={`alert alert-${msg.type}`}>{msg.text}</div>}
      <Form onSubmit={handleSubmit}>
        <Row>
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>Job Title</Form.Label>
              <Form.Control value={title} onChange={(e) => setTitle(e.target.value)} required />
            </Form.Group>
          </Col>
          <Col md={6}>
            <Form.Group className="mb-3">
              <Form.Label>Min Experience (yrs)</Form.Label>
              <Form.Range min={0} max={30} value={experience} onChange={(e) => setExperience(Number(e.target.value))} />
              <div>{experience} yrs</div>
            </Form.Group>
          </Col>
        </Row>

        <Form.Group className="mb-3">
          <Form.Label>Description</Form.Label>
          <Form.Control as="textarea" rows={4} value={description} onChange={(e) => setDescription(e.target.value)} required />
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Skills</Form.Label>
          <div>
            {SKILL_POOL.map((s) => (
              <Badge
                key={s}
                bg={skills.includes(s) ? 'primary' : 'secondary'}
                className="me-2 mb-1"
                style={{ cursor: 'pointer' }}
                onClick={() => toggleSkill(s)}
              >
                {s}
              </Badge>
            ))}
          </div>
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Education Level</Form.Label>
          <Form.Select value={education} onChange={(e) => setEducation(e.target.value)}>
            <option value="">Any</option>
            <option>High-School</option>
            <option>Diploma</option>
            <option>Bachelor</option>
            <option>Master</option>
            <option>PhD</option>
          </Form.Select>
        </Form.Group>

        <Button type="submit" disabled={loading}>{loading ? 'Creating…' : 'Create Job'}</Button>
      </Form>
    </Container>
  );
}