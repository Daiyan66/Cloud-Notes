import { useState } from 'react';
import { Form, Button, Row, Col, Badge } from 'react-bootstrap';
import { useSearchParams } from 'react-router-dom';

const EDUCATION_LEVELS = ['High-School', 'Diploma', 'Bachelor', 'Master', 'PhD'];
const SKILL_OPTIONS = ['Java', 'Spring', 'React', 'MySQL', 'Python', 'Docker'];

// --- REMOVED onApply from props ---
export default function FilterBar() {
  const [searchParams, setSearchParams] = useSearchParams();

  // read from URL on first load
  const [skills, setSkills] = useState(searchParams.get('skills')?.split(',') || []);
  const [experienceMin, setExperienceMin] = useState(Number(searchParams.get('experience') || 0));
  const [education, setEducation] = useState(searchParams.get('education') || '');

  const toggleSkill = (s) =>
    setSkills((prev) =>
      prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]
    );

  const handleApply = () => {
    const params = {};
    if (skills.length) params.skills = skills.join(',');
    if (experienceMin) params.experience = experienceMin;
    if (education) params.education = education;
    
    // Preserve the current sort parameter when applying new filters
    const currentSort = searchParams.get('sort');
    if (currentSort) {
        params.sort = currentSort;
    }
    
    setSearchParams(params, { replace: true });
    // --- REMOVED the onApply(params) call ---
  };

  const handleReset = () => {
    setSkills([]);
    setExperienceMin(0);
    setEducation('');
    
    // Preserve the current sort parameter when resetting
    const currentSort = searchParams.get('sort');
    const resetParams = currentSort ? { sort: currentSort } : {};
    
    setSearchParams(resetParams, { replace: true });
    // --- REMOVED the onApply({}) call ---
  };

  return (
    <div className="p-3 border rounded mb-3">
      <Row className="align-items-center gy-2">
        <Col md={4}>
          <Form.Label>Skills</Form.Label>
          <div>
            {SKILL_OPTIONS.map((s) => (
              <Badge
                key={s}
                bg={skills.includes(s) ? 'primary' : 'secondary'}
                className="me-2 mb-1"
                style={{ cursor: 'pointer' }}
                onClick={() => toggleSkill(s)}
              >
                {s}
              </Badge>
            ))}
          </div>
        </Col>

        <Col md={3}>
          <Form.Label>Min Experience ({experienceMin} yrs)</Form.Label>
          <Form.Range
            min={0}
            max={30}
            value={experienceMin}
            onChange={(e) => setExperienceMin(Number(e.target.value))}
          />
        </Col>

        <Col md={3}>
          <Form.Label>Education</Form.Label>
          <Form.Select value={education} onChange={(e) => setEducation(e.target.value)}>
            <option value="">Any</option>
            {EDUCATION_LEVELS.map((e) => (
              <option key={e} value={e}>{e}</option>
            ))}
          </Form.Select>
        </Col>

        <Col md={2} className="d-flex gap-2">
          <Button variant="primary" onClick={handleApply}>Apply</Button>
          <Button variant="outline-secondary" onClick={handleReset}>Reset</Button>
        </Col>
      </Row>
    </div>
  );
}