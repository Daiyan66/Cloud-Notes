import { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Alert, Spinner } from 'react-bootstrap';

const FileDrop = ({ onDrop, multiple = false, accept = {}, uploading = false }) => {
  const handleDrop = useCallback(
    (acceptedFiles) => {
      if (onDrop) onDrop(multiple ? acceptedFiles : acceptedFiles[0]);
    },
    [onDrop, multiple]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: handleDrop,
    multiple,
    accept,
    maxSize: 50 * 1024 * 1024, // 50 MB
  });

  return (
    <div
      {...getRootProps()}
      className={`border-2 border-dashed rounded p-4 text-center ${
        isDragActive ? 'border-primary bg-light' : 'border-secondary'
      }`}
      style={{ cursor: 'pointer' }}
    >
      <input {...getInputProps()} />
      {uploading ? (
        <Spinner animation="border" size="sm" />
      ) : isDragActive ? (
        <p>Drop the files here...</p>
      ) : (
        <p>Drag & drop files here, or click to select</p>
      )}
    </div>
  );
};

export default FileDrop;