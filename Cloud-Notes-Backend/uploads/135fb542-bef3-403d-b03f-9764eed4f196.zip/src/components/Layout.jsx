import { Navbar, Nav, Container, Button, NavDropdown } from 'react-bootstrap';
import { Outlet, Link } from 'react-router-dom';
import { useAuth } from '../auth/AuthProvider';
import { ROLES } from '../utils/constants';

const Layout = () => {
  const { user, logout, hasRole } = useAuth();

  const handleLogout = () => {
    logout();
    window.location.href = '/login';
  };

  return (
    <>
      <Navbar bg="dark" variant="dark" expand="lg">
        <Container>
          <Navbar.Brand as={Link} to="/">
            AI-Resume ·{" "}
            {user?.role === 'ADMIN'
              ? 'Admin Portal'
              : user?.role === 'RECRUITER'
              ? 'Recruiter Dashboard'
              : 'Candidate Home'}
          </Navbar.Brand>

          <Navbar.Toggle />
          <Navbar.Collapse>
            <Nav className="me-auto">
              <Nav.Link as={Link} to="/">
                Dashboard
              </Nav.Link>

              {/* --- NEW: ADMIN ONLY --- */}
              {hasRole(ROLES.ADMIN) && (
                <Nav.Link as={Link} to="/admin/add-recruiter">
                  Add Recruiter
                </Nav.Link>
              )}

              {/* RECRUITER ONLY (not ADMIN) */}
              {hasRole(ROLES.RECRUITER) && !hasRole(ROLES.ADMIN) && (
                <>
                  <NavDropdown title="Upload Job" id="upload-job-dropdown">
                    <NavDropdown.Item as={Link} to="/upload-job">
                      Upload PDF/DOCX
                    </NavDropdown.Item>
                    <NavDropdown.Item as={Link} to="/upload-job-form">
                      Create from Form
                    </NavDropdown.Item>
                  </NavDropdown>
                  <Nav.Link as={Link} to="/upload-resumes">
                    Upload Resumes
                  </Nav.Link>
                  <Nav.Link as={Link} to="/candidates">
                    Candidates
                  </Nav.Link>
                  <Nav.Link as={Link} to="/recruiter/analyzed-resumes">Analyzed Resumes</Nav.Link>
                </>
              )}

              {/* CANDIDATE ONLY */}
              {hasRole(ROLES.CANDIDATE) && (
                <>
                  <Nav.Link as={Link} to="/my-status">My Status</Nav.Link>
                  <Nav.Link as={Link} to="/candidate/analysis/latest">Skill Analysis</Nav.Link>
                  <Nav.Link as={Link} to="/browse-jobs">Browse Jobs</Nav.Link>
                </>
              )}
            </Nav>

            <Nav>
              {/* --- UPDATED: Display first name with a fallback --- */}
              <Navbar.Text className="me-3">
                Welcome, {user?.firstName || user?.username} ({user?.role})
              </Navbar.Text>
              <Button variant="outline-light" size="sm" onClick={handleLogout}>
                Logout
              </Button>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      <Container className="mt-4">
        <Outlet />
      </Container>
    </>
  );
};

export default Layout;