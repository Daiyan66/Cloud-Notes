import React, { useState, useEffect } from 'react';
import { Button, Card, Table, Spinner, Alert, Toast } from 'react-bootstrap';
import recruiterRequestService from '../services/recruiterRequestService';

const ManageRecruiterRequests = () => {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [actionLoading, setActionLoading] = useState(null); // To disable buttons during action

  const fetchRequests = () => {
    setLoading(true);
    setError('');
    recruiterRequestService.getPendingRequests()
      .then(response => {
        setRequests(response.data);
      })
      .catch(err => {
        setError('Failed to fetch requests. Please try again.');
        console.error(err);
      })
      .finally(() => {
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchRequests();
  }, []);

  const handleApprove = async (requestId) => {
    setActionLoading(requestId);
    try {
      await recruiterRequestService.approveRequest(requestId);
      // Refresh the list to remove the approved request
      fetchRequests();
    } catch (err) {
      setError('Failed to approve request.');
      console.error(err);
    } finally {
      setActionLoading(null);
    }
  };

  const handleReject = async (requestId) => {
    setActionLoading(requestId);
    try {
      await recruiterRequestService.rejectRequest(requestId);
      // Refresh the list to remove the rejected request
      fetchRequests();
    } catch (err) {
      setError('Failed to reject request.');
      console.error(err);
    } finally {
      setActionLoading(null);
    }
  };

  if (loading) {
    return <div className="text-center p-4"><Spinner animation="border" /></div>;
  }

  return (
    <Card>
      <Card.Header as="h4">Pending Recruiter Requests</Card.Header>
      <Card.Body>
        {error && <Alert variant="danger">{error}</Alert>}
        {requests.length === 0 && !loading && <p>No pending requests at the moment.</p>}
        
        {requests.length > 0 && (
          <Table striped hover responsive>
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Company</th>
                <th>Message</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {requests.map((request) => (
                <tr key={request.id}>
                  <td>{request.name}</td>
                  <td>{request.email}</td>
                  <td>{request.company}</td>
                  <td>{request.message || '-'}</td>
                  <td>
                    <Button
                      variant="success"
                      size="sm"
                      className="me-2"
                      onClick={() => handleApprove(request.id)}
                      disabled={actionLoading === request.id}
                    >
                      {actionLoading === request.id ? 'Approving...' : 'Approve'}
                    </Button>
                    <Button
                      variant="danger"
                      size="sm"
                      onClick={() => handleReject(request.id)}
                      disabled={actionLoading === request.id}
                    >
                      {actionLoading === request.id ? 'Rejecting...' : 'Reject'}
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card.Body>
    </Card>
  );
};

export default ManageRecruiterRequests;