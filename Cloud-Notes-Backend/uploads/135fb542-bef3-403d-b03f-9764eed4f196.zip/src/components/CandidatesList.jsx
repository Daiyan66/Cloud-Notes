import React, { useState, useEffect } from 'react';
import { Table, Button, Card, Row, Col, Badge, Alert, Spinner } from 'react-bootstrap';
import recruiterService from '../services/recruiterService';

const CandidatesList = ({ jobId }) => {
  const [candidates, setCandidates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCandidates = async () => {
      try {
        setLoading(true);
        const data = await recruiterService.getCandidatesForJob(jobId);
        setCandidates(data);
        setError(null);
      } catch (err) {
        console.error('Error fetching candidates:', err);
        setError('Failed to fetch candidates. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    if (jobId) {
      fetchCandidates();
    }
  }, [jobId]);

  const handleAccept = async (applicationId) => {
    try {
      await recruiterService.acceptApplication(applicationId);
      // Update the status in the local state
      setCandidates(candidates.map(candidate => 
        candidate.applicationId === applicationId 
          ? { ...candidate, status: 'ACCEPTED' } 
          : candidate
      ));
    } catch (err) {
      console.error('Error accepting application:', err);
      setError('Failed to accept application. Please try again.');
    }
  };

  const handleReject = async (applicationId) => {
    try {
      await recruiterService.rejectApplication(applicationId);
      // Update the status in the local state
      setCandidates(candidates.map(candidate => 
        candidate.applicationId === applicationId 
          ? { ...candidate, status: 'REJECTED' } 
          : candidate
      ));
    } catch (err) {
      console.error('Error rejecting application:', err);
      setError('Failed to reject application. Please try again.');
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'ACCEPTED':
        return <Badge bg="success">Accepted</Badge>;
      case 'REJECTED':
        return <Badge bg="danger">Rejected</Badge>;
      case 'PENDING':
        return <Badge bg="warning">Pending</Badge>;
      default:
        return <Badge bg="secondary">{status}</Badge>;
    }
  };

  const getScoreBadge = (score) => {
    if (score >= 70) {
      return <Badge bg="success">{score}%</Badge>;
    } else if (score >= 50) {
      return <Badge bg="warning">{score}%</Badge>;
    } else {
      return <Badge bg="danger">{score}%</Badge>;
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center my-5">
        <Spinner animation="border" role="status">
          <span className="visually-hidden">Loading...</span>
        </Spinner>
      </div>
    );
  }

  if (error) {
    return <Alert variant="danger">{error}</Alert>;
  }

  if (candidates.length === 0) {
    return <Alert variant="info">No candidates have applied for this job yet.</Alert>;
  }

  return (
    <Card>
      <Card.Header as="h5">Candidates for this Job</Card.Header>
      <Card.Body>
        <Table striped bordered hover responsive>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Match Score</th>
              <th>Skills</th>
              <th>Experience</th>
              <th>Applied At</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {candidates.map((candidate) => (
              <tr key={candidate.applicationId}>
                <td>{candidate.candidateName}</td>
                <td>{candidate.email}</td>
                <td>{getScoreBadge(Math.round(candidate.matchScore * 100))}</td>
                <td>
                  <div style={{ maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {candidate.skills}
                  </div>
                </td>
                <td>{candidate.experience} years</td>
                <td>{formatDate(candidate.appliedAt)}</td>
                <td>{getStatusBadge(candidate.status)}</td>
                <td>
                  <Row>
                    <Col>
                      <Button 
                        variant="success" 
                        size="sm"
                        disabled={candidate.status === 'ACCEPTED' || candidate.status === 'REJECTED'}
                        onClick={() => handleAccept(candidate.applicationId)}
                      >
                        Accept
                      </Button>
                    </Col>
                    <Col>
                      <Button 
                        variant="danger" 
                        size="sm"
                        disabled={candidate.status === 'ACCEPTED' || candidate.status === 'REJECTED'}
                        onClick={() => handleReject(candidate.applicationId)}
                      >
                        Reject
                      </Button>
                    </Col>
                  </Row>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </Card.Body>
    </Card>
  );
};

export default CandidatesList;