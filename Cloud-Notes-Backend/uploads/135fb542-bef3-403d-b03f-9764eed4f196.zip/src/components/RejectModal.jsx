import { useState } from 'react';
import { Modal, Button, Form } from 'react-bootstrap';

export default function RejectModal({ show, onHide, candidate, onSend }) {
  const [feedback, setFeedback] = useState(
    `Dear ${candidate?.candidateName || 'Candidate'},\n\n` +
    'After careful review we decided to proceed with other applicants whose skills more closely match our needs.\n\n' +
    'We encourage you to upskill and apply again in the future.\n\n' +
    'Best regards,\nRecruitment Team'
  );

  const handleSend = () => {
    onSend(candidate.applicationId, feedback);
    onHide();
  };

  return (
    <Modal show={show} onHide={onHide} size="lg">
      <Modal.Header closeButton>
        <Modal.Title>Reject Candidate – Email Preview</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form.Group>
          <Form.Label>Feedback / Email Body</Form.Label>
          <Form.Control
            as="textarea"
            rows={8}
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
          />
        </Form.Group>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Cancel
        </Button>
        <Button variant="danger" onClick={handleSend}>
          Send Rejection Email
        </Button>
      </Modal.Footer>
    </Modal>
  );
}