// In src/App.jsx

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './auth/AuthProvider';
import Layout from './components/Layout';
import PrivateRoute from './auth/PrivateRoute';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';

// Dashboard Pages
import Admin from './pages/Admin';
import Dashboard from './pages/Dashboard';
import CandidateJobBoard from './pages/CandidateJobBoard';

// Other Pages
import UploadJob from './pages/UploadJob';
import UploadJobForm from './pages/UploadJobForm';
import UploadResumes from './pages/UploadResumes';
import Candidates from './pages/Candidates';
import CandidateStatus from './pages/CandidateStatus';
import RecruiterApplications from './pages/RecruiterApplications';
import AnalyzedResumes from './pages/AnalyzedResumes';

// --- NEW IMPORTS ---
import AddRecruiter from './pages/AddRecruiter';
import RequestRecruiterAccessPage from './pages/RequestRecruiterAccessPage'; // <-- NEW
import InviteRegistrationPage from './pages/InviteRegistrationPage'; // <-- NEW

import SkillGapAnalysis from './pages/SkillGapAnalysis';
import LatestAnalysisRedirect from './pages/LatestAnalysisRedirect';

import { ROLES } from './utils/constants';

function App() {
  const { user } = useAuth();

  // Helper component to render the correct dashboard based on user role
  const DashboardRouter = () => {
    console.log("DashboardRouter running. Current user from context:", user);

    if (!user) {
        console.log("No user found, redirecting to /login");
        return <Navigate to="/login" />;
    }

    const userRole = user.role;
    console.log("User role is:", userRole);

    switch (userRole) {
      case ROLES.ADMIN:
        console.log("Role is ADMIN, rendering <Admin />");
        return <Admin />;
      case ROLES.RECRUITER:
        console.log("Role is RECRUITER, rendering <Dashboard />");
        return <Dashboard />;
      case ROLES.CANDIDATE:
        console.log("Role is CANDIDATE, rendering <CandidateJobBoard />");
        return <CandidateJobBoard />;
      default:
        console.log("Role is unrecognized, redirecting to /login");
        return <Navigate to="/login" />;
    }
};

  return (
    <BrowserRouter>
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        
        {/* --- NEW PUBLIC ROUTES --- */}
        <Route path="/request-recruiter-access" element={<RequestRecruiterAccessPage />} />
        <Route path="/invite" element={<InviteRegistrationPage />} />

        {/* Protected Routes with Layout */}
        <Route path="/" element={<PrivateRoute><Layout /></PrivateRoute>}>
          {/* Default route - renders the correct dashboard */}
          <Route index element={<DashboardRouter />} />

          {/* --- NEW ADMIN ROUTE --- */}
          {/* This specific route for adding a recruiter is placed before the general admin wildcard route */}
          <Route 
            path="admin/add-recruiter" 
            element={<PrivateRoute roles={[ROLES.ADMIN]}><AddRecruiter /></PrivateRoute>} 
          />

          {/* Admin Routes */}
          <Route path="admin/*" element={<PrivateRoute roles={[ROLES.ADMIN]}><Admin /></PrivateRoute>} />

          {/* Recruiter Routes */}
          <Route path="upload-job" element={<PrivateRoute roles={[ROLES.RECRUITER]}><UploadJob /></PrivateRoute>} />
          <Route path="upload-job-form" element={<PrivateRoute roles={[ROLES.RECRUITER]}><UploadJobForm /></PrivateRoute>} />
          <Route path="upload-resumes" element={<PrivateRoute roles={[ROLES.RECRUITER]}><UploadResumes /></PrivateRoute>} />
          <Route path="candidates" element={<PrivateRoute roles={[ROLES.RECRUITER]}><Candidates /></PrivateRoute>} />
          <Route path="applications/:jobId" element={<PrivateRoute roles={[ROLES.RECRUITER]}><RecruiterApplications /></PrivateRoute>} />
          <Route path="recruiter/analyzed-resumes" element={<PrivateRoute roles={[ROLES.RECRUITER]}><AnalyzedResumes /></PrivateRoute>} />

          {/* Candidate Routes */}
          <Route path="my-status" element={<PrivateRoute roles={[ROLES.CANDIDATE]}><CandidateStatus /></PrivateRoute>} />
          <Route path="candidate/analysis/latest" element={<PrivateRoute roles={[ROLES.CANDIDATE]}><LatestAnalysisRedirect /></PrivateRoute>} />
          <Route path="candidate/analysis/:applicationId" element={<PrivateRoute roles={[ROLES.CANDIDATE]}><SkillGapAnalysis /></PrivateRoute>} />
          <Route path="browse-jobs" element={<PrivateRoute roles={[ROLES.CANDIDATE]}><CandidateJobBoard /></PrivateRoute>} />
        </Route>

        {/* Fallback for any other routes */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;