import { useState, useEffect, useRef } from 'react';

/**
 * Custom hook to manage Server-Sent Events for upload progress.
 * It connects to the progress stream only when `shouldConnect` is true.
 */
const useUploadProgress = (jobId, token, shouldConnect) => {
  const [progress, setProgress] = useState('0/0');
  const [done, setDone] = useState(false);
  const [error, setError] = useState(null);
  const eventSourceRef = useRef(null);

  useEffect(() => {
    // If we shouldn't connect, or if we're already done, do nothing.
    if (!shouldConnect || done) {
      return;
    }

    // Reset state for a new connection
    setProgress('0/0');
    setDone(false);
    setError(null);

    const eventSource = new EventSource(
      `http://localhost:8080/api/recruiter/progress/${jobId}?token=${token}`
    );

    eventSourceRef.current = eventSource;

    eventSource.onmessage = (event) => {
      const data = event.data;
      setProgress(data);
    };

    // --- THIS IS THE CRITICAL FIX ---
    // Listen for the 'complete' event and close the connection immediately.
    eventSource.addEventListener('complete', (event) => {
      console.log("Completion event received. Closing connection.");
      setDone(true);
      eventSource.close(); // Close the connection on the event source itself
    });

    eventSource.onerror = (err) => {
      console.error('EventSource failed:', err);
      setError('Failed to connect to progress stream.');
      eventSource.close();
    };

    // Cleanup function: close the connection when the component unmounts
    // or when dependencies change.
    return () => {
      console.log("Cleaning up EventSource.");
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, [jobId, token, shouldConnect]); // Removed 'done' from dependencies to prevent re-runs

  return { progress, done, error };
};

export default useUploadProgress;