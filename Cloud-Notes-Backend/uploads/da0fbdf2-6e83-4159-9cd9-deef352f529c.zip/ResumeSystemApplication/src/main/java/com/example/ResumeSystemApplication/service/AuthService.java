package com.example.ResumeSystemApplication.service;


import org.springframework.security.core.userdetails.UserDetailsService;

import com.example.ResumeSystemApplication.model.User;

public interface AuthService extends UserDetailsService {
    User saveUser(User user);
    User saveUser(User user, String role);
    User findByUsername(String username);
    User findByEmail(String email);
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
}