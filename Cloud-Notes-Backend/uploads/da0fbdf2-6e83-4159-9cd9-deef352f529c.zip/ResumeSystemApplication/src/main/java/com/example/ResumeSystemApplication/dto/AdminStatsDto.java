// In src/main/java/com/example/ResumeSystemApplication/dto/AdminStatsDto.java

package com.example.ResumeSystemApplication.dto;

import java.util.List;
import java.util.Map;

public class AdminStatsDto {

    // User Counts
    private long totalUsers;
    private long totalCandidates;
    private long totalRecruiters;
    private long totalAdmins;

    // Content Counts
    private long totalJobs;
    private long totalApplications;
    private long totalResumes;

    // Trend Data
    private List<Map<String, Object>> applicationTrend;
    private List<Map<String, Object>> registrationTrend;

    // Role Distribution
    private List<RoleCount> userRoleDistribution;

    // --- Getters ---
    public long getTotalUsers() { return totalUsers; }
    public long getTotalCandidates() { return totalCandidates; }
    public long getTotalRecruiters() { return totalRecruiters; }
    public long getTotalAdmins() { return totalAdmins; }
    public long getTotalJobs() { return totalJobs; }
    public long getTotalApplications() { return totalApplications; }
    public long getTotalResumes() { return totalResumes; }
    public List<Map<String, Object>> getApplicationTrend() { return applicationTrend; }
    public List<Map<String, Object>> getRegistrationTrend() { return registrationTrend; }
    public List<RoleCount> getUserRoleDistribution() { return userRoleDistribution; }

    // --- Inner Class for Role Counts ---
    public static class RoleCount {
        private final String role;
        private final long count;

        public RoleCount(String role, long count) {
            this.role = role;
            this.count = count;
        }

        public String getRole() { return role; }
        public long getCount() { return count; }
    }

    // --- Manual Builder Pattern Implementation ---

    public static AdminStatsDtoBuilder builder() {
        return new AdminStatsDtoBuilder();
    }

    public static class AdminStatsDtoBuilder {
        private long totalUsers;
        private long totalCandidates;
        private long totalRecruiters;
        private long totalAdmins;
        private long totalJobs;
        private long totalApplications;
        private long totalResumes;
        private List<Map<String, Object>> applicationTrend;
        private List<Map<String, Object>> registrationTrend;
        private List<RoleCount> userRoleDistribution;

        public AdminStatsDtoBuilder totalUsers(long totalUsers) {
            this.totalUsers = totalUsers;
            return this;
        }
        public AdminStatsDtoBuilder totalCandidates(long totalCandidates) {
            this.totalCandidates = totalCandidates;
            return this;
        }
        public AdminStatsDtoBuilder totalRecruiters(long totalRecruiters) {
            this.totalRecruiters = totalRecruiters;
            return this;
        }
        public AdminStatsDtoBuilder totalAdmins(long totalAdmins) {
            this.totalAdmins = totalAdmins;
            return this;
        }
        public AdminStatsDtoBuilder totalJobs(long totalJobs) {
            this.totalJobs = totalJobs;
            return this;
        }
        public AdminStatsDtoBuilder totalApplications(long totalApplications) {
            this.totalApplications = totalApplications;
            return this;
        }
        public AdminStatsDtoBuilder totalResumes(long totalResumes) {
            this.totalResumes = totalResumes;
            return this;
        }
        public AdminStatsDtoBuilder applicationTrend(List<Map<String, Object>> applicationTrend) {
            this.applicationTrend = applicationTrend;
            return this;
        }
        public AdminStatsDtoBuilder registrationTrend(List<Map<String, Object>> registrationTrend) {
            this.registrationTrend = registrationTrend;
            return this;
        }
        public AdminStatsDtoBuilder userRoleDistribution(List<RoleCount> userRoleDistribution) {
            this.userRoleDistribution = userRoleDistribution;
            return this;
        }

        public AdminStatsDto build() {
            AdminStatsDto stats = new AdminStatsDto();
            stats.totalUsers = this.totalUsers;
            stats.totalCandidates = this.totalCandidates;
            stats.totalRecruiters = this.totalRecruiters;
            stats.totalAdmins = this.totalAdmins;
            stats.totalJobs = this.totalJobs;
            stats.totalApplications = this.totalApplications;
            stats.totalResumes = this.totalResumes;
            stats.applicationTrend = this.applicationTrend;
            stats.registrationTrend = this.registrationTrend;
            stats.userRoleDistribution = this.userRoleDistribution;
            return stats;
        }
    }
}