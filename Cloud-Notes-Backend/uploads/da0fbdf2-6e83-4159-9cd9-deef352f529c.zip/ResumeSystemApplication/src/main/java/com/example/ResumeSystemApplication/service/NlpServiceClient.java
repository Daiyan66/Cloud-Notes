package com.example.ResumeSystemApplication.service;

import com.example.ResumeSystemApplication.dto.NlpMatchRequest;
import com.example.ResumeSystemApplication.dto.NlpMatchResponse;
import com.example.ResumeSystemApplication.dto.NlpParseResponse;
import com.example.ResumeSystemApplication.config.JwtService;
import com.fasterxml.jackson.databind.ObjectMapper; // Added import
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.*;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class NlpServiceClient {

    private static final Logger logger = LoggerFactory.getLogger(NlpServiceClient.class);
    private final ObjectMapper objectMapper = new ObjectMapper(); // Added ObjectMapper instance

    private final RestTemplate restTemplate;
    private final JwtService jwtService;

    @Value("${nlp.service.url}")
    private String nlpServiceUrl;

    public NlpServiceClient(RestTemplate restTemplate, JwtService jwtService) {
        this.restTemplate = restTemplate;
        this.jwtService = jwtService;
    }

    public NlpParseResponse parseResume(String filePath) {
        try {
            String url = nlpServiceUrl + "/parse-resume";

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);
            headers.setBearerAuth(generateJwtToken());

            MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
            FileSystemResource fileResource = new FileSystemResource(new File(filePath));
            body.add("file", fileResource);

            HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<>(body, headers);

            ResponseEntity<NlpParseResponse> response = restTemplate.exchange(
                    url,
                    HttpMethod.POST,
                    entity,
                    NlpParseResponse.class
            );

            return response.getBody();
        } catch (Exception e) {
            logger.error("Error calling NLP parse service", e);
            logger.warn("Using mock response for resume parsing");
            
            NlpParseResponse mockResponse = new NlpParseResponse();
            mockResponse.setRawText("Mock resume text for testing");
            mockResponse.setSkills(Collections.singletonList("Java"));
            mockResponse.setEducation(Collections.singletonList("Bachelor of Computer Science"));
            mockResponse.setExperience(Map.of("total_years", 2));
            return mockResponse;
        }
    }

    public List<NlpMatchResponse> matchResumes(String jobDescription, List<Map<String, Object>> resumesData) {
        try {
            String url = nlpServiceUrl + "/match-resumes";

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(generateJwtToken());

            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("job_description", jobDescription);
            requestBody.put("resumes_data", resumesData);

            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);

            ResponseEntity<NlpMatchResponse[]> response = restTemplate.exchange(
                    url,
                    HttpMethod.POST,
                    entity,
                    NlpMatchResponse[].class
            );

            return List.of(response.getBody());
        } catch (Exception e) {
            logger.error("Error calling NLP match service", e);
            NlpMatchResponse defaultResponse = new NlpMatchResponse();
            defaultResponse.setOverallScore(0.5);
            return Collections.singletonList(defaultResponse);
        }
    }

    public String getChatbotResponse(String query) {
        try {
            String url = nlpServiceUrl + "/chatbot";

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(generateJwtToken());

            Map<String, String> request = Map.of("query", query);

            HttpEntity<Map<String, String>> entity = new HttpEntity<>(request, headers);

            ResponseEntity<Map> response = restTemplate.exchange(
                    url,
                    HttpMethod.POST,
                    entity,
                    Map.class
            );

            return (String) response.getBody().get("response");
        } catch (Exception e) {
            logger.error("Error calling NLP chatbot service", e);
            return "I'm sorry, I'm having trouble responding right now. Please try again later.";
        }
    }

    public NlpMatchResponse matchSingleResume(String jobDescription, Map<String, Object> resumeData) {
        try {
            List<Map<String, Object>> resumesData = Collections.singletonList(resumeData);
            NlpMatchRequest request = new NlpMatchRequest(jobDescription, resumesData);

            // --- START OF ADDED LOGGING ---
            try {
                String requestJson = objectMapper.writeValueAsString(request);
                logger.info("Sending request to NLP service: {}", requestJson);
            } catch (Exception e) {
                logger.error("Could not serialize request to JSON for logging", e);
            }
            // --- END OF ADDED LOGGING ---

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(generateJwtToken());

            HttpEntity<NlpMatchRequest> entity = new HttpEntity<>(request, headers);

            String url = nlpServiceUrl + "/match-resumes";

            ResponseEntity<NlpMatchResponse[]> response = restTemplate.exchange(
                    url,
                    HttpMethod.POST,
                    entity,
                    NlpMatchResponse[].class
            );

            // --- START OF ADDED LOGGING ---
            logger.info("Received raw response from NLP service: {}", response);
            try {
                String responseBodyJson = objectMapper.writeValueAsString(response.getBody());
                logger.info("Received response body from NLP service: {}", responseBodyJson);
            } catch (Exception e) {
                logger.error("Could not serialize response body to JSON for logging", e);
            }
            // --- END OF ADDED LOGGING ---

            NlpMatchResponse[] responses = response.getBody();
            if (responses != null && responses.length > 0) {
                return responses[0];
            } else {
                logger.warn("Received empty response from NLP service");
                NlpMatchResponse defaultResponse = new NlpMatchResponse();
                defaultResponse.setOverallScore(0.5); // Use decimal (0.5 = 50%)
                return defaultResponse;
            }
        } catch (Exception e) {
            logger.error("Error calling NLP single match service", e);
            NlpMatchResponse defaultResponse = new NlpMatchResponse();
            defaultResponse.setOverallScore(0.5); // Use decimal (0.5 = 50%)
            return defaultResponse;
        }
    }

    private String generateJwtToken() {
        UserDetails serviceUser = new User(
                "nlp-service",
                "",
                Collections.singletonList(new SimpleGrantedAuthority("ROLE_SERVICE"))
        );
        
        return jwtService.generateToken(serviceUser);
    }
}