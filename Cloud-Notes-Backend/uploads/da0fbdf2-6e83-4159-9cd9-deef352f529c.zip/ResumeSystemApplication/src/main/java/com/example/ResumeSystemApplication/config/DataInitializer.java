package com.example.ResumeSystemApplication.config;

import com.example.ResumeSystemApplication.model.Role;
import com.example.ResumeSystemApplication.repository.RoleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(DataInitializer.class);

    private final RoleRepository roleRepository;

    // Manual constructor injection
    public DataInitializer(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        initializeRole("ADMIN");
        initializeRole("RECRUITER");
        initializeRole("CANDIDATE");
    }

    private void initializeRole(String roleName) {
        roleRepository.findByName(roleName).ifPresentOrElse(
            role -> logger.info("Role '{}' already exists.", roleName),
            () -> {
                Role newRole = new Role();
                newRole.setName(roleName);
                roleRepository.save(newRole);
                logger.info("Created default role: '{}'", roleName);
            }
        );
    }
}
