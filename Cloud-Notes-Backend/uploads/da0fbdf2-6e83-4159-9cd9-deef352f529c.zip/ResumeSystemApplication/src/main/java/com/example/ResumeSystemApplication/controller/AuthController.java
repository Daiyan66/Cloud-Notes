package com.example.ResumeSystemApplication.controller;

import com.example.ResumeSystemApplication.config.JwtService;
import com.example.ResumeSystemApplication.dto.AuthRequest;
import com.example.ResumeSystemApplication.dto.AuthResponse;
import com.example.ResumeSystemApplication.dto.UserDto;
import com.example.ResumeSystemApplication.model.User;
import com.example.ResumeSystemApplication.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;

    public AuthController(AuthService authService,
                          JwtService jwtService,
                          AuthenticationManager authenticationManager) {
        this.authService = authService;
        this.jwtService = jwtService;
        this.authenticationManager = authenticationManager;
    }
    
    @GetMapping("/me")
    public ResponseEntity<?> me(Authentication auth) {
        User user = authService.findByUsername(auth.getName());
        return ResponseEntity.ok(Map.of(
            "username", user.getUsername(),
            "role", user.getRoles().iterator().next().getName()
        ));
    }

    /* ---------------- register with role ---------------- */
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody UserDto dto) {
        if (authService.existsByUsername(dto.getUsername()))
            return ResponseEntity.badRequest().body("Username is already taken!");
        if (authService.existsByEmail(dto.getEmail()))
            return ResponseEntity.badRequest().body("Email is already in use!");

        User user = new User();
        user.setFirstName(dto.getFirstName());
        user.setLastName(dto.getLastName());
        user.setEmail(dto.getEmail());
        user.setUsername(dto.getUsername());
        user.setPassword(dto.getPassword());

        String role = dto.getRole() != null ? dto.getRole() : "CANDIDATE";
        authService.saveUser(user, role);

        return ResponseEntity.ok("User registered successfully!");
    }

    /* ---------------- login ---------------- */
    @PostMapping("/login")
    public ResponseEntity<?> authenticate(@RequestBody AuthRequest request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getUsername(),
                        request.getPassword())
        );

        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        String jwt = jwtService.generateToken(userDetails);

        // load real user to obtain role
        User realUser = authService.findByUsername(userDetails.getUsername());

        AuthResponse response = new AuthResponse();
        response.setToken(jwt);
        response.setUsername(userDetails.getUsername());
        response.setRole(realUser.getRoles().iterator().next().getName()); // <-- NEW

        return ResponseEntity.ok(response);
    }
}