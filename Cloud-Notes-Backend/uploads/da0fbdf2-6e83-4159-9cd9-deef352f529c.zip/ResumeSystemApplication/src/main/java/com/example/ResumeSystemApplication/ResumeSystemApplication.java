package com.example.ResumeSystemApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling; // <-- Add this import
import org.springframework.scheduling.annotation.Scheduled;      // <-- Add this import
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
@EnableJpaAuditing
@EntityScan("com.example.ResumeSystemApplication.model")
@EnableScheduling // <-- Add this annotation
public class ResumeSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(ResumeSystemApplication.class, args);
    }

    // ... (rest of the file)
}