// src/main/java/com/example/ResumeSystemApplication/config/SseAuthFilter.java

package com.example.ResumeSystemApplication.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.example.ResumeSystemApplication.config.JwtService;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class SseAuthFilter extends OncePerRequestFilter {

    private static final Logger logger = LoggerFactory.getLogger(SseAuthFilter.class);

    private final JwtService jwtService;
    private final UserDetailsService userDetailsService;

    public SseAuthFilter(JwtService jwtService, UserDetailsService userDetailsService) {
        this.jwtService = jwtService;
        this.userDetailsService = userDetailsService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        final String token = request.getParameter("token"); // from ?token=xyz
        
        if (token == null) {
            filterChain.doFilter(request, response);
            return;
        }

        logger.debug("SseAuthFilter: Found token in request: {}", request.getRequestURI());

        try {
            final String username = jwtService.extractUsername(token);
            logger.debug("SseAuthFilter: Extracted username: {}", username);

            if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                UserDetails userDetails = this.userDetailsService.loadUserByUsername(username);
                logger.debug("SseAuthFilter: Loaded UserDetails for user: {}", username);

                if (jwtService.isTokenValid(token, userDetails)) {
                    logger.info("SseAuthFilter: Token is valid for user: {}. Setting authentication.", username);
                    UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                            userDetails, null, userDetails.getAuthorities());
                    authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(authToken);
                } else {
                    logger.warn("SseAuthFilter: Token validation FAILED for user: {}", username);
                }
            }
        } catch (Exception e) {
            logger.error("SseAuthFilter: Could not set user authentication in security context", e);
        }

        filterChain.doFilter(request, response);
    }
}