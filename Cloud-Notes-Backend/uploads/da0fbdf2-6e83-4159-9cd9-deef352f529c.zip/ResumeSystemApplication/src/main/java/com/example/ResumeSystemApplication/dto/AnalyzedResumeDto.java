package com.example.ResumeSystemApplication.dto;

import java.time.LocalDateTime;

public class AnalyzedResumeDto {
    private Long applicationId;
    private String fileName;
    private Double matchScore;
    private LocalDateTime analyzedAt;
    private String analyzedBy;
    private String jobTitle;

    // Constructors
    public AnalyzedResumeDto() {}

    public AnalyzedResumeDto(Long applicationId, String fileName, Double matchScore, LocalDateTime analyzedAt, String analyzedBy, String jobTitle) {
        this.applicationId = applicationId;
        this.fileName = fileName;
        this.matchScore = matchScore;
        this.analyzedAt = analyzedAt;
        this.analyzedBy = analyzedBy;
        this.jobTitle = jobTitle;
    }

    // Getters and Setters
    public Long getApplicationId() { return applicationId; }
    public void setApplicationId(Long applicationId) { this.applicationId = applicationId; }
    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }
    public Double getMatchScore() { return matchScore; }
    public void setMatchScore(Double matchScore) { this.matchScore = matchScore; }
    public LocalDateTime getAnalyzedAt() { return analyzedAt; }
    public void setAnalyzedAt(LocalDateTime analyzedAt) { this.analyzedAt = analyzedAt; }
    public String getAnalyzedBy() { return analyzedBy; }
    public void setAnalyzedBy(String analyzedBy) { this.analyzedBy = analyzedBy; }
    public String getJobTitle() { return jobTitle; }
    public void setJobTitle(String jobTitle) { this.jobTitle = jobTitle; }
}