package com.example.ResumeSystemApplication.dto;

import lombok.Data;

@Data
public class NlpParseRequest {
    private String filePath;
    
    public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public NlpParseRequest(String filePath) {
        this.filePath = filePath;
    }
}