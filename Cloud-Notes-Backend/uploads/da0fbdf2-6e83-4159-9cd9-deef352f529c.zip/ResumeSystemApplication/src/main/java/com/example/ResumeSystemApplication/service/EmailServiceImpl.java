package com.example.ResumeSystemApplication.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;


@Service
public class EmailServiceImpl implements EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);

    private final JavaMailSender mailSender;
    private final SpringTemplateEngine templateEngine;

    @Value("${spring.mail.username}")
    private String fromEmail;

    // Constructor injection for both mailSender and templateEngine
    public EmailServiceImpl(JavaMailSender mailSender, SpringTemplateEngine templateEngine) {
        this.mailSender = mailSender;
        this.templateEngine = templateEngine;
    }

    @Override
    public void sendEmail(String to, String subject, String body) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(to);
            message.setSubject(subject);
            message.setText(body);

            mailSender.send(message);
            logger.info("Email sent successfully to: {}", to);
        } catch (Exception e) {
            logger.error("Failed to send email to: {}", to, e);
        }
    }

    @Override
    public void sendRecruiterNotification(String recruiterEmail, String message) {
        String subject = "Resume Processing Complete";
        sendEmail(recruiterEmail, subject, message);
    }

    @Override
    public void sendCandidateNotification(String candidateEmail, boolean accepted, String feedback) {
        String subject = accepted ? "Application Accepted" : "Application Update";
        String body = "Dear Candidate,\n\n" +
                     (accepted ? "Congratulations! Your application has been accepted." :
                                 "Thank you for your application. " + feedback) +
                     "\n\nBest regards,\nHR Team";

        sendEmail(candidateEmail, subject, body);
    }

    @Override
    public void sendRejectionEmail(String to, String name, List<String> gaps, String feedback) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setFrom(fromEmail); // Set the sender's email
            helper.setTo(to);
            helper.setSubject("Application Update – Thank you for your interest");

            // Prepare context for Thymeleaf
            Context ctx = new Context();
            ctx.setVariable("name", name);
            ctx.setVariable("gaps", gaps);
            ctx.setVariable("feedback", feedback);

            // Process the HTML template
            String html = templateEngine.process("rejection-email", ctx);

            helper.setText(html, true); // true = isHtml
            mailSender.send(message);

            logger.info("Rejection email sent to {}", to);
        } catch (MessagingException e) {
            logger.error("Failed to send rejection email to {}", to, e);
            throw new RuntimeException("Mail send failed", e);
        }
    }
}
