package com.example.ResumeSystemApplication.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.Map;

public class NlpMatchRequest {

    @JsonProperty("job_description")
    private String jobDescription;

    @JsonProperty("resumes_data")
    private List<Map<String, Object>> resumesData;

    // No-argument constructor
    public NlpMatchRequest() {
    }

    // All-argument constructor
    public NlpMatchRequest(String jobDescription, List<Map<String, Object>> resumesData) {
        this.jobDescription = jobDescription;
        this.resumesData = resumesData;
    }

    // Getter for jobDescription
    public String getJobDescription() {
        return jobDescription;
    }

    // Setter for jobDescription
    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    // Getter for resumesData
    public List<Map<String, Object>> getResumesData() {
        return resumesData;
    }

    // Setter for resumesData
    public void setResumesData(List<Map<String, Object>> resumesData) {
        this.resumesData = resumesData;
    }
}