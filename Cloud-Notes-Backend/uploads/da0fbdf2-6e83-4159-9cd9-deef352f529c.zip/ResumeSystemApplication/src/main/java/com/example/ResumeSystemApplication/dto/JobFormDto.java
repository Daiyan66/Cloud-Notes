package com.example.ResumeSystemApplication.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class JobFormDto {
    @NotBlank
    private String title;

    @NotBlank
    private String description;

    private String skills;
    public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	public Integer getExperienceRequired() {
		return experienceRequired;
	}
	public void setExperienceRequired(Integer experienceRequired) {
		this.experienceRequired = experienceRequired;
	}
	public String getEducationLevel() {
		return educationLevel;
	}
	public void setEducationLevel(String educationLevel) {
		this.educationLevel = educationLevel;
	}
	private Integer experienceRequired;
    private String educationLevel;
}