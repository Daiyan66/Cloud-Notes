package com.example.ResumeSystemApplication.dto;

import lombok.Data;

@Data          // ← generates setters
public class JobDto {
    private Long id;
    private String title;
    public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSkillsRequired() {
		return skillsRequired;
	}
	public void setSkillsRequired(String skillsRequired) {
		this.skillsRequired = skillsRequired;
	}
	public String getEducationLevel() {
		return educationLevel;
	}
	public void setEducationLevel(String educationLevel) {
		this.educationLevel = educationLevel;
	}
	public Integer getExperienceRequired() {
		return experienceRequired;
	}
	public void setExperienceRequired(Integer experienceRequired) {
		this.experienceRequired = experienceRequired;
	}
	private String description;
    private String skillsRequired;
    private String educationLevel;
    private Integer experienceRequired;
}