package com.example.ResumeSystemApplication.repository;

import java.time.LocalDate;
import java.time.LocalDateTime; // <-- ADD THIS IMPORT
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.ResumeSystemApplication.model.Resume;

@Repository
public interface ResumeRepository extends JpaRepository<Resume, Long> {
    List<Resume> findByCandidateId(Long candidateId);
    Optional<Resume> findFirstByCandidateId(Long candidateId);

    // --- CORRECTED METHOD ---
    // Change the parameter type from LocalDate to LocalDateTime
    long countByUploadedAtAfter(LocalDateTime dateTime);

    @Query("SELECT r FROM Resume r WHERE r.candidateId = :candidateId ORDER BY r.uploadedAt DESC")
    List<Resume> findAllByCandidateIdOrderByUploadedAtDesc(@Param("candidateId") Long candidateId);
}