package com.example.ResumeSystemApplication.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApplyResponse {
    private String message;
    public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public double getMatchScore() {
		return matchScore;
	}

	public void setMatchScore(double matchScore) {
		this.matchScore = matchScore;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	private double matchScore;
    private String status; // PENDING or REJECTED
    
    // Constructor with message only
    public ApplyResponse(String message) {
        this.message = message;
    }
    
    // Constructor with message, matchScore, and status
    public ApplyResponse(String message, double matchScore, String status) {
        this.message = message;
        this.matchScore = matchScore;
        this.status = status;
    }
    
    // Constructor with success flag and message (for error cases)
    public ApplyResponse(boolean success, String message) {
        this.message = message;
        if (!success) {
            this.status = "ERROR";
        }
    }
}