 package com.example.ResumeSystemApplication.service;

import com.example.ResumeSystemApplication.dto.ApplyResponse;
import com.example.ResumeSystemApplication.dto.JobDto;
import com.example.ResumeSystemApplication.dto.SkillGapAnalysisDto;
import com.example.ResumeSystemApplication.model.Resume;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public interface CandidateService {
    void uploadResume(MultipartFile file, String username);
    Resume getApplicationStatus(String username);
    String getFeedback(String username);
    List<JobDto> searchJobs(String title, String skills, String education, Integer expMin);
    ApplyResponse apply(MultipartFile resume, Long jobId, String username);
    SkillGapAnalysisDto getSkillGapAnalysis(Long applicationId);
}