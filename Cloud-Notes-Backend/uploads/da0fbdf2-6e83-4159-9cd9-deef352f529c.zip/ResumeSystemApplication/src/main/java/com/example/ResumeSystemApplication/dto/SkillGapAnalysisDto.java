package com.example.ResumeSystemApplication.dto;

public class SkillGapAnalysisDto {
    private String jobTitle;
    private String rawSkillGapJson;

    // Constructors
    public SkillGapAnalysisDto() {}

    public SkillGapAnalysisDto(String jobTitle, String rawSkillGapJson) {
        this.jobTitle = jobTitle;
        this.rawSkillGapJson = rawSkillGapJson;
    }

    // Getters and Setters
    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getRawSkillGapJson() {
        return rawSkillGapJson;
    }

    public void setRawSkillGapJson(String rawSkillGapJson) {
        this.rawSkillGapJson = rawSkillGapJson;
    }
}