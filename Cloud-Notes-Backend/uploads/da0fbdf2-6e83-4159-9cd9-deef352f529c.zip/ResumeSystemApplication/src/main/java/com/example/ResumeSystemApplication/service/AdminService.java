 package com.example.ResumeSystemApplication.service;


import java.util.List;

import com.example.ResumeSystemApplication.model.User;

public interface AdminService {
    List<User> getAllUsers();
    User createUser(User user);
    User updateUser(Long id, User user);
    void deleteUser(Long id);
}