package com.example.ResumeSystemApplication.dto;

import lombok.Data;

@Data
public class ApplicationDto {
    private Long applicationId;
    private Long jobId;
    private Long resumeId;
    private String candidateName;
    private String jobTitle;
    public String getJobTitle() {
		return jobTitle;
	}
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	public Long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	public Long getJobId() {
		return jobId;
	}
	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}
	public Long getResumeId() {
		return resumeId;
	}
	public void setResumeId(Long resumeId) {
		this.resumeId = resumeId;
	}
	public String getCandidateName() {
		return candidateName;
	}
	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}
	public String getCandidateEmail() {
		return candidateEmail;
	}
	public void setCandidateEmail(String candidateEmail) {
		this.candidateEmail = candidateEmail;
	}
	public Double getMatchScore() {
		return matchScore;
	}
	public void setMatchScore(Double matchScore) {
		this.matchScore = matchScore;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getResumeFileName() {
		return resumeFileName;
	}
	public void setResumeFileName(String resumeFileName) {
		this.resumeFileName = resumeFileName;
	}
	public String getAppliedAt() {
		return appliedAt;
	}
	public void setAppliedAt(String appliedAt) {
		this.appliedAt = appliedAt;
	}
	private String candidateEmail;
    private Double matchScore;
    private String status;               // PENDING / ACCEPTED / REJECTED
    private String resumeFileName;
    private String appliedAt;
}