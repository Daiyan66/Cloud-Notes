package com.example.ResumeSystemApplication.controller;

import com.example.ResumeSystemApplication.dto.*;
import com.example.ResumeSystemApplication.service.EmailService;
import com.example.ResumeSystemApplication.service.ProgressService;
import com.example.ResumeSystemApplication.service.RecruiterService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/recruiter")
@PreAuthorize("hasRole('RECRUITER') or hasRole('ADMIN')")
@RequiredArgsConstructor
public class RecruiterController {

    private static final Logger logger = LoggerFactory.getLogger(RecruiterController.class);

    private final RecruiterService recruiterService;
    private final ProgressService progressService;
    private final EmailService emailService;
    
    public RecruiterController(RecruiterService recruiterService,
            ProgressService progressService,
            EmailService emailService) {
this.recruiterService = recruiterService;
this.progressService = progressService;
this.emailService = emailService;
}


    // No need for a custom constructor when using @RequiredArgsConstructor
    // public RecruiterController(...) { ... }

    // ========== New: Get candidates for a specific job ==========
    @GetMapping("/jobs/{jobId}/candidates")
    public ResponseEntity<List<CandidateDto>> getCandidatesForJob(@PathVariable Long jobId) {
        try {
            logger.info("Fetching candidates for job ID: {}", jobId);
            List<CandidateDto> candidates = recruiterService.getCandidatesForJob(jobId);
            return ResponseEntity.ok(candidates);
        } catch (Exception e) {
            logger.error("Error fetching candidates for job ID: {}", jobId, e);
            return ResponseEntity.internalServerError().build();
        }
    }

    // ========== New: Get applications for a job ==========
    @GetMapping("/applications/{jobId}")
    public ResponseEntity<List<ApplicationDto>> getApplicationsByJob(@PathVariable Long jobId) {
        try {
            List<ApplicationDto> apps = recruiterService.getApplicationsByJob(jobId);
            logger.info("Fetched {} applications for jobId {}", apps.size(), jobId);
            return ResponseEntity.ok(apps);
        } catch (Exception e) {
            logger.error("Error fetching applications for job ID: {}", jobId, e);
            return ResponseEntity.internalServerError().build();
        }
    }

    // ========== New: Get recruiter dashboard stats ==========
    @GetMapping("/stats")
    public ResponseEntity<RecruiterStatsDto> getRecruiterStats() {
        try {
            RecruiterStatsDto stats = recruiterService.getRecruiterStats();
            return ResponseEntity.ok(stats);
        } catch (Exception e) {
            logger.error("Error fetching recruiter stats", e);
            return ResponseEntity.internalServerError().build();
        }
    }
    
 // Add this method inside the RecruiterController class
    @GetMapping("/analyzed-resumes")
    public ResponseEntity<List<AnalyzedResumeDto>> getAnalyzedResumes() {
        try {
            List<AnalyzedResumeDto> resumes = recruiterService.getAnalyzedResumes();
            return ResponseEntity.ok(resumes);
        } catch (Exception e) {
            logger.error("Error fetching analyzed resumes", e);
            return ResponseEntity.internalServerError().build();
        }
    }
 // Add this method inside the RecruiterController class

    @PutMapping("/applications/{applicationId}")
    public ResponseEntity<String> decideApplication(
            @PathVariable Long applicationId,
            @RequestParam boolean accepted,
            @RequestParam String feedback,
            @RequestParam boolean sendMail) {

        try {
            // We call the robust service method that already exists!
            recruiterService.decideApplication(applicationId, accepted, feedback, sendMail);
            return ResponseEntity.ok("Application decision processed successfully.");
        } catch (RuntimeException e) {
            // This will catch the "Application not found" exceptions from the service layer
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            logger.error("Error processing application decision for ID: {}", applicationId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred.");
        }
    }

    // ========== Existing methods (kept for reference) ==========
    @PostMapping(value = "/jobs", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, Object>> uploadJobFile(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "File required"));
        }
        Long jobId = recruiterService.uploadJobFile(file);
        logger.info("Job PDF uploaded: {}", file.getOriginalFilename());
        return ResponseEntity.ok(Map.of("message", "Job uploaded successfully", "jobId", jobId));
    }

    @PostMapping(value = "/jobs-form")
    public ResponseEntity<String> createJobForm(@RequestBody JobFormDto dto) {
        recruiterService.saveJobForm(dto);
        return ResponseEntity.ok("Job created from form");
    }

    @PostMapping("/resumes")
    public ResponseEntity<String> uploadResumes(
            @RequestParam("files") List<MultipartFile> files,
            @RequestParam("jobId") Long jobId) {

        parseAndEmitAsync(files, jobId);
        return ResponseEntity.ok("Resumes received. Processing has started in the background.");
    }

    @GetMapping(value = "/progress/{jobId}", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter progress(@PathVariable Long jobId) {
        return progressService.createEmitter(jobId);
    }

    @GetMapping("/candidates")
    public ResponseEntity<List<CandidateDto>> getCandidates(
            @RequestParam(required = false) String skills,
            @RequestParam(required = false) Integer experience,
            @RequestParam(required = false) String education,
            @RequestParam(required = false, defaultValue = "appliedAt desc") String sort) {

        List<CandidateDto> candidates = recruiterService.getCandidates(skills, experience, education, sort);
        logger.info("Fetched {} candidates with filters - skills: {}, experience: {}, education: {}, sort: {}",
                candidates.size(), skills, experience, education, sort);
        return ResponseEntity.ok(candidates);
    }

    @PostMapping("/feedback/{candidateId}")
    public ResponseEntity<String> sendFeedback(
            @PathVariable Long candidateId,
            @RequestParam String feedback,
            @RequestParam boolean accepted) {
        recruiterService.sendFeedback(candidateId, feedback, accepted);
        logger.info("Sent feedback to candidateId {}: accepted={}, feedback={}", candidateId, accepted, feedback);
        return ResponseEntity.ok("Feedback sent successfully");
    }

    // =================================================================
    //                      *** CORRECTED METHOD ***
    // =================================================================
    @GetMapping("/match/{jobId}")
    public ResponseEntity<List<ResumeDto>> matchResumes(@PathVariable Long jobId) {
        try {
            // The service method returns a List<ResumeDto>
            List<ResumeDto> matchedResumes = recruiterService.matchResumes(jobId);
            
            // We wrap the list in a ResponseEntity.ok() to satisfy the method's return type
            return ResponseEntity.ok(matchedResumes);

        } catch (Exception e) {
            // If any error occurs, we log it and return a 500 Internal Server Error
            logger.error("Error matching resumes for job ID: {}", jobId, e);
            return ResponseEntity.status(500).build(); // Or .body(null) or a custom error DTO
        }
    }
    // =================================================================

    @Async
    public void parseAndEmitAsync(List<MultipartFile> files, Long jobId) {
        logger.info("Starting async processing for jobId: {}", jobId);
        try {
            // Call the new service method to handle the actual processing
            recruiterService.processUploadedResumes(files, jobId, progressService);
            logger.info("Completed async processing for jobId: {}", jobId);
        } catch (Exception e) {
            logger.error("Error during async processing for jobId: {}", jobId, e);
            // Ensure completion is sent even on error to stop the frontend progress bar
            progressService.sendCompletionEvent(jobId);
        }
    }
    @GetMapping("/jobs/{jobId}/upload-results")
    public ResponseEntity<List<ResumeDto>> getUploadResults(@PathVariable Long jobId) {
        try {
            logger.info("Fetching upload results for job ID: {}", jobId);
            // This service method will get all applications for the job and convert them to DTOs
            List<ResumeDto> results = recruiterService.getUploadResultsForJob(jobId);
            return ResponseEntity.ok(results);
        } catch (Exception e) {
            logger.error("Error fetching upload results for job ID: {}", jobId, e);
            return ResponseEntity.internalServerError().build();
        }
    }
 // Add this method inside your RecruiterController class

    @GetMapping("/applications/recent")
    public ResponseEntity<List<ApplicationDto>> getRecentApplications() {
        try {
            // We will create this method in the service in the next step
            List<ApplicationDto> recentApplications = recruiterService.getRecentApplications();
            logger.info("Fetched {} recent applications", recentApplications.size());
            return ResponseEntity.ok(recentApplications);
        } catch (Exception e) {
            logger.error("Error fetching recent applications", e);
            return ResponseEntity.internalServerError().build();
        }
    }
}