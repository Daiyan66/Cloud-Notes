package com.example.ResumeSystemApplication.service;

import com.example.ResumeSystemApplication.dto.AnalyzedResumeDto;
import com.example.ResumeSystemApplication.dto.ApplicationDto;
import com.example.ResumeSystemApplication.dto.CandidateDto;
import com.example.ResumeSystemApplication.dto.JobDto;
import com.example.ResumeSystemApplication.dto.JobFormDto;
import com.example.ResumeSystemApplication.dto.RecruiterStatsDto;
import com.example.ResumeSystemApplication.dto.ResumeDto;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface RecruiterService {

    // --- Existing Methods ---

    List<String> gapHints(Long applicationId);

    void uploadJobDescription(JobDto jobDto);

    void saveJobForm(JobFormDto dto);

    Long uploadJobFile(MultipartFile file);

    void uploadResumes(MultipartFile[] files);

    // Updated method signature to include the sort parameter
    List<CandidateDto> getCandidates(String skills, Integer experience, String education, String sort);

    void sendFeedback(Long candidateId, String feedback, boolean accepted);

    List<ResumeDto> matchResumes(Long jobId);

    List<CandidateDto> getCandidatesForJob(Long jobId);

    void updateApplicationStatus(Long applicationId, String status);

    List<ApplicationDto> getApplicationsByJob(Long jobId);
    
    List<ApplicationDto> getRecentApplications();

    void decideApplication(Long applicationId, boolean accepted, String feedback, boolean sendMail);

    RecruiterStatsDto getRecruiterStats();

    // --- NEW METHOD SIGNATURES ---
    // Add these two new method signatures to the interface

    /**
     * Processes a list of uploaded resume files for a specific job, parses them,
     * and saves the results. This method is intended for asynchronous execution.
     *
     * @param files The list of resume files to process.
     * @param jobId The ID of the job to match the resumes against.
     * @param progressService The service to send progress updates.
     */
    void processUploadedResumes(List<MultipartFile> files, Long jobId, ProgressService progressService);

    /**
     * Retrieves the processed upload results (resumes and their match scores) for a specific job.
     *
     * @param jobId The ID of the job.
     * @return A list of ResumeDto objects containing the file name and match score.
     */
    List<ResumeDto> getUploadResultsForJob(Long jobId);
    
 // Add this method inside the RecruiterService interface
    List<AnalyzedResumeDto> getAnalyzedResumes();
}