package com.example.ResumeSystemApplication.repository;

import com.example.ResumeSystemApplication.model.JobDescription;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface JobRepository extends JpaRepository<JobDescription, Long> {
    List<JobDescription> findByCreatedBy(Long createdBy);
    
    // Add methods for filtering jobs based on search criteria
    @Query("SELECT j FROM JobDescription j WHERE " +
           "(:title IS NULL OR LOWER(j.title) LIKE LOWER(CONCAT('%', :title, '%'))) AND " +
           "(:skills IS NULL OR LOWER(j.skillsRequired) LIKE LOWER(CONCAT('%', :skills, '%'))) AND " +
           "(:education IS NULL OR LOWER(j.educationLevel) LIKE LOWER(CONCAT('%', :education, '%'))) AND " +
           "(:expMin IS NULL OR j.experienceRequired >= :expMin)")
    List<JobDescription> findJobsWithFilters(
            @Param("title") String title,
            @Param("skills") String skills,
            @Param("education") String education,
            @Param("expMin") Integer expMin);
    
 // Add this method to find jobs created after a certain date
    List<JobDescription> findByCreatedAtAfter(LocalDateTime dateTime);
 // In JobRepository.java

    @Query("SELECT j FROM JobDescription j ORDER BY j.createdAt DESC")
    List<JobDescription> findTop5ByOrderByCreatedAtDesc();
    
 // In JobRepository.java

    @Query(value = "SELECT * FROM job_descriptions ORDER BY RAND() LIMIT 1", nativeQuery = true)
    JobDescription findRandomJob();
    @Query("SELECT j FROM JobDescription j ORDER BY j.createdAt DESC")
    List<JobDescription> findTop20ByOrderByCreatedAtDesc();
}