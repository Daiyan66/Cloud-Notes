package com.example.ResumeSystemApplication.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Table(name = "resumes")
public class Resume {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "candidate_id", nullable = true)
    private Long candidateId;

    // --- NEW: JPA Relationship to User ---
    // This tells JPA how to join the 'resumes' table with the 'users' table.
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "candidate_id", referencedColumnName = "id", insertable = false, updatable = false)
    private User candidate;

    @Column(name = "file_name", nullable = false)
    private String fileName;

    @Column(name = "file_path", nullable = false)
    private String filePath;

    @Column(name = "parsed_content", columnDefinition = "TEXT")
    private String parsedContent;

    @Column(name = "extracted_skills", columnDefinition = "TEXT")
    private String extractedSkills;

    @Column(name = "extracted_experience")
    private Integer extractedExperience;

    @Column(name = "extracted_education", columnDefinition = "TEXT")
    private String extractedEducation;

    @Column(name = "uploaded_at")
    private LocalDateTime uploadedAt;

    // --- JPA Lifecycle Callback ---
    @PrePersist
    protected void onCreate() {
        uploadedAt = LocalDateTime.now();
    }

    // --- Constructors ---
    public Resume() {
    }

    // --- Getters and Setters ---
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCandidateId() {
        return candidateId;
    }

    public void setCandidateId(Long candidateId) {
        this.candidateId = candidateId;
    }

    // --- NEW: Getter and Setter for the relationship ---
    public User getCandidate() {
        return candidate;
    }

    public void setCandidate(User candidate) {
        this.candidate = candidate;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getParsedContent() {
        return parsedContent;
    }

    public void setParsedContent(String parsedContent) {
        this.parsedContent = parsedContent;
    }

    public String getExtractedSkills() {
        return extractedSkills;
    }

    public void setExtractedSkills(String extractedSkills) {
        this.extractedSkills = extractedSkills;
    }

    public Integer getExtractedExperience() {
        return extractedExperience;
    }

    public void setExtractedExperience(Integer extractedExperience) {
        this.extractedExperience = extractedExperience;
    }

    public String getExtractedEducation() {
        return extractedEducation;
    }

    public void setExtractedEducation(String extractedEducation) {
        this.extractedEducation = extractedEducation;
    }

    public LocalDateTime getUploadedAt() {
        return uploadedAt;
    }

    public void setUploadedAt(LocalDateTime uploadedAt) {
        this.uploadedAt = uploadedAt;
    }

    // --- equals() and hashCode() based on the primary key ---
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Resume resume = (Resume) o;
        return Objects.equals(id, resume.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    // --- toString() for easy logging ---
    @Override
    public String toString() {
        return "Resume{" +
                "id=" + id +
                ", candidateId=" + candidateId +
                ", fileName='" + fileName + '\'' +
                ", extractedSkills='" + extractedSkills + '\'' +
                '}';
    }
}