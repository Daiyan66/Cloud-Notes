package com.example.ResumeSystemApplication.dto;

import java.util.List;
import java.util.Map;

public class RecruiterStatsDto {

    // --- Fields ---
    private long totalCandidates;
    private long pendingApplications;
    private long activeJobs;
    private long newResumesToday;
    private List<Map<String, Object>> applicationTrend;
    private List<Map<String, Object>> registrationTrend;
    private List<Map<String, Object>> topSkills;

    // --- Getters and Setters ---
    public long getTotalCandidates() {
        return totalCandidates;
    }

    public void setTotalCandidates(long totalCandidates) {
        this.totalCandidates = totalCandidates;
    }

    public long getPendingApplications() {
        return pendingApplications;
    }

    public void setPendingApplications(long pendingApplications) {
        this.pendingApplications = pendingApplications;
    }

    public long getActiveJobs() {
        return activeJobs;
    }

    public void setActiveJobs(long activeJobs) {
        this.activeJobs = activeJobs;
    }

    public long getNewResumesToday() {
        return newResumesToday;
    }

    public void setNewResumesToday(long newResumesToday) {
        this.newResumesToday = newResumesToday;
    }

    public List<Map<String, Object>> getApplicationTrend() {
        return applicationTrend;
    }

    public void setApplicationTrend(List<Map<String, Object>> applicationTrend) {
        this.applicationTrend = applicationTrend;
    }

    public List<Map<String, Object>> getRegistrationTrend() {
        return registrationTrend;
    }

    public void setRegistrationTrend(List<Map<String, Object>> registrationTrend) {
        this.registrationTrend = registrationTrend;
    }

    public List<Map<String, Object>> getTopSkills() {
        return topSkills;
    }

    public void setTopSkills(List<Map<String, Object>> topSkills) {
        this.topSkills = topSkills;
    }

    // --- Constructors ---
    public RecruiterStatsDto() {
    }

    public RecruiterStatsDto(long totalCandidates, long pendingApplications, long activeJobs, long newResumesToday, List<Map<String, Object>> applicationTrend, List<Map<String, Object>> registrationTrend, List<Map<String, Object>> topSkills) {
        this.totalCandidates = totalCandidates;
        this.pendingApplications = pendingApplications;
        this.activeJobs = activeJobs;
        this.newResumesToday = newResumesToday;
        this.applicationTrend = applicationTrend;
        this.registrationTrend = registrationTrend;
        this.topSkills = topSkills;
    }

    // --- The Manually Created Builder ---
    public static RecruiterStatsDtoBuilder builder() {
        return new RecruiterStatsDtoBuilder();
    }

    public static class RecruiterStatsDtoBuilder {
        private long totalCandidates;
        private long pendingApplications;
        private long activeJobs;
        private long newResumesToday;
        private List<Map<String, Object>> applicationTrend;
        private List<Map<String, Object>> registrationTrend;
        private List<Map<String, Object>> topSkills;

        public RecruiterStatsDtoBuilder totalCandidates(long totalCandidates) {
            this.totalCandidates = totalCandidates;
            return this;
        }

        public RecruiterStatsDtoBuilder pendingApplications(long pendingApplications) {
            this.pendingApplications = pendingApplications;
            return this;
        }

        public RecruiterStatsDtoBuilder activeJobs(long activeJobs) {
            this.activeJobs = activeJobs;
            return this;
        }

        public RecruiterStatsDtoBuilder newResumesToday(long newResumesToday) {
            this.newResumesToday = newResumesToday;
            return this;
        }

        public RecruiterStatsDtoBuilder applicationTrend(List<Map<String, Object>> applicationTrend) {
            this.applicationTrend = applicationTrend;
            return this;
        }

        public RecruiterStatsDtoBuilder registrationTrend(List<Map<String, Object>> registrationTrend) {
            this.registrationTrend = registrationTrend;
            return this;
        }

        public RecruiterStatsDtoBuilder topSkills(List<Map<String, Object>> topSkills) {
            this.topSkills = topSkills;
            return this;
        }

        public RecruiterStatsDto build() {
            return new RecruiterStatsDto(totalCandidates, pendingApplications, activeJobs, newResumesToday, applicationTrend, registrationTrend, topSkills);
        }
    }
}