package com.example.ResumeSystemApplication.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor // Add a no-args constructor
@AllArgsConstructor // Add an all-args constructor
public class NlpMatchResponse {
    
    @JsonProperty("resume_id")
    private Integer resumeId;
    
    public Integer getResumeId() {
		return resumeId;
	}

	public void setResumeId(Integer resumeId) {
		this.resumeId = resumeId;
	}

	public Double getSemanticSimilarity() {
		return semanticSimilarity;
	}

	public void setSemanticSimilarity(Double semanticSimilarity) {
		this.semanticSimilarity = semanticSimilarity;
	}

	public Double getSkillMatch() {
		return skillMatch;
	}

	public void setSkillMatch(Double skillMatch) {
		this.skillMatch = skillMatch;
	}

	public Double getExperienceMatch() {
		return experienceMatch;
	}

	public void setExperienceMatch(Double experienceMatch) {
		this.experienceMatch = experienceMatch;
	}

	public Double getOverallScore() {
		return overallScore;
	}

	public void setOverallScore(Double overallScore) {
		this.overallScore = overallScore;
	}

	public List<String> getMatchedSkills() {
		return matchedSkills;
	}

	public void setMatchedSkills(List<String> matchedSkills) {
		this.matchedSkills = matchedSkills;
	}

	public List<String> getMissingSkills() {
		return missingSkills;
	}

	public void setMissingSkills(List<String> missingSkills) {
		this.missingSkills = missingSkills;
	}

	@JsonProperty("semantic_similarity")
    private Double semanticSimilarity;
    
    @JsonProperty("skill_match")
    private Double skillMatch;
    
    @JsonProperty("experience_match")
    private Double experienceMatch;
    
    @JsonProperty("overall_score")
    private Double overallScore;

    // --- NEW FIELDS FOR SKILL GAP ANALYSIS ---
    @JsonProperty("matched_skills")
    private List<String> matchedSkills;

    @JsonProperty("missing_skills")
    private List<String> missingSkills;
}