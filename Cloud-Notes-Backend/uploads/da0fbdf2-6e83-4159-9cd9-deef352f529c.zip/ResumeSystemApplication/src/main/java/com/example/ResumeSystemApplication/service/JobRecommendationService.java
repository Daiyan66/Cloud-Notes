package com.example.ResumeSystemApplication.service;

import com.example.ResumeSystemApplication.dto.JobDto;
import com.example.ResumeSystemApplication.model.JobDescription;
import com.example.ResumeSystemApplication.model.Resume;
import com.example.ResumeSystemApplication.model.User;
import com.example.ResumeSystemApplication.repository.JobRepository;
import com.example.ResumeSystemApplication.repository.ResumeRepository;
import com.example.ResumeSystemApplication.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class JobRecommendationService {

    private static final Logger logger = LoggerFactory.getLogger(JobRecommendationService.class);
    private static final int RECOMMENDATION_THRESHOLD = 85; // High match score threshold

    private final UserRepository userRepository;
    private final JobRepository jobRepository;
    private final ResumeRepository resumeRepository;
    private final NlpServiceClient nlpServiceClient;
    private final EmailService emailService;
    
    public JobRecommendationService(UserRepository userRepository,
            JobRepository jobRepository,
            ResumeRepository resumeRepository,
            NlpServiceClient nlpServiceClient,
            EmailService emailService) {
this.userRepository = userRepository;
this.jobRepository = jobRepository;
this.resumeRepository = resumeRepository;
this.nlpServiceClient = nlpServiceClient;
this.emailService = emailService;
}


    // This method will run every 5 minutes for testing.
    // For production, you might change it to "0 0 9 * * *" to run daily at 9 AM.
    @Scheduled(fixedRate = 300000) // 300000 ms = 5 minutes
    public void findAndSendRecommendations() {
        logger.info("Running scheduled job recommendation task...");

        // 1. Find all new jobs posted in the last 24 hours
        LocalDateTime since = LocalDateTime.now().minusHours(24);
        List<JobDescription> newJobs = jobRepository.findByCreatedAtAfter(since);

        if (newJobs.isEmpty()) {
            logger.info("No new jobs found in the last 24 hours. Skipping.");
            return;
        }

        logger.info("Found {} new jobs to check for recommendations.", newJobs.size());

        // 2. Find all candidates who have opted in
        List<User> candidates = userRepository.findByOptInForRecommendationsTrue();

        for (JobDescription job : newJobs) {
            for (User candidate : candidates) {
                try {
                    processCandidateForJob(candidate, job);
                } catch (Exception e) {
                    logger.error("Error processing recommendation for candidate {} and job {}", candidate.getId(), job.getId(), e);
                }
            }
        }
        logger.info("Scheduled job recommendation task finished.");
    }

    private void processCandidateForJob(User candidate, JobDescription job) {
        // 3. Get the candidate's latest resume
    	// Change to this
    	List<Resume> resumes = resumeRepository.findAllByCandidateIdOrderByUploadedAtDesc(candidate.getId());
    	Resume resume = (resumes != null && !resumes.isEmpty()) ? resumes.get(0) : null;
        if (resume == null) {
            logger.warn("Candidate {} has no resume to match.", candidate.getId());
            return;
        }

        // 4. Run the NLP match
        Map<String, Object> resumeData = Map.of(
                "raw_text", resume.getParsedContent() != null ? resume.getParsedContent() : "",
                "skills", resume.getExtractedSkills() != null ? List.of(resume.getExtractedSkills().split(",\\s*")) : List.of(),
                "education", resume.getExtractedEducation() != null ? List.of(resume.getExtractedEducation().split(",\\s*")) : List.of(),
                "experience", Map.of("total_years", resume.getExtractedExperience() != null ? resume.getExtractedExperience() : 0)
        );

        var matchResult = nlpServiceClient.matchSingleResume(job.getDescription(), resumeData);
        if (matchResult == null || matchResult.getOverallScore() == null) {
            logger.warn("NLP service returned null for candidate {} and job {}", candidate.getId(), job.getId());
            return;
        }

        double rawScore = matchResult.getOverallScore();
        double scorePercentage = rawScore > 1.0 ? rawScore : rawScore * 100.0;

        // 5. Check if the score is above the threshold
        if (scorePercentage >= RECOMMENDATION_THRESHOLD) {
            logger.info("Found a strong match! Candidate: {}, Job: {}, Score: {}%", candidate.getEmail(), job.getTitle(), (int) Math.round(scorePercentage));
            sendRecommendationEmail(candidate, job, scorePercentage);
        }
    }

    private void sendRecommendationEmail(User candidate, JobDescription job, double score) {
        String subject = "New Job Recommendation: " + job.getTitle();
        String feedback = String.format(
                "Hi %s,\n\n" +
                "We found a new job that is a great match for your profile!\n\n" +
                "Job Title: %s\n" +
                "Match Score: %d%%\n\n" +
                "We think you'd be a strong candidate. Log in to your dashboard to view the full details and apply.\n\n" +
                "Best regards,\n" +
                "The AI-Resume Team",
                candidate.getFirstName(),
                job.getTitle(),
                (int) Math.round(score)
        );

        emailService.sendEmail(candidate.getEmail(), subject, feedback);
    }
}