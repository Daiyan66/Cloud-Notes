package com.example.ResumeSystemApplication.service;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;
import java.util.stream.Collectors;
import java.io.FileInputStream;

@Service
public class FileProcessingService {

    private static final Logger logger = LoggerFactory.getLogger(FileProcessingService.class);

    @Value("${file.upload-dir}")
    private String uploadDir;

    public String saveFile(MultipartFile file) throws IOException {
        String fileName = UUID.randomUUID().toString() + "_" + file.getOriginalFilename();
        Path uploadPath = Paths.get(uploadDir);

        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        Path filePath = uploadPath.resolve(fileName);
        Files.copy(file.getInputStream(), filePath);

        logger.info("File saved: {}", fileName);
        return filePath.toString();
    }
    
    public String extractText(String filePath) {
        try {
            File file = new File(filePath);
            String lower = filePath.toLowerCase();

            if (lower.endsWith(".pdf")) {
                return extractPdfText(file);
            } else if (lower.endsWith(".docx")) {
                return extractDocxText(file);
            } else if (lower.endsWith(".txt")) {
                return Files.readString(file.toPath()); // Java 11+
            } else {
                throw new IllegalArgumentException("Unsupported file type");
            }
        } catch (Exception e) {
            throw new RuntimeException("Text extraction failed", e);
        }
    }

    /* ---------- helpers ---------- */
    private String extractPdfText(File pdf) throws IOException {
        PDDocument doc = PDDocument.load(pdf);
        PDFTextStripper stripper = new PDFTextStripper();
        String text = stripper.getText(doc);
        doc.close();
        return text;
    }

    private String extractDocxText(File docx) throws IOException {
        try (XWPFDocument document = new XWPFDocument(new FileInputStream(docx))) {
            return document.getParagraphs()
                           .stream()
                           .map(XWPFParagraph::getText)
                           .collect(Collectors.joining("\n"));
        }
    }
}
