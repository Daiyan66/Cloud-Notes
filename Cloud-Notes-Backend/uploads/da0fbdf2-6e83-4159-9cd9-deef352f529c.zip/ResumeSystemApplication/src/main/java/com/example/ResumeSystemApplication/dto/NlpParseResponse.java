package com.example.ResumeSystemApplication.dto;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class NlpParseResponse {
    private String rawText;
    private List<String> skills;
    public String getRawText() {
		return rawText;
	}
	public void setRawText(String rawText) {
		this.rawText = rawText;
	}
	public List<String> getSkills() {
		return skills;
	}
	public void setSkills(List<String> skills) {
		this.skills = skills;
	}
	public List<String> getEducation() {
		return education;
	}
	public void setEducation(List<String> education) {
		this.education = education;
	}
	public Map<String, Object> getExperience() {
		return experience;
	}
	public void setExperience(Map<String, Object> experience) {
		this.experience = experience;
	}
	public Map<String, String> getContactInfo() {
		return contactInfo;
	}
	public void setContactInfo(Map<String, String> contactInfo) {
		this.contactInfo = contactInfo;
	}
	private List<String> education;
    private Map<String, Object> experience;
    private Map<String, String> contactInfo;
}