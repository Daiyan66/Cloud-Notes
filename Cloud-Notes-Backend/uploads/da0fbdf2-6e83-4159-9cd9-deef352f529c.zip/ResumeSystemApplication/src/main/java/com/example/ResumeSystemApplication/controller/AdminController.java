// In src/main/java/com/example/ResumeSystemApplication/controller/AdminController.java

package com.example.ResumeSystemApplication.controller;

import com.example.ResumeSystemApplication.dto.AdminStatsDto;
import com.example.ResumeSystemApplication.model.User;
import com.example.ResumeSystemApplication.repository.ApplicationRepository;
import com.example.ResumeSystemApplication.repository.JobRepository;
import com.example.ResumeSystemApplication.repository.ResumeRepository;
import com.example.ResumeSystemApplication.repository.UserRepository;
import com.example.ResumeSystemApplication.service.AdminService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    // Dependencies for CRUD operations
    private final AdminService adminService;
    
    // Dependencies for statistics
    private final UserRepository userRepository;
    private final JobRepository jobRepository;
    private final ApplicationRepository applicationRepository;
    private final ResumeRepository resumeRepository;

    // Manual constructor to initialize all final fields
    public AdminController(AdminService adminService,
                           UserRepository userRepository,
                           JobRepository jobRepository,
                           ApplicationRepository applicationRepository,
                           ResumeRepository resumeRepository) {
        this.adminService = adminService;
        this.userRepository = userRepository;
        this.jobRepository = jobRepository;
        this.applicationRepository = applicationRepository;
        this.resumeRepository = resumeRepository;
    }

    // === Original CRUD Endpoints ===

    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        logger.info("Fetching all users");
        return ResponseEntity.ok(adminService.getAllUsers());
    }

    @PostMapping("/users")
    public ResponseEntity<User> createUser(@RequestBody User user) {
        logger.info("Creating new user with username: {}", user.getUsername());
        return ResponseEntity.ok(adminService.createUser(user));
    }

    @PutMapping("/users/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User user) {
        logger.info("Updating user with id: {}", id);
        return ResponseEntity.ok(adminService.updateUser(id, user));
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        logger.info("Deleting user with id: {}", id);
        adminService.deleteUser(id);
        return ResponseEntity.ok().build();
    }

    // === Statistics Endpoint ===

    @GetMapping("/stats")
    public ResponseEntity<AdminStatsDto> getSystemStats() {
        AdminStatsDto.AdminStatsDtoBuilder statsBuilder = AdminStatsDto.builder();

        // 1. Get User Counts
        long totalUsers = userRepository.count();
        statsBuilder.totalUsers(totalUsers);
        statsBuilder.totalCandidates(userRepository.countByRoles_Name("ROLE_CANDIDATE"));
        statsBuilder.totalRecruiters(userRepository.countByRoles_Name("ROLE_RECRUITER"));
        statsBuilder.totalAdmins(userRepository.countByRoles_Name("ROLE_ADMIN"));

        // 2. Get Content Counts
        statsBuilder.totalJobs(jobRepository.count());
        statsBuilder.totalApplications(applicationRepository.count());
        statsBuilder.totalResumes(resumeRepository.count());

        // 3. Get Application Trend (Last 7 Days)
        statsBuilder.applicationTrend(getTrendData(applicationRepository::countByAppliedAtAfter));
        
        // 4. Get Registration Trend (Last 7 Days)
        statsBuilder.registrationTrend(getTrendData(userRepository::countByCreatedAtAfter));

        // 5. Get User Role Distribution
        List<AdminStatsDto.RoleCount> roleDistribution = userRepository.findAll().stream()
                .collect(Collectors.groupingBy(user -> user.getRoles().iterator().next().getName()))
                .entrySet()
                .stream()
                .map(entry -> new AdminStatsDto.RoleCount(entry.getKey(), entry.getValue().size()))
                .collect(Collectors.toList());
        statsBuilder.userRoleDistribution(roleDistribution);

        return ResponseEntity.ok(statsBuilder.build());
    }

    // Helper method to get trend data for the last 7 days
 // AFTER (Correct)
    private List<Map<String, Object>> getTrendData(java.util.function.Function<java.time.LocalDateTime, Long> countFunction) {
        List<Map<String, Object>> trendData = new ArrayList<>();
        for (int i = 6; i >= 0; i--) {
            // Convert LocalDate to LocalDateTime at the start of the day
            java.time.LocalDateTime dateTime = java.time.LocalDate.now().minusDays(i).atStartOfDay();
            long count = countFunction.apply(dateTime);
            trendData.add(Map.of(
                "date", dateTime.toLocalDate().toString(), // Keep the output as a date string for the frontend
                "count", count
            ));
        }
        return trendData;
    }
}