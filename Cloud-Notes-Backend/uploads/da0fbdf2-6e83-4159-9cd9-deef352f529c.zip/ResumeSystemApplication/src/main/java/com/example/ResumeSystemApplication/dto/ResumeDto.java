package com.example.ResumeSystemApplication.dto;

import lombok.Data;

@Data
public class ResumeDto {
    private Long id;
    private String name;
    public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getParsedContent() {
		return parsedContent;
	}
	public void setParsedContent(String parsedContent) {
		this.parsedContent = parsedContent;
	}
	public String getExtractedSkills() {
		return extractedSkills;
	}
	public void setExtractedSkills(String extractedSkills) {
		this.extractedSkills = extractedSkills;
	}
	public Integer getExtractedExperience() {
		return extractedExperience;
	}
	public void setExtractedExperience(Integer extractedExperience) {
		this.extractedExperience = extractedExperience;
	}
	public String getExtractedEducation() {
		return extractedEducation;
	}
	public void setExtractedEducation(String extractedEducation) {
		this.extractedEducation = extractedEducation;
	}
	public Double getMatchScore() {
		return matchScore;
	}
	public void setMatchScore(Double matchScore) {
		this.matchScore = matchScore;
	}
	private String fileName;
    private String parsedContent;
    private String extractedSkills;
    private Integer extractedExperience;
    private String extractedEducation;
    private Double matchScore;
}