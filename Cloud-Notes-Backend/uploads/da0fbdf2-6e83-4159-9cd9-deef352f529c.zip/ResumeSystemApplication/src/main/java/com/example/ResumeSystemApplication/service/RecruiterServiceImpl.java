package com.example.ResumeSystemApplication.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.example.ResumeSystemApplication.dto.AnalyzedResumeDto;
import com.example.ResumeSystemApplication.dto.ApplicationDto;
import com.example.ResumeSystemApplication.dto.CandidateDto;
import com.example.ResumeSystemApplication.dto.JobDto;
import com.example.ResumeSystemApplication.dto.JobFormDto;
import com.example.ResumeSystemApplication.dto.NlpMatchResponse;
import com.example.ResumeSystemApplication.dto.NlpParseResponse;
import com.example.ResumeSystemApplication.dto.RecruiterStatsDto;
import com.example.ResumeSystemApplication.dto.ResumeDto;
import com.example.ResumeSystemApplication.model.Application;
import com.example.ResumeSystemApplication.model.Feedback;
import com.example.ResumeSystemApplication.model.JobDescription;
import com.example.ResumeSystemApplication.model.Resume;
import com.example.ResumeSystemApplication.model.User;
import com.example.ResumeSystemApplication.repository.ApplicationRepository;
import com.example.ResumeSystemApplication.repository.FeedbackRepository;
import com.example.ResumeSystemApplication.repository.JobRepository;
import com.example.ResumeSystemApplication.repository.ResumeRepository;
import com.example.ResumeSystemApplication.repository.UserRepository;

import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Order;

import com.example.ResumeSystemApplication.model.Application.ApplicationStatus;

@Service
public class RecruiterServiceImpl implements RecruiterService {

    private static final Logger logger = LoggerFactory.getLogger(RecruiterServiceImpl.class);

    private final JobRepository jobRepository;
    private final ResumeRepository resumeRepository;
    private final ApplicationRepository applicationRepository;
    private final NlpServiceClient nlpServiceClient;
    private final FileProcessingService fileProcessingService;
    private final EmailService emailService;
    private final FeedbackRepository feedbackRepository;
    private final UserRepository userRepository;
    private final AuthService authService;

    @Value("${app.match.threshold}")
    private int matchThreshold;

    @Autowired
    public RecruiterServiceImpl(
            JobRepository jobRepository,
            ResumeRepository resumeRepository,
            ApplicationRepository applicationRepository,
            NlpServiceClient nlpServiceClient,
            FileProcessingService fileProcessingService,
            EmailService emailService,
            FeedbackRepository feedbackRepository,
            UserRepository userRepository,
            AuthService authService
    ) {
        this.jobRepository = jobRepository;
        this.resumeRepository = resumeRepository;
        this.applicationRepository = applicationRepository;
        this.nlpServiceClient = nlpServiceClient;
        this.fileProcessingService = fileProcessingService;
        this.emailService = emailService;
        this.feedbackRepository = feedbackRepository;
        this.userRepository = userRepository;
        this.authService = authService;
    }

    /* ---------- existing methods ---------- */

    @Override
    public List<String> gapHints(Long applicationId) {
        return List.of("Spring Security", "Docker", "Kubernetes");
    }

    @Override
    public void uploadJobDescription(JobDto jobDto) {
        JobDescription job = new JobDescription();
        job.setTitle(jobDto.getTitle());
        job.setDescription(jobDto.getDescription());
        job.setSkillsRequired(jobDto.getSkillsRequired());
        job.setExperienceRequired(jobDto.getExperienceRequired());
        job.setEducationLevel(jobDto.getEducationLevel());
        jobRepository.save(job);
        logger.info("Job description saved: {}", jobDto.getTitle());
    }

    @Override
    public void saveJobForm(JobFormDto dto) {
        JobDescription job = new JobDescription();
        job.setTitle(dto.getTitle());
        job.setDescription(dto.getDescription());
        job.setSkillsRequired(dto.getSkills());
        job.setExperienceRequired(dto.getExperienceRequired());
        job.setEducationLevel(dto.getEducationLevel());

        User currentUser = authService.findByUsername(
                SecurityContextHolder.getContext().getAuthentication().getName());
        job.setCreatedBy(currentUser.getId());

        jobRepository.save(job);
        logger.info("Job created from form: {}", dto.getTitle());
    }
    
 // Add this method inside the RecruiterServiceImpl class
    @Override
    public List<AnalyzedResumeDto> getAnalyzedResumes() {
        return applicationRepository.findAllAnalyzedResumes();
    }
    
 // In RecruiterServiceImpl.java

    @Override
    @Transactional
    public void processUploadedResumes(List<MultipartFile> files, Long jobId, ProgressService progressService) {
        JobDescription job = jobRepository.findById(jobId)
                .orElseThrow(() -> new RuntimeException("Job not found with ID: " + jobId));

        int total = files.size();
        for (int i = 0; i < total; i++) {
            MultipartFile file = files.get(i);
            try {
                logger.info("Processing file {} of {} for jobId: {}", i + 1, total, jobId);

                // 1. Save the file and parse it
                String filePath = fileProcessingService.saveFile(file);
                NlpParseResponse parsedData = nlpServiceClient.parseResume(filePath);

                // 2. Save the Resume entity
                Resume resume = new Resume();
                resume.setFileName(file.getOriginalFilename());
                resume.setFilePath(filePath);
                resume.setParsedContent(parsedData.getRawText());
                resume.setExtractedSkills(parsedData.getSkills() != null ? String.join(", ", parsedData.getSkills()) : "");
                resume.setExtractedEducation(parsedData.getEducation() != null ? String.join(", ", parsedData.getEducation()) : "");
                Integer experience = 0;
                if (parsedData.getExperience() != null && parsedData.getExperience().containsKey("total_years")) {
                    experience = (Integer) parsedData.getExperience().get("total_years");
                }
                resume.setExtractedExperience(experience);
                resume = resumeRepository.save(resume); // Save to get the ID

                // 3. Create the Application entity
                Application application = new Application();
                application.setJobId(jobId);
                application.setResumeId(resume.getId());
                application.setStatus(ApplicationStatus.PENDING);
                applicationRepository.save(application);

             // 4. Get the match score from NLP service
                Map<String, Object> resumeData = convertResumeToMap(resume);
                NlpMatchResponse matchResult = nlpServiceClient.matchSingleResume(job.getDescription(), resumeData);
                double rawScore = matchResult.getOverallScore();

                // --- FIX: Normalize the score to a 0-100 scale ---
                double scorePercentage = rawScore > 1.0 ? rawScore : rawScore * 100.0;

                // 5. Update the application with the score
                application.setMatchScore(scorePercentage);
                applicationRepository.save(application);

                logger.info("Successfully processed resume {} with score {}%", file.getOriginalFilename(), scorePercentage);

            } catch (Exception e) {
                logger.error("Error processing file {}: {}", file.getOriginalFilename(), e.getMessage());
            } finally {
                // 6. Send progress update
                progressService.sendProgress(jobId, (i + 1) + "/" + total);
            }
        }
        // Send final completion event
        progressService.sendCompletionEvent(jobId);
    }

 // In RecruiterServiceImpl.java

    @Override
    public List<ResumeDto> getUploadResultsForJob(Long jobId) {
        // Find all applications for the given job
        List<Application> applications = applicationRepository.findByJobIdOrderByAppliedAtDesc(jobId);

        return applications.stream()
                .map(app -> {
                    // For each application, get the corresponding resume
                    Resume resume = resumeRepository.findById(app.getResumeId())
                            .orElseThrow(() -> new RuntimeException("Resume not found for application ID: " + app.getId()));

                    // --- ADD THIS DEBUG LINE ---
                    System.out.println(">>> DEBUG: Fetched score from DB for app " + app.getId() + " is: " + app.getMatchScore());

                    // Convert the resume to a DTO
                    ResumeDto dto = convertToDto(resume);
                    // Add the match score from the application entity
                    dto.setMatchScore(app.getMatchScore());
                    return dto;
                })
                .collect(Collectors.toList());
    }

    @Override
    public Long uploadJobFile(MultipartFile file) {
        try {
            String filePath = fileProcessingService.saveFile(file);
            String rawText = fileProcessingService.extractText(filePath);

            JobDescription job = new JobDescription();
            job.setTitle(file.getOriginalFilename());
            job.setDescription(rawText);
            job.setCreatedBy(authService.findByUsername(
                    SecurityContextHolder.getContext().getAuthentication().getName()).getId());

            job = jobRepository.save(job);
            logger.info("Job file uploaded: {}", file.getOriginalFilename());
            return job.getId();
        } catch (Exception e) {
            logger.error("Failed to upload job file", e);
            throw new RuntimeException("File upload failed", e);
        }
    }

    @Override
    public void uploadResumes(MultipartFile[] files) {
        for (MultipartFile file : files) {
            try {
                String filePath = fileProcessingService.saveFile(file);

                Resume resume = new Resume();
                resume.setFileName(file.getOriginalFilename());
                resume.setFilePath(filePath);

                NlpParseResponse parsedData = nlpServiceClient.parseResume(filePath);

                resume.setParsedContent(parsedData.getRawText());
                resume.setExtractedSkills(parsedData.getSkills() != null ? String.join(", ", parsedData.getSkills()) : "");
                resume.setExtractedEducation(parsedData.getEducation() != null ? String.join(", ", parsedData.getEducation()) : "");

                Integer experience = 0;
                if (parsedData.getExperience() != null && parsedData.getExperience().containsKey("total_years")) {
                    experience = (Integer) parsedData.getExperience().get("total_years");
                }
                resume.setExtractedExperience(experience);

                resumeRepository.save(resume);
                logger.info("Resume saved: {}", file.getOriginalFilename());

                List<JobDescription> activeJobs = jobRepository.findAll();
                for (JobDescription job : activeJobs) {
                    Application application = new Application();
                    application.setJobId(job.getId());
                    application.setResumeId(resume.getId());
                    application.setStatus(Application.ApplicationStatus.PENDING);
                    applicationRepository.save(application);

                    try {
                        logger.info("Checking match score for resume {} against job {}", resume.getId(), job.getId());

                        Map<String, Object> resumeData = Map.of(
                            "raw_text", resume.getParsedContent(),
                            "skills", parsedData.getSkills() != null ? parsedData.getSkills() : List.of(),
                            "education", parsedData.getEducation() != null ? parsedData.getEducation() : List.of(),
                            "experience", parsedData.getExperience()
                        );

                        NlpMatchResponse matchResult = nlpServiceClient.matchSingleResume(job.getDescription(), resumeData);
                        double score = matchResult.getOverallScore();

                        logger.info("NLP score for resume {}: {}", resume.getId(), score);

                        int scorePercentage = (int) Math.round(score * 100);

                        if (scorePercentage < matchThreshold) {
                            logger.warn("Score {} is below threshold {}. Auto-rejecting application {}", scorePercentage, matchThreshold, application.getId());

                            application.setStatus(Application.ApplicationStatus.REJECTED);
                            application.setMatchScore(score);
                            applicationRepository.save(application);

                            User candidate = userRepository.findById(resume.getCandidateId())
                                    .orElseThrow(() -> new RuntimeException("Candidate not found for resume ID: " + resume.getId()));

                            String feedback = String.format(
                                "Unfortunately, your application for the position of %s was not successful. " +
                                "Our system indicates your profile is a %d%% match, which is below our current threshold of %d%%.",
                                job.getTitle(), scorePercentage, matchThreshold
                            );

                            emailService.sendRejectionEmail(
                                candidate.getEmail(),
                                candidate.getFirstName(),
                                List.of("Skill Gap Analysis"),
                                feedback
                            );
                            logger.info("Sent automatic rejection email to {}", candidate.getEmail());
                        } else {
                            application.setMatchScore(score);
                            applicationRepository.save(application);
                            logger.info("Score {} is above threshold. Application {} remains PENDING.", scorePercentage, application.getId());
                        }

                    } catch (Exception e) {
                        logger.error("Error during automatic match check for application {}: {}", application.getId(), e.getMessage());
                    }
                }

                emailService.sendRecruiterNotification(
                        "recruiter@example.com",
                        "New resumes have been uploaded and processed."
                );

            } catch (Exception e) {
                logger.error("Error saving resume: {}", file.getOriginalFilename(), e);
            }
        }
    }

    @Override
    public List<CandidateDto> getCandidates(String skills, Integer experience, String education, String sort) {
        // Define the base specification
        Specification<Application> spec = (root, query, cb) -> {
            // Join Application with Resume
            Join<Application, Resume> resumeJoin = root.join("resume", JoinType.INNER);
            
            // Create a list of predicates
            List<jakarta.persistence.criteria.Predicate> predicates = new ArrayList<>();
            
            // --- CORRECTED SKILLS FILTERING LOGIC ---
            if (skills != null && !skills.trim().isEmpty()) {
                // 1. Split the comma-separated string from the frontend into a list of individual skills
                List<String> skillList = Arrays.asList(skills.split("\\s*,\\s*"));

                // 2. Create a list to hold the individual "LIKE" predicates for each skill
                List<jakarta.persistence.criteria.Predicate> skillPredicates = new ArrayList<>();

                // 3. Loop through each skill and create a "LIKE" predicate for it
                for (String skill : skillList) {
                    if (!skill.isEmpty()) {
                        skillPredicates.add(cb.like(cb.lower(resumeJoin.get("extractedSkills")), "%" + skill.toLowerCase() + "%"));
                    }
                }

                // 4. Combine all the individual skill predicates with an "OR" and add it to our main list
                if (!skillPredicates.isEmpty()) {
                    predicates.add(cb.or(skillPredicates.toArray(new jakarta.persistence.criteria.Predicate[0])));
                }
            }
            
            if (experience != null) {
                predicates.add(cb.greaterThanOrEqualTo(resumeJoin.get("extractedExperience"), experience));
            }
            if (education != null && !education.trim().isEmpty()) {
                predicates.add(cb.like(cb.lower(resumeJoin.get("extractedEducation")), "%" + education.toLowerCase() + "%"));
            }
            
            // Apply sorting if a sort parameter is provided
            if (sort != null && !sort.trim().isEmpty()) {
                String[] parts = sort.split(" ");
                String field = parts[0];
                String direction = parts.length > 1 ? parts[1] : "asc";
                boolean isDesc = "desc".equalsIgnoreCase(direction);
                
                List<Order> orders = new ArrayList<>();
                
                switch (field) {
                    case "name":
                        // Need to join with User to get candidate name
                        Join<Resume, User> userJoin = resumeJoin.join("candidate", JoinType.INNER);
                        orders.add(isDesc ? cb.desc(userJoin.get("firstName")) : cb.asc(userJoin.get("firstName")));
                        orders.add(isDesc ? cb.desc(userJoin.get("lastName")) : cb.asc(userJoin.get("lastName")));
                        break;
                    case "email":
                        // Need to join with User to get candidate email
                        Join<Resume, User> emailJoin = resumeJoin.join("candidate", JoinType.INNER);
                        orders.add(isDesc ? cb.desc(emailJoin.get("email")) : cb.asc(emailJoin.get("email")));
                        break;
                    case "experience":
                        orders.add(isDesc ? cb.desc(resumeJoin.get("extractedExperience")) : cb.asc(resumeJoin.get("extractedExperience")));
                        break;
                    case "education":
                        orders.add(isDesc ? cb.desc(resumeJoin.get("extractedEducation")) : cb.asc(resumeJoin.get("extractedEducation")));
                        break;
                    case "score":
                        // The 'score' is on the Application entity, not the Resume
                        orders.add(isDesc ? cb.desc(root.get("matchScore")) : cb.asc(root.get("matchScore")));
                        break;
                    default:
                        // Default sort if the field is not recognized
                        orders.add(isDesc ? cb.desc(root.get("appliedAt")) : cb.asc(root.get("appliedAt")));
                        break;
                }
                
                query.orderBy(orders);
            }
            
            // Combine all predicates with AND
            return cb.and(predicates.toArray(new jakarta.persistence.criteria.Predicate[0]));
        };

        List<Application> allApplications = applicationRepository.findAll(spec);

        // The rest of the method remains the same
        return allApplications.stream()
                .map(app -> {
                    try {
                        return convertToCandidateDto(app);
                    } catch (RuntimeException e) {
                        logger.warn("Skipping application {} due to error: {}", app.getId(), e.getMessage());
                        return null;
                    }
                })
                .filter(dto -> dto != null)
                .collect(Collectors.toList());
    }

    @Override
    public void sendFeedback(Long candidateId, String feedback, boolean accepted) {
        Application application = applicationRepository.findById(candidateId)
                .orElseThrow(() -> new RuntimeException("Application not found with id: " + candidateId));

        application.setStatus(accepted ? Application.ApplicationStatus.ACCEPTED : Application.ApplicationStatus.REJECTED);
        applicationRepository.save(application);

        Feedback feedbackEntity = new Feedback();
        feedbackEntity.setApplicationId(candidateId);
        feedbackEntity.setContent(feedback);
        feedbackEntity.setCreatedBy(1L);
        feedbackRepository.save(feedbackEntity);

        Resume resume = resumeRepository.findById(application.getResumeId())
                .orElseThrow(() -> new RuntimeException("Resume not found with id: " + application.getResumeId()));

        emailService.sendCandidateNotification(
                "candidate@example.com",
                accepted,
                feedback
        );

        logger.info("Feedback sent to candidate {}: accepted={}, feedback={}", candidateId, accepted, feedback);
    }
    
    

    @Override
    public List<ResumeDto> matchResumes(Long jobId) {
        JobDescription job = jobRepository.findById(jobId)
                .orElseThrow(() -> new RuntimeException("Job not found with id: " + jobId));

        List<Resume> resumes = resumeRepository.findAll();

        List<Map<String, Object>> resumesData = resumes.stream()
                .map(this::convertResumeToMap)
                .collect(Collectors.toList());

        List<NlpMatchResponse> matchResults = nlpServiceClient.matchResumes(job.getDescription(), resumesData);

        for (NlpMatchResponse result : matchResults) {
            Application application = applicationRepository.findByJobIdAndResumeId(jobId, result.getResumeId().longValue())
                    .orElseThrow(() -> new RuntimeException("Application not found"));
            application.setMatchScore(result.getOverallScore());
            applicationRepository.save(application);
        }

        return matchResults.stream()
                .map(result -> {
                    Resume resume = resumes.stream()
                            .filter(r -> r.getId().equals(result.getResumeId().longValue()))
                            .findFirst()
                            .orElseThrow(() -> new RuntimeException("Resume not found with id: " + result.getResumeId()));
                    ResumeDto dto = convertToDto(resume);
                    dto.setMatchScore(result.getOverallScore());
                    return dto;
                })
                .collect(Collectors.toList());
    }

    /* ---------- NEW methods ---------- */

    @Override
    public List<CandidateDto> getCandidatesForJob(Long jobId) {
        try {
            logger.info("Fetching candidates for job ID: {}", jobId);

            JobDescription job = jobRepository.findById(jobId)
                    .orElseThrow(() -> new RuntimeException("Job not found with ID: " + jobId));

            List<Application> applications = applicationRepository.findByJobIdOrderByMatchScoreDesc(jobId);

            logger.info("Found {} applications for job ID: {}", applications.size(), jobId);

            return applications.stream()
                    .map(this::convertToCandidateDto)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            logger.error("Error fetching candidates for job ID: {}", jobId, e);
            throw new RuntimeException("Failed to fetch candidates", e);
        }
    }

    @Override
    public void updateApplicationStatus(Long applicationId, String status) {
        try {
            Application application = applicationRepository.findById(applicationId)
                    .orElseThrow(() -> new RuntimeException("Application not found with ID: " + applicationId));

            application.setStatus(Application.ApplicationStatus.valueOf(status));
            applicationRepository.save(application);

            logger.info("Updated application status to {} for application ID: {}", status, applicationId);
        } catch (Exception e) {
            logger.error("Error updating application status for application ID: {}", applicationId, e);
            throw new RuntimeException("Failed to update application status", e);
        }
    }

    @Override
    public List<ApplicationDto> getApplicationsByJob(Long jobId) {
        return applicationRepository.findByJobIdOrderByAppliedAtDesc(jobId)
                .stream()
                .map(app -> {
                    Resume resume = resumeRepository.findById(app.getResumeId())
                            .orElseThrow(() -> new RuntimeException("Resume not found"));
                    User candidate = userRepository.findById(resume.getCandidateId())
                            .orElseThrow(() -> new RuntimeException("Candidate not found"));

                    ApplicationDto dto = new ApplicationDto();
                    dto.setApplicationId(app.getId());
                    dto.setJobId(app.getJobId());
                    dto.setResumeId(app.getResumeId());
                    dto.setCandidateName(candidate.getFirstName() + " " + candidate.getLastName());
                    dto.setCandidateEmail(candidate.getEmail());
                    dto.setMatchScore(app.getMatchScore());
                    dto.setStatus(app.getStatus().name());
                    dto.setResumeFileName(resume.getFileName());
                    dto.setAppliedAt(app.getAppliedAt().toString());
                    return dto;
                })
                .toList();
    }

    @Override
    @Transactional
    public void decideApplication(Long applicationId, boolean accepted, String feedback, boolean sendMail) {
        System.out.println("--- Inside decideApplication ---");
        System.out.println("Application ID: " + applicationId);
        System.out.println("Accepted: " + accepted);
        System.out.println("Send Mail: " + sendMail);

        Application app = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new RuntimeException("Application not found"));

        app.setStatus(accepted ? Application.ApplicationStatus.ACCEPTED : Application.ApplicationStatus.REJECTED);
        applicationRepository.save(app);

        if (feedback != null && !feedback.isBlank()) {
            // ... save feedback logic
        }

        if (!accepted && sendMail) {
            System.out.println("--- Conditions met. Attempting to send rejection email. ---");
            
            Resume resume = resumeRepository.findById(app.getResumeId())
                    .orElseThrow(() -> new RuntimeException("Resume not found"));
            User candidate = userRepository.findById(resume.getCandidateId())
                    .orElseThrow(() -> new RuntimeException("Candidate not found"));

            System.out.println("Candidate Email: " + candidate.getEmail());

            try {
                emailService.sendRejectionEmail(
                        candidate.getEmail(),
                        candidate.getFirstName(),
                        List.of("Spring Security", "Docker", "Kubernetes"), // TODO gap-hints
                        feedback);
                System.out.println("--- Rejection email sent successfully. ---");
            } catch (Exception e) {
                System.err.println("--- FAILED TO SEND REJECTION EMAIL! ---");
                e.printStackTrace();
            }
        } else {
            System.out.println("--- Conditions not met. Skipping email. ---");
        }
    }

    /* ---------- helpers ---------- */
    private Map<String, Object> convertResumeToMap(Resume resume) {
        return Map.of(
                "raw_text", resume.getParsedContent() != null ? resume.getParsedContent() : "",
                "skills", resume.getExtractedSkills() != null ? List.of(resume.getExtractedSkills().split(",\\s*")) : List.of(),
                "education", resume.getExtractedEducation() != null ? List.of(resume.getExtractedEducation().split(",\\s*")) : List.of(),
                "experience", Map.of("total_years", resume.getExtractedExperience() != null ? resume.getExtractedExperience() : 0)
        );
    }

    private ResumeDto convertToDto(Resume resume) {
        ResumeDto dto = new ResumeDto();
        dto.setId(resume.getId());
        dto.setFileName(resume.getFileName());
        dto.setParsedContent(resume.getParsedContent());
        dto.setExtractedSkills(resume.getExtractedSkills());
        dto.setExtractedExperience(resume.getExtractedExperience());
        dto.setExtractedEducation(resume.getExtractedEducation());
        return dto;
    }

 // In RecruiterServiceImpl.java

    private CandidateDto convertToCandidateDto(Application application) {
        Resume resume = resumeRepository.findById(application.getResumeId())
                .orElseThrow(() -> new RuntimeException("Resume not found with ID: " + application.getResumeId()));

        // If the resume is not linked to a candidate, throw an exception to be caught by the stream
        if (resume.getCandidateId() == null) {
            throw new RuntimeException("Resume not linked to a candidate.");
        }

        User user = userRepository.findById(resume.getCandidateId())
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + resume.getCandidateId()));

        CandidateDto dto = new CandidateDto();
        dto.setApplicationId(application.getId());
        dto.setCandidateId(user.getId());
        dto.setCandidateName(user.getFirstName() + " " + user.getLastName());
        dto.setEmail(user.getEmail());
        dto.setResumeFileName(resume.getFileName());
        dto.setMatchScore(application.getMatchScore());
        dto.setStatus(application.getStatus().toString());
        dto.setAppliedAt(application.getAppliedAt());
        dto.setSkills(resume.getExtractedSkills());
        dto.setExperience(resume.getExtractedExperience());
        dto.setEducation(resume.getExtractedEducation());
        dto.setResumeId(resume.getId());

        return dto;
    }

    // --- CORRECTLY IMPLEMENTED METHOD ---
    @Override
    public RecruiterStatsDto getRecruiterStats() {
        RecruiterStatsDto.RecruiterStatsDtoBuilder statsBuilder = RecruiterStatsDto.builder();

        statsBuilder.totalCandidates(userRepository.countByRoles_Name("ROLE_CANDIDATE"));
        statsBuilder.pendingApplications(applicationRepository.countByStatus(Application.ApplicationStatus.PENDING));
        statsBuilder.activeJobs(jobRepository.count());
     // AFTER (Correct)
        statsBuilder.newResumesToday(resumeRepository.countByUploadedAtAfter(LocalDate.now().atStartOfDay()));

        statsBuilder.applicationTrend(getTrendData(applicationRepository::countByAppliedAtAfter));
        statsBuilder.registrationTrend(getTrendData(userRepository::countByCreatedAtAfter));
        statsBuilder.topSkills(getTopSkills());

        return statsBuilder.build();
    }

    private List<Map<String, Object>> getTrendData(java.util.function.Function<LocalDateTime, Long> countFunction) {
        List<Map<String, Object>> trendData = new ArrayList<>();
        for (int i = 6; i >= 0; i--) {
            // Convert LocalDate to LocalDateTime at the start of the day
            LocalDateTime dateTime = LocalDate.now().minusDays(i).atStartOfDay();
            long count = countFunction.apply(dateTime); // CORRECT: Now passing LocalDateTime
            trendData.add(Map.of(
                "date", dateTime.toLocalDate().toString(), // Keep the output as a date string for the frontend
                "count", count
            ));
        }
        return trendData;
    }

    private List<Map<String, Object>> getTopSkills() {
        return List.of(
            Map.of("Java", 100L),
            Map.of("React", 120L),
            Map.of("Python", 90L)
        );
    }

    @Override
    public List<ApplicationDto> getRecentApplications() {
        // Get the start of today as a LocalDateTime
        LocalDateTime startOfToday = LocalDateTime.now().toLocalDate().atStartOfDay();
        
        // Find all applications applied after the start of today
        List<Application> recentApps = applicationRepository.findByAppliedAtAfter(startOfToday);
        
        // Convert the list of Application entities to a list of ApplicationDto
        return recentApps.stream()
                .map(app -> {
                    // --- Check 1: Ensure the application has a resumeId ---
                    if (app.getResumeId() == null) {
                        logger.warn("Skipping application {} because it has no associated resume ID.", app.getId());
                        return null; // Return null to filter it out later
                    }

                    Resume resume = resumeRepository.findById(app.getResumeId())
                            .orElse(null); // Use orElse(null) to avoid throwing an exception

                    // --- Check 2: Ensure the resume was actually found ---
                    if (resume == null) {
                        logger.warn("Skipping application {} because its associated resume (ID: {}) was not found.", app.getId(), app.getResumeId());
                        return null;
                    }
                    
                    // --- Check 3: Ensure the resume has a candidateId (THIS IS THE LIKELY CULPRIT) ---
                    if (resume.getCandidateId() == null) {
                        logger.warn("Skipping application {} because its associated resume (ID: {}) is not linked to a candidate.", app.getId(), resume.getId());
                        return null;
                    }

                    User candidate = userRepository.findById(resume.getCandidateId())
                            .orElse(null); // Use orElse(null) here as well

                    // --- Check 4: Ensure the candidate was actually found ---
                    if (candidate == null) {
                        logger.warn("Skipping application {} because its associated candidate (ID: {}) was not found.", app.getId(), resume.getCandidateId());
                        return null;
                    }

                    // If all checks pass, create the DTO
                    ApplicationDto dto = new ApplicationDto();
                    dto.setApplicationId(app.getId());
                    dto.setJobId(app.getJobId());
                    dto.setResumeId(app.getResumeId());
                    dto.setCandidateName(candidate.getFirstName() + " " + candidate.getLastName());
                    dto.setCandidateEmail(candidate.getEmail());
                    dto.setMatchScore(app.getMatchScore());
                    dto.setStatus(app.getStatus().name());
                    dto.setResumeFileName(resume.getFileName());
                    dto.setAppliedAt(app.getAppliedAt().toString());
                    return dto;
                })
                .filter(dto -> dto != null) // Filter out any nulls from the failed checks
                .toList();
    }
}