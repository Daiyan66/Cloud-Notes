package com.example.ResumeSystemApplication.repository;


import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.ResumeSystemApplication.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
    Optional<User> findByEmail(String email);
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
    long countByRoles_Name(String roleName);
    long countByCreatedAtAfter(LocalDateTime dateTime);
 // Add this method to find users who have opted in
    List<User> findByOptInForRecommendationsTrue();
}