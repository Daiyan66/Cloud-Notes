package com.example.ResumeSystemApplication.controller;

import com.example.ResumeSystemApplication.exception.ResourceNotFoundException;
import com.example.ResumeSystemApplication.model.Resume;
import com.example.ResumeSystemApplication.repository.ResumeRepository;
import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders; // CORRECTED: Import from Spring
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@RestController
@RequestMapping("/api/files")
@RequiredArgsConstructor
public class FileUploadController {

    // This is injected from your application.properties file (e.g., file.upload-dir=uploads)
    @Value("${file.upload-dir}")
    private String uploadDir;

    // --- ADDED: Inject the repository to find resume info ---
    private final ResumeRepository resumeRepository;

    private Path fileStoragePath;
    
    public FileUploadController(ResumeRepository resumeRepository) {
        this.resumeRepository = resumeRepository;
    }


    // --- ADDED: Initialize the upload directory when the application starts ---
    @PostConstruct
    public void init() {
        this.fileStoragePath = Paths.get(uploadDir).toAbsolutePath().normalize();
        try {
            Files.createDirectories(this.fileStoragePath);
        } catch (Exception ex) {
            throw new RuntimeException("Could not create the directory where the uploaded files will be stored.", ex);
        }
    }

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {
        try {
            // Generate a unique file name to prevent collisions
            String uniqueFileName = UUID.randomUUID().toString() + "_" + file.getOriginalFilename();
            Path filePath = this.fileStoragePath.resolve(uniqueFileName);
            
            Files.copy(file.getInputStream(), filePath);
            
            // Return the unique file name so it can be saved in the database
            return ResponseEntity.ok(uniqueFileName);
        } catch (IOException e) {
            return ResponseEntity.internalServerError().body("Failed to upload file: " + e.getMessage());
        }
    }
    
    // =================================================================
    //                      *** UPDATED METHOD ***
    // =================================================================
    @GetMapping("/resumes/{resumeId}")
    public ResponseEntity<Resource> downloadResume(@PathVariable Long resumeId, HttpServletRequest request) {
        // 1. Find the resume in the database to get the file path
        Resume resume = resumeRepository.findById(resumeId)
                .orElseThrow(() -> new ResourceNotFoundException("Resume not found with id: " + resumeId));

        try {
            // 2. Get the full path from the database 
            String dbFilePath = resume.getFilePath();
            
            // 3. Extract ONLY the filename from the path
            String justTheFileName = Paths.get(dbFilePath).getFileName().toString();

            // 4. Construct the correct final path by combining the base dir with just the filename
            Path finalFilePath = this.fileStoragePath.resolve(justTheFileName).normalize();
            
            // 5. Load the file as a Resource
            Resource resource = new UrlResource(finalFilePath.toUri());
            
            if (resource.exists() && resource.isReadable()) {
                // 6. Determine the file's content type
                String contentType = null;
                try {
                    contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
                } catch (IOException ex) {
                    System.err.println("Could not determine file type.");
                }

                // Fallback to a default content type
                if (contentType == null) {
                    contentType = "application/octet-stream";
                }

                // 7. Return the file in the response
                return ResponseEntity.ok()
                        .contentType(MediaType.parseMediaType(contentType))
                        .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + resume.getFileName() + "\"")
                        .body(resource);
            } else {
                throw new ResourceNotFoundException("File not found at corrected path: " + finalFilePath);
            }
        } catch (MalformedURLException ex) {
            throw new ResourceNotFoundException("Error processing file path: " + resume.getFilePath());
        }
    }
}