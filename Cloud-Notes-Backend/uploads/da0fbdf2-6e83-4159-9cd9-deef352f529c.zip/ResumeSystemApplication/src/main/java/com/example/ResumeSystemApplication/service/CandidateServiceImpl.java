package com.example.ResumeSystemApplication.service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.fasterxml.jackson.databind.ObjectMapper; // --- NEW IMPORT ---

import com.example.ResumeSystemApplication.dto.ApplyResponse;
import com.example.ResumeSystemApplication.dto.JobDto;
import com.example.ResumeSystemApplication.dto.NlpMatchResponse;
import com.example.ResumeSystemApplication.dto.NlpParseResponse;
import com.example.ResumeSystemApplication.dto.SkillGapAnalysisDto; // --- NEW IMPORT ---
import com.example.ResumeSystemApplication.model.Application;
import com.example.ResumeSystemApplication.model.Feedback;
import com.example.ResumeSystemApplication.model.JobDescription;
import com.example.ResumeSystemApplication.model.Resume;
import com.example.ResumeSystemApplication.model.User;
import com.example.ResumeSystemApplication.repository.ApplicationRepository;
import com.example.ResumeSystemApplication.repository.FeedbackRepository;
import com.example.ResumeSystemApplication.repository.JobRepository;
import com.example.ResumeSystemApplication.repository.ResumeRepository;
import com.example.ResumeSystemApplication.repository.RoleRepository;
import com.example.ResumeSystemApplication.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CandidateServiceImpl implements CandidateService {

    private static final Logger logger = LoggerFactory.getLogger(CandidateServiceImpl.class);

    private final ResumeRepository resumeRepository;
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final ApplicationRepository applicationRepository;
    private final JobRepository jobRepository;
    private final FeedbackRepository feedbackRepository;
    private final NlpServiceClient nlpServiceClient;
    private final FileProcessingService fileProcessingService;
    private final EmailService emailService;
    private final ObjectMapper objectMapper; // --- NEW DEPENDENCY ---
    
    @Value("${app.match.threshold}")
    private int matchThreshold;
    
    // --- UPDATED CONSTRUCTOR ---
    public CandidateServiceImpl(ResumeRepository resumeRepository,
            UserRepository userRepository,
            RoleRepository roleRepository,
            ApplicationRepository applicationRepository,
            JobRepository jobRepository,
            FeedbackRepository feedbackRepository,
            NlpServiceClient nlpServiceClient,
            FileProcessingService fileProcessingService,
            EmailService emailService,
            ObjectMapper objectMapper) { // --- ADD ObjectMapper ---
        this.resumeRepository = resumeRepository;
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.applicationRepository = applicationRepository;
        this.jobRepository = jobRepository;
        this.feedbackRepository = feedbackRepository;
        this.nlpServiceClient = nlpServiceClient;
        this.fileProcessingService = fileProcessingService;
        this.emailService = emailService;
        this.objectMapper = objectMapper;
    }

    // ... (other existing methods like uploadResume, getApplicationStatus, etc. remain the same) ...
    
 // In CandidateServiceImpl.java

    @Override
    public void uploadResume(MultipartFile file, String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found: " + username));

        try {
            String filePath = fileProcessingService.saveFile(file);

            Resume resume = new Resume();
            resume.setCandidateId(user.getId());
            resume.setFileName(file.getOriginalFilename());
            resume.setFilePath(filePath);

            NlpParseResponse parsedData = nlpServiceClient.parseResume(filePath);

            resume.setParsedContent(parsedData.getRawText());
            resume.setExtractedSkills(parsedData.getSkills() != null ? String.join(", ", parsedData.getSkills()) : "");
            resume.setExtractedEducation(parsedData.getEducation() != null ? String.join(", ", parsedData.getEducation()) : "");
            
            Integer experience = 0;
            if (parsedData.getExperience() != null && parsedData.getExperience().containsKey("total_years")) {
                experience = (Integer) parsedData.getExperience().get("total_years");
            }
            resume.setExtractedExperience(experience);

            resumeRepository.save(resume);
            logger.info("Resume uploaded for user: {}", username);

            // This part creates applications for all active jobs when a resume is uploaded
            List<JobDescription> activeJobs = jobRepository.findAll();
            for (JobDescription job : activeJobs) {
                Application application = new Application();
                application.setJobId(job.getId());
                application.setResumeId(resume.getId());
                application.setStatus(Application.ApplicationStatus.PENDING);
                applicationRepository.save(application);
                logger.info("Application created for job {} and resume {}", job.getId(), resume.getId());
            }

        } catch (Exception e) {
            logger.error("Error uploading resume for user: {}", username, e);
            throw new RuntimeException("Failed to upload resume", e);
        }
    }

    @Override
    public Resume getApplicationStatus(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found: " + username));

        return resumeRepository.findFirstByCandidateId(user.getId())
                .orElseThrow(() -> new RuntimeException("No resume found for user: " + username));
    }

    @Override
    public String getFeedback(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found: " + username));

        Resume resume = resumeRepository.findFirstByCandidateId(user.getId())
                .orElseThrow(() -> new RuntimeException("No resume found for user: " + username));

        List<Application> applications = applicationRepository.findByResumeId(resume.getId());

        if (applications.isEmpty()) {
            return "No applications found for your resume.";
        }

        Application application = applications.get(0);
        Feedback feedback = feedbackRepository.findByApplicationId(application.getId())
                .stream()
                .findFirst()
                .orElse(null);

        if (feedback == null) {
            return "Your application is under review. We will notify you of the decision soon.";
        }

        return feedback.getContent();
    }
    
    @Override
    public List<JobDto> searchJobs(String title, String skills, String education, Integer expMin) {
        try {
            logger.info("Searching jobs with filters - title: {}, skills: {}, education: {}, expMin: {}", 
                       title, skills, education, expMin);
            
            List<JobDescription> jobs;
            
            if (title != null || skills != null || education != null || expMin != null) {
                jobs = jobRepository.findJobsWithFilters(title, skills, education, expMin);
            } else {
                jobs = jobRepository.findAll();
            }
            
            logger.info("Found {} jobs matching the criteria", jobs.size());
            
            return jobs.stream()
                .map(this::convertJobToDto)
                .toList();
        } catch (Exception e) {
            logger.error("Error searching jobs: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to search jobs", e);
        }
    }

    // --- UPDATED apply METHOD ---
    @Override
    public ApplyResponse apply(MultipartFile resume, Long jobId, String username) {
        try {
            JobDescription job = jobRepository.findById(jobId)
                    .orElseThrow(() -> new RuntimeException("Job not found"));

            String filePath;
            NlpParseResponse parsedData;
            try {
                filePath = fileProcessingService.saveFile(resume);
                parsedData = nlpServiceClient.parseResume(filePath);
            } catch (Exception e) {
                logger.error("Resume processing failed", e);
                throw new RuntimeException("Resume processing failed", e);
            }

            User user = userRepository.findByUsername(username)
                    .orElseThrow(() -> new RuntimeException("User not found"));

            // --- FIXED: Renamed to resumeEntity ---
            Resume resumeEntity = new Resume();
            resumeEntity.setCandidateId(user.getId());
            resumeEntity.setFileName(resume.getOriginalFilename());
            resumeEntity.setFilePath(filePath);
            resumeEntity.setParsedContent(parsedData.getRawText());
            resumeEntity.setExtractedSkills(parsedData.getSkills() != null ? String.join(", ", parsedData.getSkills()) : "");
            resumeEntity.setExtractedEducation(parsedData.getEducation() != null ? String.join(", ", parsedData.getEducation()) : "");

            Integer experience = 0;
            if (parsedData.getExperience() != null && parsedData.getExperience().containsKey("total_years")) {
                experience = (Integer) parsedData.getExperience().get("total_years");
            }
            resumeEntity.setExtractedExperience(experience);
            resumeEntity = resumeRepository.save(resumeEntity); // --- UPDATED ---

            double rawScore = 0.0;
            String skillGapJson = null;
            try {
                Map<String, Object> resumeData = new HashMap<>();
                resumeData.put("raw_text", resumeEntity.getParsedContent() != null ? resumeEntity.getParsedContent() : ""); // --- UPDATED ---
                resumeData.put("skills", parsedData.getSkills() != null ? parsedData.getSkills() : Collections.emptyList());
                resumeData.put("education", parsedData.getEducation() != null ? parsedData.getEducation() : Collections.emptyList());

                Map<String, Object> experienceMap = new HashMap<>();
                if (parsedData.getExperience() != null) {
                    experienceMap.put("total_years", parsedData.getExperience().get("total_years"));
                } else {
                    experienceMap.put("total_years", 0);
                }
                resumeData.put("experience", experienceMap);

                NlpMatchResponse matchResult = nlpServiceClient.matchSingleResume(job.getDescription(), resumeData);
                if (matchResult != null && matchResult.getOverallScore() != null) {
                    rawScore = matchResult.getOverallScore();
                } else {
                    logger.warn("Received null match result or score, using default score");
                    rawScore = 50.0;
                }

                if (matchResult != null && matchResult.getMatchedSkills() != null && matchResult.getMissingSkills() != null) {
                    try {
                        Map<String, Object> skillGapData = Map.of(
                            "matchedSkills", matchResult.getMatchedSkills(),
                            "missingSkills", matchResult.getMissingSkills()
                        );
                        skillGapJson = objectMapper.writeValueAsString(skillGapData);
                    } catch (Exception e) {
                        logger.error("Error creating skill gap JSON for application", e);
                        skillGapJson = null;
                    }
                }

            } catch (Exception e) {
                logger.error("Error matching resume: {}", e.getMessage(), e);
                rawScore = 50.0;
            }

            double scorePercentage = rawScore > 1.0 ? rawScore : rawScore * 100.0;

            Application.ApplicationStatus finalStatus;
            if (scorePercentage >= matchThreshold) {
                finalStatus = Application.ApplicationStatus.PENDING;
                logger.info("Score {}% is above threshold {}. Application {} remains PENDING.", scorePercentage, matchThreshold, resumeEntity.getId()); // --- UPDATED ---
            } else {
                finalStatus = Application.ApplicationStatus.REJECTED;
                logger.warn("Score {}% is below threshold {}. Auto-rejecting application {}", scorePercentage, matchThreshold, resumeEntity.getId()); // --- UPDATED ---

                try {
                    String feedback = String.format(
                            "Unfortunately, your application for the position of %s was not successful. " +
                                    "Our system indicates your profile is a %d%% match, which is below our current threshold of %d%%.",
                            job.getTitle(), (int) Math.round(scorePercentage), matchThreshold
                    );
                    emailService.sendRejectionEmail(
                            user.getEmail(),
                            user.getFirstName(),
                            Collections.singletonList("Skill Gap Analysis"),
                            feedback
                    );
                    logger.info("Sent automatic rejection email to {}", user.getEmail());
                } catch (Exception e) {
                    logger.error("Error sending automatic rejection email to {}: {}", user.getEmail(), e.getMessage());
                }
            }

            Application app = new Application();
            app.setJobId(jobId);
            app.setResumeId(resumeEntity.getId()); // --- UPDATED ---
            app.setStatus(finalStatus);
            app.setMatchScore(scorePercentage);
            app.setSkillGapAnalysis(skillGapJson);
            applicationRepository.save(app);

            logger.info("Applied: user={}, job={}, score={}%, status={}", username, jobId, (int) Math.round(scorePercentage), finalStatus);
            return new ApplyResponse("Application submitted successfully", (int) Math.round(scorePercentage), finalStatus.name());

        } catch (Exception e) {
            logger.error("Error applying for job: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to apply for job", e);
        }
    }
    // --- NEW METHOD ---
    @Override
    public SkillGapAnalysisDto getSkillGapAnalysis(Long applicationId) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new RuntimeException("Application not found"));

        // Get the current user to ensure they own this application
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        Resume resume = resumeRepository.findById(application.getResumeId())
                .orElseThrow(() -> new RuntimeException("Resume not found"));

        if (!resume.getCandidateId().equals(user.getId())) {
            throw new RuntimeException("You are not authorized to view this analysis.");
        }

        String skillGapJson = application.getSkillGapAnalysis();
        if (skillGapJson == null || skillGapJson.isEmpty()) {
            return new SkillGapAnalysisDto(); // Return empty DTO if no data exists
        }

        SkillGapAnalysisDto dto = new SkillGapAnalysisDto();
        dto.setJobTitle(jobRepository.findById(application.getJobId()).map(JobDescription::getTitle).orElse("Unknown Job"));
        dto.setRawSkillGapJson(skillGapJson); // Pass raw JSON to frontend for parsing
        return dto;
    }

    private JobDto convertJobToDto(JobDescription j) {
        try {
            JobDto dto = new JobDto();
            dto.setId(j.getId());
            dto.setTitle(j.getTitle());
            dto.setDescription(j.getDescription());
            dto.setSkillsRequired(j.getSkillsRequired());
            dto.setEducationLevel(j.getEducationLevel());
            dto.setExperienceRequired(j.getExperienceRequired());
            return dto;
        } catch (Exception e) {
            logger.error("Error converting job to DTO: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to convert job to DTO", e);
        }
    }
}