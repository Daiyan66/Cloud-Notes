// src/main/java/com/example/ResumeSystemApplication/service/ProgressService.java

package com.example.ResumeSystemApplication.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class ProgressService {

    private static final Logger logger = LoggerFactory.getLogger(ProgressService.class);

    // This map holds the active SSE connections for each job.
    private final Map<Long, SseEmitter> emitters = new ConcurrentHashMap<>();

    /**
     * Creates a new SseEmitter for a given job and stores it.
     * @param jobId The ID of the job to track.
     * @return The created SseEmitter.
     */
    public SseEmitter createEmitter(Long jobId) {
        SseEmitter emitter = new SseEmitter(60_000L); // 60-second timeout
        emitters.put(jobId, emitter);

        // These callbacks ensure the emitter is cleaned up from the map
        // when the connection is closed, times out, or encounters an error.
        emitter.onCompletion(() -> {
            logger.info("Emitter completed for jobId: {}", jobId);
            emitters.remove(jobId);
        });
        emitter.onTimeout(() -> {
            logger.info("Emitter timed out for jobId: {}", jobId);
            emitters.remove(jobId);
        });
        emitter.onError(e -> {
            logger.error("Emitter error for jobId: {}", jobId, e);
            emitters.remove(jobId);
        });

        return emitter;
    }

    /**
     * Sends a progress message to the client for a specific job.
     * @param jobId The ID of the job.
     * @param message The progress message (e.g., "2/5").
     */
    public void sendProgress(Long jobId, String message) {
        SseEmitter emitter = emitters.get(jobId);
        if (emitter != null) {
            try {
                emitter.send(message);
            } catch (IOException e) {
                logger.error("Failed to send progress for jobId: {}", jobId, e);
                // If sending fails, remove the emitter to prevent further issues.
                emitters.remove(jobId);
            }
        }
    }

    /**
     * Sends a 'complete' event and gracefully closes the SSE connection after a short delay.
     * The delay prevents a race condition where the browser reconnects before the frontend
     * has processed the completion event.
     * @param jobId The ID of the job to complete.
     */
    public void sendCompletionEvent(Long jobId) {
        SseEmitter emitter = emitters.get(jobId);
        if (emitter != null) {
            try {
                // Step 1: Send the 'complete' event. This is the critical part.
                emitter.send(SseEmitter.event().name("complete").data("Processing complete."));
                logger.info("Sent completion event for jobId: {}", jobId);

                // Step 2: Start a new thread to handle the delayed completion.
                // This prevents the browser from reconnecting before the frontend can process the event.
                new Thread(() -> {
                    try {
                        Thread.sleep(500); // Wait for 500ms to allow frontend to process
                        emitter.complete();
                        logger.info("Successfully closed emitter for jobId: {} after delay.", jobId);
                    } catch (InterruptedException e) {
                        logger.error("Thread sleep interrupted for jobId: {}", jobId, e);
                        Thread.currentThread().interrupt(); // Good practice to restore the interrupted status
                        emitter.completeWithError(e);
                    }
                    // Note: We don't need to catch IOException here. If emitter.complete() fails,
                    // the emitter's onError callback (defined in createEmitter) will handle cleanup.
                }).start();

            } catch (IOException e) {
                // This catch block handles the case where the initial 'emitter.send(...)' call fails.
                logger.error("Failed to send completion event for jobId: {}", jobId, e);
                emitter.completeWithError(e);
                // If sending the event failed, we must remove the emitter immediately.
                emitters.remove(jobId);
            }
        }
    }
}