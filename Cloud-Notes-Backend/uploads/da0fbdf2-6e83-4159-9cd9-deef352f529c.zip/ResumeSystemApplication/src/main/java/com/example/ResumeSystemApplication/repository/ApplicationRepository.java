package com.example.ResumeSystemApplication.repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.ResumeSystemApplication.dto.AnalyzedResumeDto;
import com.example.ResumeSystemApplication.model.Application;
import com.example.ResumeSystemApplication.model.Application.ApplicationStatus;

@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long>, JpaSpecificationExecutor<Application> {
//    List<Application> findByJobId(Long jobId);
	
	List<Application> findByJobIdOrderByAppliedAtDesc(Long jobId);
    List<Application> findByResumeId(Long resumeId);
    
    @Query("SELECT a FROM Application a WHERE a.jobId = :jobId ORDER BY a.matchScore DESC")
    List<Application> findByJobIdOrderByScoreDesc(@Param("jobId") Long jobId);
    
    @Query("SELECT a FROM Application a WHERE a.jobId = :jobId AND a.resumeId = :resumeId")
    Optional<Application> findByJobIdAndResumeId(@Param("jobId") Long jobId, @Param("resumeId") Long resumeId);
    
    @Query("SELECT a FROM Application a WHERE a.jobId = :jobId ORDER BY a.matchScore DESC")
    List<Application> findByJobIdOrderByMatchScoreDesc(@Param("jobId") Long jobId);

 // Add these methods to your ApplicationRepository.java
 // CORRECT SIGNATURE
    long countByStatus(Application.ApplicationStatus status);
    long countByAppliedAtAfter(LocalDateTime dateTime);
    List<Application> findByAppliedAtAfter(LocalDateTime dateTime);
    
 // Add this method inside the ApplicationRepository interface

    @Query("SELECT new com.example.ResumeSystemApplication.dto.AnalyzedResumeDto(" +
    	       "a.id, r.fileName, a.matchScore, a.appliedAt, " +
    	       "CONCAT(u.firstName, ' ', u.lastName), j.title) " +
    	       "FROM Application a " +
    	       "JOIN Resume r ON r.id = a.resumeId " +
    	       "JOIN JobDescription j ON j.id = a.jobId " +
    	       "JOIN User u ON u.id = j.createdBy " +
    	       "WHERE r.candidateId IS NULL " +
    	       "ORDER BY a.appliedAt DESC")
    	List<AnalyzedResumeDto> findAllAnalyzedResumes();
    

    @Query("SELECT a FROM Application a WHERE a.resumeId = :resumeId ORDER BY a.appliedAt DESC")
    Application findFirstByResumeIdOrderByAppliedAtDesc(@Param("resumeId") Long resumeId);
    
 // Add this method to your ApplicationRepository interface
    @Query("SELECT DISTINCT a.jobId FROM Application a WHERE a.resumeId IN (SELECT r.id FROM Resume r WHERE r.candidateId = :candidateId)")
    List<Long> findJobIdsByCandidateId(@Param("candidateId") Long candidateId);
    
 // In ApplicationRepository.java

    @Query("SELECT a FROM Application a JOIN Resume r ON a.resumeId = r.id WHERE r.candidateId = :candidateId ORDER BY a.appliedAt DESC")
    List<Application> findAllByCandidateIdOrderByAppliedAtDesc(@Param("candidateId") Long candidateId);
    
}