package com.example.ResumeSystemApplication.service;

import java.util.List;

public interface EmailService {
    void sendEmail(String to, String subject, String body);
    void sendRecruiterNotification(String recruiterEmail, String message);
    void sendCandidateNotification(String candidateEmail, boolean accepted, String feedback);
    void sendRejectionEmail(String to, String name, List<String> gaps, String feedback);
}