package com.example.ResumeSystemApplication.controller;

import com.example.ResumeSystemApplication.dto.ApplicationDto;
import com.example.ResumeSystemApplication.dto.ApplyResponse;
import com.example.ResumeSystemApplication.dto.JobDto;
import com.example.ResumeSystemApplication.dto.NlpMatchResponse;
import com.example.ResumeSystemApplication.dto.SkillGapAnalysisDto;
import com.example.ResumeSystemApplication.model.Application;
import com.example.ResumeSystemApplication.model.JobDescription;
import com.example.ResumeSystemApplication.model.Resume;
import com.example.ResumeSystemApplication.model.User;
import com.example.ResumeSystemApplication.repository.ApplicationRepository;
import com.example.ResumeSystemApplication.repository.JobRepository;
import com.example.ResumeSystemApplication.repository.ResumeRepository;
import com.example.ResumeSystemApplication.repository.UserRepository;
import com.example.ResumeSystemApplication.service.CandidateService;
import com.example.ResumeSystemApplication.service.NlpServiceClient;

import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/candidate")
@PreAuthorize("hasRole('CANDIDATE')")
@RequiredArgsConstructor
public class CandidateController {

    private static final Logger logger = LoggerFactory.getLogger(CandidateController.class);

    private final CandidateService candidateService;
    private final UserRepository userRepository;
    private final ApplicationRepository applicationRepository;
    private final JobRepository jobRepository;
    private final ResumeRepository resumeRepository;
    private final NlpServiceClient nlpServiceClient;

    // NOTE: The @RequiredArgsConstructor annotation already creates this constructor for you.
    // You can safely remove the manual constructor below to keep the code cleaner.
    public CandidateController(CandidateService candidateService,
            UserRepository userRepository,
            ApplicationRepository applicationRepository,
            JobRepository jobRepository,
            ResumeRepository resumeRepository,
            NlpServiceClient nlpServiceClient) {
        this.candidateService = candidateService;
        this.userRepository = userRepository;
        this.applicationRepository = applicationRepository;
        this.jobRepository = jobRepository;
        this.resumeRepository = resumeRepository;
        this.nlpServiceClient = nlpServiceClient;
    }


    // --- EXISTING METHODS ---
    @PostMapping("/resume")
    public ResponseEntity<String> uploadResume(
            @RequestParam("file") MultipartFile file,
            @AuthenticationPrincipal UserDetails userDetails) {
        logger.info("Uploading resume for user: {}", userDetails.getUsername());
        try {
            candidateService.uploadResume(file, userDetails.getUsername());
            return ResponseEntity.ok("Resume uploaded successfully");
        } catch (Exception e) {
            logger.error("Error uploading resume: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error uploading resume: " + e.getMessage());
        }
    }

    @GetMapping("/status")
    public ResponseEntity<?> getApplicationStatus(@AuthenticationPrincipal UserDetails userDetails) {
        logger.info("Fetching application status for user: {}", userDetails.getUsername());
        try {
            return ResponseEntity.ok(candidateService.getApplicationStatus(userDetails.getUsername()));
        } catch (Exception e) {
            logger.error("Error fetching application status: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error fetching application status: " + e.getMessage());
        }
    }

    @GetMapping("/feedback")
    public ResponseEntity<String> getFeedback(@AuthenticationPrincipal UserDetails userDetails) {
        logger.info("Fetching feedback for user: {}", userDetails.getUsername());
        try {
            return ResponseEntity.ok(candidateService.getFeedback(userDetails.getUsername()));
        } catch (Exception e) {
            logger.error("Error fetching feedback: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error fetching feedback: " + e.getMessage());
        }
    }

    @GetMapping("/jobs")
    public ResponseEntity<?> getJobs(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String skills,
            @RequestParam(required = false) String education,
            @RequestParam(required = false) Integer expMin) {
        logger.info("Fetching jobs with filters - title: {}, skills: {}, education: {}, expMin: {}", 
                   title, skills, education, expMin);
        try {
            List<JobDto> jobs = candidateService.searchJobs(title, skills, education, expMin);
            logger.info("Found {} jobs", jobs.size());
            return ResponseEntity.ok(jobs);
        } catch (Exception e) {
            logger.error("Error fetching jobs: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error fetching jobs: " + e.getMessage());
        }
    }
    
    @PostMapping(value = "/apply", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ApplyResponse> apply(
            @RequestParam("resume") MultipartFile resume,
            @RequestParam("jobId") Long jobId,
            @AuthenticationPrincipal UserDetails userDetails) {
        logger.info("Applying for job {} by user {}", jobId, userDetails.getUsername());
        try {
            ApplyResponse resp = candidateService.apply(resume, jobId, userDetails.getUsername());
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            logger.error("Error applying for job: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApplyResponse(false, "Error applying for job: " + e.getMessage()));
        }
    }

    // --- SKILL ANALYSIS METHODS ---
    @GetMapping("/analysis/{applicationId}")
    public ResponseEntity<SkillGapAnalysisDto> getSkillGapAnalysis(@PathVariable Long applicationId) {
        try {
            SkillGapAnalysisDto analysis = candidateService.getSkillGapAnalysis(applicationId);
            return ResponseEntity.ok(analysis);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        } catch (Exception e) {
            logger.error("Error fetching skill gap analysis for application ID: {}", applicationId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/analysis/latest")
    public ResponseEntity<Map<String, Long>> getLatestApplicationIdForAnalysis() {
        try {
            String username = SecurityContextHolder.getContext().getAuthentication().getName();
            User user = userRepository.findByUsername(username)
                    .orElseThrow(() -> new RuntimeException("User not found"));
            
            List<Application> userApplications = applicationRepository.findAllByCandidateIdOrderByAppliedAtDesc(user.getId());
            if (userApplications == null || userApplications.isEmpty()) {
                return ResponseEntity.ok(Map.of("applicationId", (Long) null));
            }
            return ResponseEntity.ok(Map.of("applicationId", userApplications.get(0).getId()));
        } catch (Exception e) {
            logger.error("Error finding latest application for analysis", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/applications")
    public ResponseEntity<List<ApplicationDto>> getMyApplications() {
        try {
            String username = SecurityContextHolder.getContext().getAuthentication().getName();
            User user = userRepository.findByUsername(username)
                    .orElseThrow(() -> new RuntimeException("User not found"));

            List<Application> userApplications = applicationRepository.findAllByCandidateIdOrderByAppliedAtDesc(user.getId());

            List<ApplicationDto> applicationDtos = userApplications.stream()
                    .map(app -> {
                        JobDescription job = jobRepository.findById(app.getJobId()).orElse(null);
                        ApplicationDto dto = new ApplicationDto();
                        dto.setApplicationId(app.getId());
                        dto.setJobTitle(job != null ? job.getTitle() : "Unknown Job");
                        dto.setMatchScore(app.getMatchScore());
                        dto.setStatus(app.getStatus().name());
                        dto.setAppliedAt(app.getAppliedAt().toString());
                        return dto;
                    })
                    .toList();

            return ResponseEntity.ok(applicationDtos);

        } catch (Exception e) {
            logger.error("Error fetching applications for candidate", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // --- NEW RECOMMENDATIONS LOGIC (CORRECTED) ---
    @GetMapping("/recommendations")
    public ResponseEntity<List<JobDto>> getMyRecommendations() {
        try {
            String username = SecurityContextHolder.getContext().getAuthentication().getName();
            User user = userRepository.findByUsername(username)
                    .orElseThrow(() -> new RuntimeException("User not found"));

            List<Resume> resumes = resumeRepository.findAllByCandidateIdOrderByUploadedAtDesc(user.getId());
            Resume resume = (resumes != null && !resumes.isEmpty()) ? resumes.get(0) : null;

            if (resume == null) {
                return ResponseEntity.ok(List.of());
            }

            // --- NEW LOGIC: Recommend any recent, unapplied job ---
            List<JobDescription> allRecentJobs = jobRepository.findTop20ByOrderByCreatedAtDesc();
            List<Long> appliedJobIds = applicationRepository.findJobIdsByCandidateId(user.getId());

            // --- FIX IS HERE ---
            // Changed the declared type from List<JobDescription> to List<JobDto>
            List<JobDto> recommendedJobs = allRecentJobs.stream()
                    .filter(job -> !appliedJobIds.contains(job.getId())) // Filter out already applied jobs
                    .limit(3) // Get up to 3 recommendations
                    .map(this::convertToDtoLocally) // Convert to DTO
                    .collect(Collectors.toList());

            if (recommendedJobs.isEmpty()) {
                logger.info("No new recommendations found for candidate {}.", user.getId());
                return ResponseEntity.ok(List.of());
            }

            return ResponseEntity.ok(recommendedJobs);

        } catch (Exception e) {
            logger.error("Error fetching job recommendations for candidate", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // --- ADD THIS HELPER METHOD TO THE CONTROLLER CLASS ---
    private JobDto convertToDtoLocally(JobDescription job) {
        JobDto dto = new JobDto();
        dto.setId(job.getId());
        dto.setTitle(job.getTitle());
        dto.setDescription(job.getDescription());
        dto.setSkillsRequired(job.getSkillsRequired());
        dto.setEducationLevel(job.getEducationLevel());
        dto.setExperienceRequired(job.getExperienceRequired());
        return dto;
    }
}