package com.example.ResumeSystemApplication.controller;

import com.example.ResumeSystemApplication.service.NlpServiceClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/chatbot")
public class ChatbotController {

    private static final Logger logger = LoggerFactory.getLogger(ChatbotController.class);

    private final NlpServiceClient nlpServiceClient;

    // Manual constructor for dependency injection
    public ChatbotController(NlpServiceClient nlpServiceClient) {
        this.nlpServiceClient = nlpServiceClient;
    }

    @PostMapping("/ask")
    @PreAuthorize("hasAnyRole('ADMIN', 'RECRUITER')")
    public ResponseEntity<Map<String, String>> askQuestion(@RequestBody Map<String, String> request) {
        String query = request.get("query");
        String response = nlpServiceClient.getChatbotResponse(query);
        
        return ResponseEntity.ok(Map.of("response", response));
    }
}
