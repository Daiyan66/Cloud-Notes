from typing import List, Dict, Any
import numpy as np
from sentence_transformers import SentenceTransformer
import logging
import json

logger = logging.getLogger(__name__)

class ResumeMatcher:
    def __init__(self):
        # Load pre-trained sentence transformer model
        try:
            self.model = SentenceTransformer('all-MiniLM-L6-v2')
            logger.info("Sentence transformer model loaded successfully")
        except Exception as e:
            logger.error(f"Error loading sentence transformer model: {str(e)}")
            # Continue without the model - will use fallback logic
            self.model = None

    # --- All methods below this point must be indented to be inside the class ---

    def _get_detailed_skill_match(self, job_description: str, resume_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculate detailed skill match, including lists of matched and missing skills.
        """
        job_skills = set()
        resume_skills = set()
        
        # Extract skills from job description
        common_skills = [
            'python', 'java', 'javascript', 'c++', 'c#', 'php', 'ruby', 'swift',
            'html', 'css', 'react', 'angular', 'vue', 'node.js', 'django', 'flask',
            'spring', 'hibernate', 'sql', 'mysql', 'postgresql', 'mongodb',
            'aws', 'azure', 'gcp', 'docker', 'kubernetes', 'jenkins'
        ]
        
        for skill in common_skills:
            if skill in job_description.lower():
                job_skills.add(skill)
        
        # Handle different formats of resume skills
        if 'skills' in resume_data and resume_data['skills']:
            if isinstance(resume_data['skills'], list):
                resume_skills = set([skill.lower() for skill in resume_data['skills']])
            else:
                resume_skills = set([skill.lower() for skill in str(resume_data['skills']).split(',')])
        
        if not job_skills:
            # If no skills are found in the job, return empty lists and a neutral score
            return {
                'matched_skills': [],
                'missing_skills': [],
                'match_percentage': 0.5
            }
        
        # Calculate the intersection and difference
        matched = job_skills.intersection(resume_skills)
        missing = job_skills.difference(resume_skills)
        
        # Calculate match percentage
        match_percentage = len(matched) / len(job_skills)
        
        return {
            'matched_skills': list(matched),
            'missing_skills': list(missing),
            'match_percentage': match_percentage
        }

    def match(self, job_description: str, resumes_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Match resumes against job description and return match scores.
        
        Args:
            job_description: Text of the job description
            resumes_data: List of parsed resume data
            
        Returns:
            List of dictionaries with resume ID and match score
        """
        # --- START OF ADDED LOGGING ---
        logger.info(f"Received job_description: {job_description}")
        logger.info(f"Received resumes_data: {json.dumps(resumes_data)}")
        # --- END OF ADDED LOGGING ---

        # Handle the edge case where there are no resumes to match
        if not resumes_data:
            logger.info("No resumes provided for matching. Returning empty list.")
            return []

        try:
            # Prepare texts for comparison
            job_text = self._prepare_job_text(job_description)
            resume_texts = [self._prepare_resume_text(resume) for resume in resumes_data]

            # --- START OF ADDED LOGGING ---
            logger.info(f"Prepared job_text: {job_text}")
            logger.info(f"Prepared resume_texts: {resume_texts}")
            # --- END OF ADDED LOGGING ---
            
            # Generate embeddings if model is available
            if self.model is not None:
                try:
                    job_embedding = self.model.encode([job_text], convert_to_tensor=True)
                    resume_embeddings = self.model.encode(resume_texts, convert_to_tensor=True)
                    similarities = self._calculate_cosine_similarity(job_embedding, resume_embeddings)
                except Exception as e:
                    logger.error(f"Error generating embeddings: {str(e)}")
                    # Use fallback similarity calculation
                    similarities = np.array([self._fallback_similarity(job_text, text) for text in resume_texts])
            else:
                # Use fallback similarity calculation
                similarities = np.array([self._fallback_similarity(job_text, text) for text in resume_texts])
            
            # Ensure similarities is a 1D array
            if similarities.ndim > 1:
                similarities = similarities.flatten()
            
            # Prepare results
            results = []
            for i, (resume, similarity) in enumerate(zip(resumes_data, similarities)):
                # --- NEW: Get detailed skill analysis ---
                skill_analysis = self._get_detailed_skill_match(job_description, resume)
                
                # Calculate skill match percentage (now from our new method)
                skill_match = skill_analysis['match_percentage']
                
                # Calculate experience match
                experience_match = self._calculate_experience_match(job_description, resume)
                
                # Calculate overall score (weighted average)
                overall_score = (
                    0.5 * similarity +  # Semantic similarity
                    0.3 * skill_match +  # Skill match
                    0.2 * experience_match  # Experience match
                )
                
                # --- UPDATED: Add the new skill lists to the result ---
                results.append({
                    'resume_id': i,
                    'semantic_similarity': float(similarity),
                    'skill_match': float(skill_match),
                    'experience_match': float(experience_match),
                    'overall_score': float(overall_score),
                    'matched_skills': skill_analysis['matched_skills'],
                    'missing_skills': skill_analysis['missing_skills']
                })
            
            # Sort by overall score
            results.sort(key=lambda x: x['overall_score'], reverse=True)
            
            return results
        except Exception as e:
            logger.error(f"Error matching resumes: {str(e)}")
            # Return default results to avoid breaking the application
            return [{
                'resume_id': i,
                'semantic_similarity': 0.5,
                'skill_match': 0.5,
                'experience_match': 0.5,
                'overall_score': 0.5,
                'matched_skills': [], # --- NEW: Default empty lists
                'missing_skills': []  # --- NEW: Default empty lists
            } for i in range(len(resumes_data))]

    def _prepare_job_text(self, job_description: str) -> str:
        """Prepare job description text for embedding."""
        # Extract key sections from job description
        lines = job_description.split('\n')
        relevant_lines = []
        
        for line in lines:
            line = line.strip().lower()
            # Include lines with keywords
            if any(keyword in line for keyword in ['requirement', 'skill', 'experience', 'qualification']):
                relevant_lines.append(line)
        
        return ' '.join(relevant_lines) if relevant_lines else job_description

    def _prepare_resume_text(self, resume_data: Dict[str, Any]) -> str:
        """Prepare resume text for embedding."""
        # Combine relevant sections from resume
        text_parts = []
        
        if 'skills' in resume_data and resume_data['skills']:
            if isinstance(resume_data['skills'], list):
                text_parts.append(' '.join(resume_data['skills']))
            else:
                text_parts.append(str(resume_data['skills']))
        
        if 'experience' in resume_data and isinstance(resume_data['experience'], dict):
            exp = resume_data['experience']
            if 'total_years' in exp:
                text_parts.append(f"{exp['total_years']} years experience")
        
        if 'education' in resume_data and resume_data['education']:
            if isinstance(resume_data['education'], list):
                text_parts.append(' '.join(resume_data['education']))
            else:
                text_parts.append(str(resume_data['education']))
        
        return ' '.join(text_parts)

    def _calculate_cosine_similarity(self, job_embedding, resume_embeddings):
        """Calculate cosine similarity between job and resume embeddings."""
        try:
            # Check dimensions and reshape if necessary
            if job_embedding.ndim == 1:
                job_embedding = job_embedding.unsqueeze(0)
            
            if resume_embeddings.ndim == 1:
                resume_embeddings = resume_embeddings.unsqueeze(0)
            
            # Normalize embeddings
            job_norm = job_embedding / job_embedding.norm(dim=1, keepdim=True)
            resume_norm = resume_embeddings / resume_embeddings.norm(dim=1, keepdim=True)
            
            # Calculate cosine similarity
            similarities = (job_norm @ resume_norm.T).squeeze()
            
            # Ensure we return a 1D array
            if similarities.ndim > 1:
                similarities = similarities.flatten()
            elif similarities.ndim == 0:
                similarities = similarities.unsqueeze(0)
            
            return similarities.cpu().numpy()
        except Exception as e:
            logger.error(f"Error calculating cosine similarity: {str(e)}")
            # Return default similarity
            return np.array([0.5] * len(resume_embeddings))

    def _fallback_similarity(self, job_text: str, resume_text: str) -> float:
        """Fallback similarity calculation using keyword overlap."""
        job_words = set(job_text.lower().split())
        resume_words = set(resume_text.lower().split())
        
        if not job_words:
            return 0.5
        
        intersection = job_words.intersection(resume_words)
        return len(intersection) / len(job_words)

    def _calculate_skill_match(self, job_description: str, resume_data: Dict[str, Any]) -> float:
        """Calculate skill match percentage."""
        job_skills = set()
        resume_skills = set()
        
        # Extract skills from job description
        common_skills = [
            'python', 'java', 'javascript', 'c++', 'c#', 'php', 'ruby', 'swift',
            'html', 'css', 'react', 'angular', 'vue', 'node.js', 'django', 'flask',
            'spring', 'hibernate', 'sql', 'mysql', 'postgresql', 'mongodb',
            'aws', 'azure', 'gcp', 'docker', 'kubernetes', 'jenkins'
        ]
        
        for skill in common_skills:
            if skill in job_description.lower():
                job_skills.add(skill)
        
        # Handle different formats of resume skills
        if 'skills' in resume_data and resume_data['skills']:
            if isinstance(resume_data['skills'], list):
                resume_skills = set([skill.lower() for skill in resume_data['skills']])
            else:
                resume_skills = set([skill.lower() for skill in str(resume_data['skills']).split(',')])
        
        if not job_skills:
            return 0.5  # Default if no skills found in job description
        
        # Calculate match percentage
        intersection = job_skills.intersection(resume_skills)
        match_percentage = len(intersection) / len(job_skills)
        
        return match_percentage

    def _calculate_experience_match(self, job_description: str, resume_data: Dict[str, Any]) -> float:
        """Calculate experience match percentage."""
        resume_exp = resume_data.get('experience', {})
        resume_years = 0
        
        # Handle different formats of experience
        if 'total_years' in resume_exp:
            try:
                resume_years = int(resume_exp['total_years'])
            except (ValueError, TypeError):
                resume_years = 0
        
        # Extract required experience from job description
        import re
        exp_pattern = r'(\d+)\s*(years?|yrs?)\s*(of\s*)?experience'
        exp_match = re.search(exp_pattern, job_description, re.IGNORECASE)
        
        if not exp_match:
            return 1.0  # No experience requirement mentioned
        
        required_years = int(exp_match.group(1))
        
        # Calculate match (capped at 1.0)
        if resume_years >= required_years:
            return 1.0
        else:
            return resume_years / required_years