import PyPDF2
import docx
import re
import spacy
from typing import Dict, List, Any
import logging

logger = logging.getLogger(__name__)

class ResumeParser:
    def __init__(self):
        # Load spaCy model for NLP processing
        try:
            self.nlp = spacy.load("en_core_web_sm")
            logger.info("spaCy model loaded successfully")
        except OSError:
            logger.warning("spaCy model not found. Using basic text processing.")
            self.nlp = None
        
        # Common skills keywords
        self.skills_keywords = [
            'python', 'java', 'javascript', 'c++', 'c#', 'php', 'ruby', 'swift',
            'html', 'css', 'react', 'angular', 'vue', 'node.js', 'django', 'flask',
            'spring', 'hibernate', 'sql', 'mysql', 'postgresql', 'mongodb',
            'aws', 'azure', 'gcp', 'docker', 'kubernetes', 'jenkins',
            'git', 'agile', 'scrum', 'machine learning', 'data science',
            'tensorflow', 'pytorch', 'pandas', 'numpy', 'tableau'
        ]
        
        # Education keywords
        self.education_keywords = [
            'bachelor', 'master', 'phd', 'doctorate', 'degree',
            'diploma', 'certification', 'university', 'college'
        ]

    def parse(self, file_path: str) -> Dict[str, Any]:
        """Parse resume file and extract structured information."""
        try:
            # Extract text from file
            text = self._extract_text(file_path)
            
            # Extract information
            parsed_data = {
                'raw_text': text,
                'skills': self._extract_skills(text),
                'education': self._extract_education(text),
                'experience': self._extract_experience(text)
            }
            
            return parsed_data
        except Exception as e:
            logger.error(f"Error parsing resume: {str(e)}")
            # Return a default response to avoid breaking the application
            return {
                'raw_text': "Error parsing resume",
                'skills': ["Error"],
                'education': ["Error"],
                'experience': {"total_years": 0}
            }

    def _extract_text(self, file_path: str) -> str:
        """Extract text from PDF or DOCX file."""
        if file_path.endswith('.pdf'):
            return self._extract_pdf_text(file_path)
        elif file_path.endswith('.docx'):
            return self._extract_docx_text(file_path)
        else:
            raise ValueError("Unsupported file format")

    def _extract_pdf_text(self, file_path: str) -> str:
        """Extract text from PDF file."""
        text = ""
        try:
            with open(file_path, 'rb') as file:
                reader = PyPDF2.PdfReader(file)
                for page in reader.pages:
                    text += page.extract_text()
        except Exception as e:
            logger.error(f"Error extracting PDF text: {str(e)}")
            return "Error extracting PDF text"
        return text

    def _extract_docx_text(self, file_path: str) -> str:
        """Extract text from DOCX file."""
        try:
            doc = docx.Document(file_path)
            return "\n".join([paragraph.text for paragraph in doc.paragraphs])
        except Exception as e:
            logger.error(f"Error extracting DOCX text: {str(e)}")
            return "Error extracting DOCX text"

    def _extract_skills(self, text: str) -> List[str]:
        """Extract skills from resume text."""
        text_lower = text.lower()
        found_skills = []
        
        for skill in self.skills_keywords:
            if skill in text_lower:
                found_skills.append(skill)
        
        return found_skills

    def _extract_education(self, text: str) -> List[str]:
        """Extract education information from resume text."""
        education_info = []
        text_lower = text.lower()
        
        # Look for education patterns
        education_patterns = [
            r'([A-Z][a-z]+ [A-Z][a-z]+ University)',
            r'(University of [A-Z][a-z]+)',
            r'([A-Z][a-z]+ College)',
            r'(B\.?S\.?|M\.?S\.?|Ph\.?D\.?)\s+in\s+([A-Za-z\s]+)',
            r'(Bachelor|Master|Doctorate)\s+(of|in)\s+([A-Za-z\s]+)'
        ]
        
        for pattern in education_patterns:
            matches = re.findall(pattern, text)
            for match in matches:
                if isinstance(match, tuple):
                    education_info.extend([m for m in match if m])
                else:
                    education_info.append(match)
        
        return list(set(education_info))

    def _extract_experience(self, text: str) -> Dict[str, Any]:
        """Extract work experience information from resume text."""
        experience_data = {
            'total_years': 0
        }
        
        # Look for experience patterns
        experience_patterns = [
            r'(\d+)\s*(years?|yrs?)\s*(of\s*)?experience',
            r'(\d{1,2})\s*[-]\s*(\d{1,2})\s*(years?|yrs?)',
            r'from\s*(\d{4})\s*to\s*(present|\d{4})'
        ]
        
        for pattern in experience_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                # Extract years from first match
                first_match = matches[0]
                if isinstance(first_match, tuple):
                    try:
                        years = int(first_match[0])
                        experience_data['total_years'] = max(experience_data['total_years'], years)
                    except ValueError:
                        pass
        
        return experience_data