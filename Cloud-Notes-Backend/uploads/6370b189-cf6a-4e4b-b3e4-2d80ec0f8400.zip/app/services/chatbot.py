import os
import google.generativeai as genai
import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

class ChatbotService:
    def __init__(self):
        # Initialize Gemini API
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            logger.warning("GEMINI_API_KEY not found in environment variables. Using fallback responses.")
            self.model = None
        else:
            try:
                genai.configure(api_key=api_key)
                self.model = genai.GenerativeModel('gemini-pro')
                logger.info("Gemini model initialized successfully")
            except Exception as e:
                logger.error(f"Error initializing Gemini model: {str(e)}")
                self.model = None
        
        # System prompt for the chatbot
        self.system_prompt = """
        You are an AI assistant for a Resume Shortlisting System. Your role is to help recruiters 
        with questions about using the system, understanding resume matching results, and best 
        practices for candidate evaluation. You should be helpful, professional, and provide 
        concise answers. If asked about technical implementation details, provide high-level 
        explanations without revealing sensitive information.
        """

    def get_response(self, query: str) -> str:
        """
        Get a response from the chatbot for a given query.
        
        Args:
            query: User's question or query
            
        Returns:
            Chatbot's response
        """
        if self.model is None:
            # Use fallback responses
            return self._get_fallback_response(query)
        
        try:
            # Combine system prompt with user query
            full_prompt = f"{self.system_prompt}\n\nUser: {query}\nAssistant:"
            
            # Generate response
            response = self.model.generate_content(full_prompt)
            
            return response.text
        except Exception as e:
            logger.error(f"Error generating chatbot response: {str(e)}")
            return self._get_fallback_response(query)

    def _get_fallback_response(self, query: str) -> str:
        """Get fallback response when the model is not available."""
        query_lower = query.lower()
        
        if "upload" in query_lower and "resume" in query_lower:
            return "To upload resumes, go to the Recruiter Dashboard, click on 'Upload Resumes', select PDF or DOCX files, and click 'Upload'."
        
        if "job description" in query_lower:
            return "To create an effective job description, be specific about required skills and experience, include both technical and soft skills, and describe job responsibilities clearly."
        
        if "matching" in query_lower or "score" in query_lower:
            return "Our matching algorithm uses semantic similarity analysis (50% weight), skill matching (30% weight), and experience matching (20% weight) to find the best matches."
        
        if "interpret" in query_lower or "score" in query_lower:
            return "Match scores range from 0 to 1: 0.8-1.0 is an excellent match, 0.6-0.8 is a good match, 0.4-0.6 is a moderate match, and below 0.4 is a poor match."
        
        return "I apologize, but I'm having trouble responding right now. Please try again later or contact support for more assistance."

    def get_help_topics(self) -> Dict[str, str]:
        """Get common help topics and their descriptions."""
        return {
            "uploading_resumes": "How to upload resume files (PDF/DOCX)",
            "job_description": "How to create effective job descriptions",
            "matching_algorithm": "How the resume matching algorithm works",
            "interpreting_scores": "How to interpret match scores and rankings",
            "candidate_feedback": "How to provide feedback to candidates",
            "system_features": "Overview of system features and capabilities"
        }

    def get_predefined_response(self, topic: str) -> str:
        """Get predefined responses for common topics."""
        responses = {
            "uploading_resumes": """
            To upload resumes:
            1. Go to the Recruiter Dashboard
            2. Click on 'Upload Resumes'
            3. Select multiple PDF or DOCX files
            4. Click 'Upload'
            The system will automatically parse and analyze each resume.
            """,
            
            "job_description": """
            To create an effective job description:
            1. Be specific about required skills and experience
            2. Include both technical and soft skills
            3. Specify education requirements
            4. Mention preferred certifications
            5. Describe job responsibilities clearly
            """,
            
            "matching_algorithm": """
            Our matching algorithm uses:
            1. Semantic similarity analysis (50% weight)
            2. Skill matching (30% weight)
            3. Experience matching (10% weight)
            The system analyzes both the job description and resumes to find the best matches.
            """,
            
            "interpreting_scores": """
            Match scores range from 0 to 1:
            - 0.8-1.0: Excellent match
            - 0.6-0.8: Good match
            - 0.4-0.6: Moderate match
            - Below 0.4: Poor match
            Consider the breakdown of semantic, skill, and experience scores for detailed analysis.
            """
        }
        
        return responses.get(topic, "I don't have specific information about that topic. Could you ask something else?")