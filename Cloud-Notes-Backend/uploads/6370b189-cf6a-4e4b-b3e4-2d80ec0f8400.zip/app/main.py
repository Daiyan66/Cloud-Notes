import logging
from fastapi import FastAPI, File, UploadFile, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import os
from dotenv import load_dotenv
from services.parser import ResumeParser
from services.matcher import ResumeMatcher
from services.chatbot import ChatbotService
from core.config import settings
import jwt
from datetime import datetime, timedelta

# --- ADD THIS LOGGING CONFIGURATION ---
# Configure the root logger to display INFO level messages
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
# --- END OF NEW CONFIGURATION ---

# Load environment variables
load_dotenv()

app = FastAPI(
    title="Resume NLP Service",
    description="NLP service for resume parsing and matching",
    version="1.0.0"
)

# CORS middleware - Restrict to your frontend URL in production
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173"],  # Your React app URLs
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize services
resume_parser = ResumeParser()
resume_matcher = ResumeMatcher()
chatbot_service = ChatbotService()

# Security
security = HTTPBearer()

# JWT Configuration
JWT_SECRET = os.getenv("JWT_SECRET", "your-super-secret-jwt-key-here")
JWT_ALGORITHM = "HS256"

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """
    Verify JWT token from Spring Boot application
    """
    token = credentials.credentials
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        # You can add more validation here if needed
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

@app.get("/")
async def root():
    return {"message": "Resume NLP Service is running"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

@app.post("/parse-resume")
async def parse_resume(
    file: UploadFile = File(...),
    token_data: dict = Depends(verify_token)
):
    """
    Parse a resume file (PDF or DOCX) and extract structured information.
    """
    # Validate file type
    if not (file.filename.endswith('.pdf') or file.filename.endswith('.docx')):
        raise HTTPException(status_code=400, detail="Only PDF and DOCX files are supported")
    
    try:
        # Save uploaded file temporarily
        temp_file_path = f"temp_{file.filename}"
        with open(temp_file_path, "wb") as buffer:
            buffer.write(await file.read())
        
        # Parse the resume
        parsed_data = resume_parser.parse(temp_file_path)
        
        # Clean up temporary file
        os.remove(temp_file_path)
        
        return parsed_data
    except Exception as e:
        # Clean up file if it exists
        if os.path.exists(temp_file_path):
            os.remove(temp_file_path)
        raise HTTPException(status_code=500, detail=f"Error parsing resume: {str(e)}")

@app.post("/match-resumes")
async def match_resumes(
    request: dict,
    token_data: dict = Depends(verify_token)
):
    """
    Match a list of parsed resumes against a job description and return match scores.
    """
    try:
        # Extract data from request body
        job_description = request.get("job_description", "")
        resumes_data = request.get("resumes_data", [])
        
        match_results = resume_matcher.match(job_description, resumes_data)
        return match_results
    except Exception as e:
        # --- FIX IS HERE ---
        # Use the configured logger instead of an undefined one
        logging.error(f"Error matching resumes: {str(e)}")
        # --- END OF FIX ---
        raise HTTPException(status_code=500, detail=f"Error matching resumes: {str(e)}")

@app.post("/chatbot")
async def chatbot_query(
    query: str,
    token_data: dict = Depends(verify_token)
):
    """
    Get a response from the chatbot assistant.
    """
    try:
        response = chatbot_service.get_response(query)
        return {"response": response}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing chatbot query: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)