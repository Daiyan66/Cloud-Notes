from pydantic import BaseModel
from typing import List, Dict, Any

class ParseResponse(BaseModel):
    raw_text: str
    skills: List[str]
    education: List[str]
    experience: Dict[str, Any]
    contact_info: Dict[str, str]

class MatchResponse(BaseModel):
    resume_id: int
    resume_data: Dict[str, Any]
    semantic_similarity: float
    skill_match: float
    experience_match: float
    overall_score: float

class ChatbotResponse(BaseModel):
    response: str