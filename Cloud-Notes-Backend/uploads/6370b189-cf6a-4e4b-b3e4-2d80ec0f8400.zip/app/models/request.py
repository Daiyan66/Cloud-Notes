from pydantic import BaseModel
from typing import List, Dict, Any

class MatchRequest(BaseModel):
    job_description: str
    resumes_data: List[Dict[str, Any]]

class ChatbotRequest(BaseModel):
    query: str