import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # App settings
    app_name: str = "Resume NLP Service"
    app_version: str = "1.0.0"
    
    # API keys
    gemini_api_key: str = os.getenv("GEMINI_API_KEY", "")
    
    # Model settings
    model_name: str = os.getenv("MODEL_NAME", "all-MiniLM-L6-v2")
    
    # Database (if needed)
    database_url: str = os.getenv("DATABASE_URL", "")
    
    # JWT settings
    jwt_secret: str = os.getenv("JWT_SECRET", "your-super-secret-jwt-key-here")
    jwt_algorithm: str = "HS256"
    
    class Config:
        env_file = ".env"

settings = Settings()