document.addEventListener('DOMContentLoaded', () => {
    // Handle registration and login logic
    const registrationForm = document.getElementById('registration-form');
    const loginForm = document.getElementById('login-form');

    if (registrationForm) {
        registrationForm.addEventListener('submit', (event) => {
            event.preventDefault();
            // Registration logic here
            alert('Registered successfully!');
        });
    }

    if (loginForm) {
        loginForm.addEventListener('submit', (event) => {
            event.preventDefault();
            // Login logic here
            alert('Logged in successfully!');
        });
    }
});
