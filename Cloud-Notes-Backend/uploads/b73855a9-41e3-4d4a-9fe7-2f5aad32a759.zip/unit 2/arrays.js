// Creating an Empty Array
let names = [];
console.log(names);

// Creating an Array and Initializing with Values
let x = ["HTML", "CSS", "Javascript", "React"];
console.log(x);

// Creating and Initializing an array with constructors
let courses123 = new Array("HTML", "CSS", "Javascript", "React");
console.log(courses123);

// Creating an Array and Initializing with Values
let courses1234 = ["c", "java", "python", "c++"];
courses1234.push("js");
let lan =courses1234.pop();
console.log(lan);
// Accessing Array Elements
console.log(courses1234[0]);
console.log(courses1234[1]);

for (let i = 0; i < courses1234.length; i++) {
    console.log(courses1234[i]);
}

