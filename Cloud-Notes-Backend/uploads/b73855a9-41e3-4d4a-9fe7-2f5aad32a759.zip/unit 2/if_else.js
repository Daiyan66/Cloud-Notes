let marks = 75;

if (marks >= 50) {
  console.log("Pass");
} else {
  console.log("Fail");
}
