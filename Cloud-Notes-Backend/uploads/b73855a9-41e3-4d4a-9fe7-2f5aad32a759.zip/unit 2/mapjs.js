let numbers = [1, 2, 3, 4, 5];

// Using map() to create a new array with squared values
let squaredNumbers = numbers.map(function(num) {
  return num * num;
});

console.log(squaredNumbers);  // Output: [1, 4, 9, 16, 25]
console.log(numbers);         // Output: [1, 2, 3, 4, 5] (original array is unchanged)


// squaredNumbers = numbers.map(num => num * num);
//console.log(squaredNumbers);  // Output: [1, 4, 9, 16, 25]
