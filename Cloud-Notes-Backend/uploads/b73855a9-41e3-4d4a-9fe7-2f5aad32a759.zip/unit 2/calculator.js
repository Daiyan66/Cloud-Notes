<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Calculator</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin-top: 50px;
        }
        input {
            margin: 5px;
            padding: 10px;
            font-size: 16px;
        }
        button {
            padding: 10px 20px;
            font-size: 16px;
            margin: 5px;
        }
        #result {
            margin-top: 20px;
            font-size: 18px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h1>Simple Calculator</h1>
    <form>
        <input type="number" id="num1" placeholder="Enter first number" required>
        <input type="number" id="num2" placeholder="Enter second number" required>
        <br>
        <button type="button" onclick="add()">+</button>
        <button type="button" onclick="subtract()">-</button>
        <button type="button" onclick="multiply()">×</button>
        <button type="button" onclick="divide()">÷</button>
    </form>
    
    <div id="result">Result will appear here</div>

    <script>
        function add() {
            let num1 = parseFloat(document.getElementById('num1').value);
            let num2 = parseFloat(document.getElementById('num2').value);
            let result = num1 + num2;
            document.getElementById('result').textContent = "Result: " + result;
        }

        function subtract() {
            let num1 = parseFloat(document.getElementById('num1').value);
            let num2 = parseFloat(document.getElementById('num2').value);
            let result = num1 - num2;
            document.getElementById('result').textContent = "Result: " + result;
        }

        function multiply() {
            let num1 = parseFloat(document.getElementById('num1').value);
            let num2 = parseFloat(document.getElementById('num2').value);
            let result = num1 * num2;
            document.getElementById('result').textContent = "Result: " + result;
        }

        function divide() {
            let num1 = parseFloat(document.getElementById('num1').value);
            let num2 = parseFloat(document.getElementById('num2').value);
            if (num2 === 0) {
                document.getElementById('result').textContent = "Error: Division by zero is not allowed!";
            } else {
                let result = num1 / num2;
                document.getElementById('result').textContent = "Result: " + result;
            }
        }
    </script>
</body>
</html>
