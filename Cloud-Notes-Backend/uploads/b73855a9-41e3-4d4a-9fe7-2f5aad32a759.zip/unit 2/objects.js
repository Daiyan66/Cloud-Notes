let student = {
  name: "William",
  age: 21,
  course: "JavaScript"
};

console.log("Student Name:", student.name);
