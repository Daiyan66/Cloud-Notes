console.log("Hello Padmini, JavaScript is running in VS Code!");
