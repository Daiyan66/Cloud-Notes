<script>
console.log("== vs === Examples");

//Case 1: Number and String
console.log(5 == "5");   // true  (values same, type converted)
console.log(5 === "5");  // false (number vs string)

// Case 2: Number and Boolean
console.log(0 == false);  // true  (false converted to 0)
console.log(0 === false); // false (number vs boolean)

// Case 3: Null and Undefined
console.log(null == undefined);  // true (special case in JS)
console.log(null === undefined); // false (different types)

// Case 4: Identical values
console.log(10 == 10);   // true
console.log(10 === 10);  // true (same value, same type)
</script>

