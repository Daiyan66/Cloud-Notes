<script>
  var userInput = prompt("Please enter your name:");
  console.log("User input: " + userInput);
</script>

