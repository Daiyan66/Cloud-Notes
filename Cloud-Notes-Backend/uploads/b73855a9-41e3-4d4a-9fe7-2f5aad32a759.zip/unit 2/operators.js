// Addition
let a = 5 + 3;
console.log(a);

// Subtraction
let b = 10 - 4;
console.log(b); 

// Addition Assignment
let y = 5;
y += 3;
console.log(y);

// Subtraction Assignment
let z = 15;
z -= 6;
console.log(z); 
