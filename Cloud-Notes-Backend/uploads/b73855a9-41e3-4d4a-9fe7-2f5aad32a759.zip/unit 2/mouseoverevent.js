let para = document.getElementById("demo");

para.addEventListener("mouseover", function() {
  para.style.color = "red";
});

para.addEventListener("mouseout", function() {
  para.style.color = "black";
});
