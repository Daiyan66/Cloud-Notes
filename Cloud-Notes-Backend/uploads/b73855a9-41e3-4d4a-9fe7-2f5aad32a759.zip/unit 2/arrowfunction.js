//Arrow Function with One Parameter:
const square = num => num * num;

console.log(square(4));  // Output: 16

//Arrow Function with Multiple Parameters:

const add = (a, b) => a + b;

console.log(add(3, 7));  // Output: 10

//3. Arrow Function with No Parameters:

const sayHello = () => "Hello, World!";

console.log(sayHello());  // Output: Hello, World!

//4. Arrow Function with Multiple Statements:

const multiply = (a, b) => {
    const product = a * b;
    return product;
  };
  
  console.log(multiply(5, 10));  // Output: 50
  