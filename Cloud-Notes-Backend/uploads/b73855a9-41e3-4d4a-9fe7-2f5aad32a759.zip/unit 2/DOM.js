// Creating a new paragraph element
var newParagraph = document.createElement("p");

// Adding text to the new element
newParagraph.innerHTML = "This is a new paragraph added dynamically.";

// Appending the new element to an existing div
document.getElementById("myDiv").appendChild(newParagraph);

// Changing the style of an existing element
document.getElementById("myDiv").style.color = "blue";
