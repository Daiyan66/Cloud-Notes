var a = "Hello world"
var b = 10;
console.log(a);
console.log(b);
// Using let
{
    let num = 20;
    num=30;
    // Calling the function inside block
    console.log(num)
}

// Calling the function outside 
// block throws a Error
//console.log(num)

// Using const
const x = 22;
{
    const x = 90;
    console.log(x);
    {
        const x = 45;
        console.log(x);
    }
}
x=44;
console.log(x);
