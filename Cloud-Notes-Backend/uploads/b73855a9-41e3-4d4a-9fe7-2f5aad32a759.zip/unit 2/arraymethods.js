// Initialize an array
let fruits = ["apple", "banana", "cherry"];
console.log("Initial Array:", fruits);

// 1. push() - Adds one or more elements to the end of the array
fruits.push("orange");
console.log("After push('orange'):", fruits);

// 2. pop() - Removes the last element from the array
fruits.pop();
console.log("After pop():", fruits);

// 3. shift() - Removes the first element from the array
fruits.shift();
console.log("After shift():", fruits);

// 4. unshift() - Adds one or more elements to the beginning of the array
fruits.unshift("strawberry");
console.log("After unshift('strawberry'):", fruits);

// 5. splice() - Adds/Removes elements from the array
// Here, removing 1 element at index 1 and adding 'mango' and 'kiwi' at index 1
fruits.splice(1, 1, "mango", "kiwi");
console.log("After splice(1, 1, 'mango', 'kiwi'):", fruits);

// 6. slice() - Returns a shallow copy of a portion of an array into a new array
let slicedFruits = fruits.slice(1, 3);
console.log("After slice(1, 3):", slicedFruits);  // New sliced array

// 7. concat() - Combines two or more arrays
let tropicalFruits = ["pineapple", "papaya"];
let allFruits = fruits.concat(tropicalFruits);
console.log("After concat with tropicalFruits:", allFruits);

// 8. forEach() - Executes a provided function once for each array element
console.log("forEach() output:");
allFruits.forEach(function(fruit) {
  console.log(fruit);
});

// 9. map() - Creates a new array with the results of calling a function for every array element
let upperFruits = allFruits.map(function(fruit) 
{
  return fruit.toUpperCase();
});
console.log("After map() to uppercase:", upperFruits);

// 10. filter() - Creates a new array with all elements that pass the test implemented by the provided function
let longNamedFruits = allFruits.filter(function(fruit) 
{
  return fruit.length > 5;
});
console.log("After filter() for names longer than 5 characters:", longNamedFruits);

// 11. find() - Returns the value of the first element in the array that satisfies the provided testing function
let findFruit = allFruits.find(function(fruit) 
{
  return fruit === "mango";
});
console.log("After find('mango'):", findFruit);

// 12. includes() - Determines whether an array includes a certain value
let hasBanana = allFruits.includes("banana");
console.log("After includes('banana'):", hasBanana);

// 13. sort() - Sorts the elements of an array
allFruits.sort();
console.log("After sort():", allFruits);

// 14. reverse() - Reverses the order of the elements in an array
allFruits.reverse();
console.log("After reverse():", allFruits);
