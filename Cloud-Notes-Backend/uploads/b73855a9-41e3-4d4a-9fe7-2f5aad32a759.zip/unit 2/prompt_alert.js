<!DOCTYPE html>
<html>
<head>
  <title>Prompt Example</title>
</head>
<body>
  <h1>JavaScript Prompt Example</h1>

  <script>
    let name = prompt("Enter your name:");
    alert("Welcome, " + name + "!");
  </script>
</body>
</html>
