// Decimal Numbers
console.log(323)
// Binary Numbers
console.log(0b11);
// String
const str1 = "Welcome to nie";
console.log(str1);
// Boolean
let student = true;
console.log(student);
// null
let val = null;
console.log(val);
// undefined
let undefinedValue;
console.log(undefinedValue);
// Bigint
let bigNumber = 123456789012345678901234567890n;
console.log(bigNumber);
// Object
let person = {
    name: 'rahul',
    age: 21,
    usn:4n,
};
console.log(person);
