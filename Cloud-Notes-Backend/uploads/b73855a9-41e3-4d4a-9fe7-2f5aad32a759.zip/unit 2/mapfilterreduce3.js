const cities = [
  { name: "Tokyo", population: 5, continent: "Asia" },
  { name: "London", population: 3, continent: "Europe" },
  { name: "Lagos", population: 6, continent: "Africa" },
  { name: "New York", population: 2, continent: "North America" },
];

cities.forEach(city => {
  console.log(`City: ${city.name} (${city.continent})`);
});

const temp = cities.map(city => city.population * 2);
const temp1 = temp.filter(pop => pop > 5);
const temp2 = temp1.reduce((x, pop) => x + pop, 0);

console.log("temp:", temp);
console.log("temp:", temp.reverse());
console.log("temp1:", temp1);
console.log("temp2:", temp2);
