function greet() {
  alert("Hello, Padmini!");
}

document.getElementById("myBtn").addEventListener("click", greet);
