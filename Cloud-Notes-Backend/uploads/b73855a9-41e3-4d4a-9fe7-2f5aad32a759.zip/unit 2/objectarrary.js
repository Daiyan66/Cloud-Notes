let people = [
    { name: 'Alice', age: 25 },
    { name: 'Bob', age: 30 },
    { name: 'Charlie', age: 35 }
  ];
  
  // Using map() to extract names
  let names = people.map(person => person.name);
  console.log(names);  // Output: ["Alice", "Bob", "Charlie"]
  
  