var x = prompt("Enter your name:");
console.log("Hello, " + x + "!");
