// 1. Object Creation using Object Literal
let person = {
    firstName: "John",
    lastName: "Doe",
    age: 30,
    occupation: "Developer"
  };
  
  console.log("Initial Object:", person);
  
  // 2. Accessing Object Properties (Dot Notation and Bracket Notation)
  console.log("First Name:", person.firstName);   // Dot Notation
  console.log("Last Name:", person["lastName"]);  // Bracket Notation
  
  // 3. Modifying Object Properties
  person.age = 80;
  person["occupation"] = "Manager";
  console.log("After Modification:", person);
  
  // 4. Adding New Properties to the Object
  person.gender = "Male";
  person["country"] = "USA";
  console.log("After Adding New Properties:", person);
  
  // 5. Deleting Properties from the Object
  delete person.occupation;
  console.log("After Deleting 'occupation' Property:", person);
  
  // 6. Nested Objects
  person.address = {
    street: "123 Main St",
    city: "Metropolis",
    zip: "10001"
  };
  console.log("After Adding Nested Object:", person);
  
  // Accessing Nested Object Properties
  console.log("City:", person.address.city);
  console.log("ZIP Code:", person["address"]["zip"]);
  
  // 7. Using Object Methods
  person.greet = function() {
    return "Hello, " + this.firstName + " " + this.lastName + "!";
  };
  console.log(person.greet());  // Calling the method
  
  // 8. Checking Property Existence (Using 'in' operator)
  console.log("Has 'age' property:", 'age' in person);
  console.log("Has 'occupation' property:", 'occupation' in person);
  
  