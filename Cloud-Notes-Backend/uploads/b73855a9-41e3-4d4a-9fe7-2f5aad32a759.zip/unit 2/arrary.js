let fruits = ["Apple", "Banana", "Mango"];
fruits.push("Orange"); // Add element
console.log("Fruits:", fruits);
console.log("First Fruit:", fruits[0]);
